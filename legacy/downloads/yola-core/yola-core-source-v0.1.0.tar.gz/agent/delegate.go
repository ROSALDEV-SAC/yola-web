package agent

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/config"
	"github.com/ROSALDEV-SAC/yola-core/llm"
	"github.com/ROSALDEV-SAC/yola-core/session"
	"github.com/ROSALDEV-SAC/yola-core/sse"
)

// DefaultDelegateTimeout is the default timeout for synchronous delegation (kept for backward compat).
const DefaultDelegateTimeout = 5 * time.Minute

// MaxDelegateIterations and DelegateInitialBackoff are kept for backward compat.
const (
	MaxDelegateIterations   = 1000
	DelegateInitialBackoff = 100 * time.Millisecond
)

// DelegateServices holds the runtime dependencies needed by the delegate handler.
// Set by main.go during wiring.
type DelegateService struct {
	SessionStore session.Store
	EventBus     *sse.EventBus
	LLMClient    llm.Client
	ProviderKeys *config.ProviderKeys
	Catalog      *config.Catalog
	Memory       interface {
		RecordDecision(sessionID, workspaceID string, turn int, observation, inference, decision, alternatives, toolName, toolArgs, context, outcome, outcomeDetail string, importance float64) string
	}
	Metrics interface {
		Add(name string, delta int64)
	}
	AgentStore Store
}

// DelegateServices is the global singleton holding wired dependencies.
var DelegateServices DelegateService

// DelegateHandler is the handler for the delegate tool.
// It satisfies ToolHandler's func(args map[string]interface{}) (string, error) signature.
// Now delegates to the DelegateTracker if available (async), or returns an error.
func DelegateHandler(args map[string]interface{}) (string, error) {
	return DelegateWithEvents(args, DelegateServices.EventBus, &DelegateServices)
}

// DelegateWithEvents performs asynchronous delegation via the DelegateTracker.
// If the tracker is initialized, it creates a child session, registers the
// delegation, launches the sub-agent in a goroutine, and returns immediately
// with a JSON object containing the delegationId and status.
//
// The caller should use check_delegation / retrieve_delegation tools to
// monitor and collect results. The child session persists for review/fork.
func DelegateWithEvents(args map[string]interface{}, events *sse.EventBus, svc *DelegateService) (string, error) {
	if DelegateTrackerInstance != nil {
		return DelegateTrackerInstance.DelegateHandler(args)
	}
	return "", fmt.Errorf("delegate: tracker not initialized (cannot delegate asynchronously)")
}

// getStringArg is a helper duplicate (avoids importing tools for this).
func getStringArg(args map[string]interface{}, key string) (string, error) {
	v, ok := args[key]
	if !ok {
		return "", fmt.Errorf("missing required argument '%s'", key)
	}
	s, ok := v.(string)
	if !ok {
		return "", fmt.Errorf("argument '%s' must be a string, got %T", key, v)
	}
	return s, nil
}

// getOptionalStringArg is a helper duplicate.
func getOptionalStringArg(args map[string]interface{}, key string) string {
	v, ok := args[key]
	if !ok {
		return ""
	}
	s, _ := v.(string)
	return s
}

// getOptionalIntArg returns an optional int argument with a default value.
func getOptionalIntArg(args map[string]interface{}, key string, defaultVal int) int {
	v, ok := args[key]
	if !ok {
		return defaultVal
	}
	switch n := v.(type) {
	case float64:
		return int(n)
	case int:
		return n
	case int64:
		return int(n)
	default:
		return defaultVal
	}
}

// init ensures the json encoding is linked.
func init() {
	_ = json.Marshal
}

