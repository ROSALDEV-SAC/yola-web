package agent

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/db"
)

// SQLiteAgentStore provides SQLite-backed CRUD for agent configurations.
type SQLiteAgentStore struct {
	database *sql.DB
}

// NewStore creates a new AgentStore.
func NewStore(database *sql.DB) *SQLiteAgentStore {
	return &SQLiteAgentStore{database: database}
}

// SeedDefaults inserts default agents (yola, build, chat) into the DB if they don't exist.
func (as *SQLiteAgentStore) SeedDefaults(keys interface{}) {
	defaultIDs := []string{"yola", "build", "chat"}
	now := time.Now().UnixMilli()
	for _, id := range defaultIDs {
		var count int
		as.database.QueryRow(`SELECT COUNT(*) FROM agent_configs WHERE id = ?`, id).Scan(&count)
		if count > 0 {
			continue
		}
		// Use config agent if available (from providers.json)
		if keyProvider, ok := keys.(interface{ GetAgent(string) (interface{}, bool) }); ok {
			if def, ok := keyProvider.GetAgent(id); ok {
				if cfg, ok := def.(interface {
					GetName() string
					GetSystemPrompt() string
					GetModel() string
					GetTools() []string
					GetSkills() []string
				}); ok {
					toolsJSON, err := json.Marshal(cfg.GetTools())
					if err != nil {
						log.Printf("[WARN] marshal tools for agent %s: %v", id, err)
						continue
					}
					skillsJSON, err := json.Marshal(cfg.GetSkills())
					if err != nil {
						log.Printf("[WARN] marshal skills for agent %s: %v", id, err)
						continue
					}
					as.database.Exec(
						`INSERT OR IGNORE INTO agent_configs (id, name, system_prompt, model, tools, skills, max_turns, temperature, created_at, updated_at)
						 VALUES (?, ?, ?, ?, ?, ?, 20, 0.7, ?, ?)`,
						id, cfg.GetName(), cfg.GetSystemPrompt(), cfg.GetModel(), string(toolsJSON), string(skillsJSON), now, now,
					)
					continue
				}
			}
		}
		// Insert defaults
		prompts := map[string]string{
			"yola":  DefaultSystemPrompt,
			"build": "You are a build/deploy agent. Execute build commands and report results.",
			"chat":  "You are a helpful assistant. Answer questions and help with general tasks.",
		}
		prompt := prompts[id]
		if prompt == "" {
			prompt = "You are a helpful assistant."
		}
		as.database.Exec(
			`INSERT OR IGNORE INTO agent_configs (id, name, system_prompt, model, tools, skills, max_turns, temperature, created_at, updated_at)
			 VALUES (?, ?, ?, ?, '[]', '[]', 20, 0.7, ?, ?)`,
			id, id, prompt, "", now, now,
		)
	}
}

func (as *SQLiteAgentStore) Create(cfg *AgentConfig) (string, error) {
	now := time.Now().UnixMilli()
	id := db.NewID("agt")
	toolsJSON, err := json.Marshal(cfg.Tools)
	if err != nil {
		return "", fmt.Errorf("marshal tools: %w", err)
	}
	skillsJSON, err := json.Marshal(cfg.Skills)
	if err != nil {
		return "", fmt.Errorf("marshal skills: %w", err)
	}
	_, err = as.database.Exec(
		`INSERT INTO agent_configs (id, name, description, system_prompt, model, provider, tools, skills, max_turns, temperature, created_at, updated_at)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		id, cfg.Name, cfg.Description, cfg.SystemPrompt, cfg.Model, cfg.Provider, string(toolsJSON), string(skillsJSON), cfg.MaxTurns, cfg.Temperature, now, now,
	)
	if err != nil {
		return "", fmt.Errorf("create agent: %w", err)
	}
	cfg.ID = id
	return id, nil
}

func (as *SQLiteAgentStore) Get(id string) (*AgentConfig, error) {
	row := as.database.QueryRow(
		`SELECT id, name, COALESCE(description,''), COALESCE(system_prompt,''), COALESCE(model,''),
		        COALESCE(provider,''), COALESCE(tools,'[]'), COALESCE(skills,'[]'),
		        max_turns, COALESCE(temperature,0.7), created_at, updated_at
		 FROM agent_configs WHERE id = ?`, id,
	)
	cfg := &AgentConfig{}
	var toolsStr, skillsStr string
	err := row.Scan(&cfg.ID, &cfg.Name, &cfg.Description, &cfg.SystemPrompt, &cfg.Model,
		&cfg.Provider, &toolsStr, &skillsStr, &cfg.MaxTurns, &cfg.Temperature, &cfg.CreatedAt, &cfg.UpdatedAt)
	if err != nil {
		return nil, err
	}
	json.Unmarshal([]byte(toolsStr), &cfg.Tools)
	json.Unmarshal([]byte(skillsStr), &cfg.Skills)
	return cfg, nil
}

func (as *SQLiteAgentStore) List() ([]*AgentConfig, error) {
	rows, err := as.database.Query(
		`SELECT id, name, COALESCE(description,''), COALESCE(system_prompt,''), COALESCE(model,''),
		        COALESCE(provider,''), COALESCE(tools,'[]'), COALESCE(skills,'[]'),
		        max_turns, COALESCE(temperature,0.7), created_at, updated_at
		 FROM agent_configs ORDER BY created_at ASC`,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var configs []*AgentConfig
	for rows.Next() {
		cfg := &AgentConfig{}
		var toolsStr, skillsStr string
		if err := rows.Scan(&cfg.ID, &cfg.Name, &cfg.Description, &cfg.SystemPrompt, &cfg.Model,
			&cfg.Provider, &toolsStr, &skillsStr, &cfg.MaxTurns, &cfg.Temperature, &cfg.CreatedAt, &cfg.UpdatedAt); err != nil {
			continue
		}
		json.Unmarshal([]byte(toolsStr), &cfg.Tools)
		json.Unmarshal([]byte(skillsStr), &cfg.Skills)
		configs = append(configs, cfg)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("rows iter: %w", err)
	}
	return configs, nil
}

func (as *SQLiteAgentStore) Update(cfg *AgentConfig) error {
	now := time.Now().UnixMilli()
	toolsJSON, err := json.Marshal(cfg.Tools)
	if err != nil {
		return fmt.Errorf("marshal tools: %w", err)
	}
	skillsJSON, err := json.Marshal(cfg.Skills)
	if err != nil {
		return fmt.Errorf("marshal skills: %w", err)
	}
	_, err = as.database.Exec(
		`UPDATE agent_configs SET name=?, description=?, system_prompt=?, model=?, provider=?,
		 tools=?, skills=?, max_turns=?, temperature=?, updated_at=? WHERE id=?`,
		cfg.Name, cfg.Description, cfg.SystemPrompt, cfg.Model, cfg.Provider,
		string(toolsJSON), string(skillsJSON), cfg.MaxTurns, cfg.Temperature, now, cfg.ID,
	)
	return err
}

func (as *SQLiteAgentStore) Delete(id string) error {
	_, err := as.database.Exec(`DELETE FROM agent_configs WHERE id = ?`, id)
	return err
}
