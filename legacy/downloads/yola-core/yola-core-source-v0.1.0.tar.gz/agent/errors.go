package agent

import "fmt"

// ─── Agent Error Types ─────────────────────────────────────────────

// AgentError clasifica errores del agent loop
type AgentError struct {
	Turn    int
	Phase   string // "llm_call", "tool_execution", "stream", "interrupt"
	Message string
	Cause   error
	Fatal   bool // si es fatal, el loop debe detenerse
}

func (e *AgentError) Error() string {
	return fmt.Sprintf("[AGENT turn=%d phase=%s] %s", e.Turn, e.Phase, e.Message)
}

func (e *AgentError) Unwrap() error {
	return e.Cause
}
