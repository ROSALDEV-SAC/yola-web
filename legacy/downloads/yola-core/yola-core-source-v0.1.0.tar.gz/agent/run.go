package agent

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/config"
	"github.com/ROSALDEV-SAC/yola-core/governor"
	"github.com/ROSALDEV-SAC/yola-core/llm"
	"github.com/ROSALDEV-SAC/yola-core/memory"
	"github.com/ROSALDEV-SAC/yola-core/session"
	"github.com/ROSALDEV-SAC/yola-core/sse"
	"github.com/ROSALDEV-SAC/yola-core/tools"
)

// Package-level state manager for concurrency control across sessions.
// Created once; shared across all Run invocations on the same process.
var runStateManager = session.DefaultRunStateManager

// retryBackoff defines the sleep durations between transient LLM retries.
var retryBackoff = []time.Duration{1 * time.Second, 3 * time.Second, 5 * time.Second}

// Run executes the agent loop for a session.
// It reads messages from the session store, calls the LLM with tools,
// handles tool calls, and streams results via SSE.
func (a *Agent) Run(
	sessionID string,
	store session.Store,
	events *sse.EventBus,
	llmClient llm.Client,
	catalog *config.Catalog,
	apiKeys map[string]string,
	modelRef config.ModelRef,
	keys *config.ProviderKeys,
) {
	sessionObj := store.Get(sessionID)
	if sessionObj == nil {
		return
	}

	// ── RunStateManager: acquire session lock ──────────────────────────
	if err := runStateManager.TryAcquire(sessionID); err != nil {
		emitAndStoreError(events, store, sessionID, fmt.Sprintf("Session is busy: %v", err))
		return
	}
	defer runStateManager.Release(sessionID)

	// ── Step events ────────────────────────────────────────────────────
	events.Publish(sse.NewStepStartedEvent(sessionID, "main", "Agent processing"))
	stepStatus := "completed"
	defer func() {
		events.Publish(sse.NewStepEndedEvent(sessionID, "main", stepStatus))
	}()

	// ── Governor: classify user intent ─────────────────────────────────
	initMsgs := store.GetMessages(sessionID)
	lastUserMsg := getLastUserMessage(initMsgs)

	gov := governor.NewGovernor(nil)
	cls := gov.Classify(lastUserMsg, governor.Context{
		WorkspaceID: sessionObj.WorkspaceID,
		SessionID:   sessionID,
	})

	// DIRECT mode: execute tool directly without LLM
	if cls.IsDirect() {
		dc := cls.DirectCall
		argsJSON, _ := json.Marshal(dc.Args)
		events.Publish(sse.NewToolCalledEvent(sessionID, "direct", dc.ToolName, string(argsJSON)))
		result, execErr := tools.ExecuteTool(dc.ToolName, dc.Args)
		if execErr != nil {
			events.Publish(sse.NewToolFailedEvent(sessionID, "direct", dc.ToolName, execErr.Error()))
			store.AddToolResultWithState(sessionID, "", "direct", dc.ToolName, fmt.Sprintf("Error: %v", execErr), session.ToolCallFailed)
		} else {
			events.Publish(sse.NewToolResultEvent(sessionID, "direct", dc.ToolName, result))
			store.AddToolResultWithState(sessionID, "", "direct", dc.ToolName, result, session.ToolCallCompleted)
		}
		events.Publish(sse.NewTextEndedEvent(sessionID))
		events.Publish(sse.NewSessionUpdatedEvent(sessionID))
		return
	}

	// ── Resolve provider ──────────────────────────────────────────────
	providerID := modelRef.ProviderID
	modelID := modelRef.ID
	variant := modelRef.Variant

	// Auto-resolve ProviderID from catalog if not set
	if providerID == "" {
		for pid, cp := range catalog.Raw() {
			if _, ok := cp.Models[modelID]; ok {
				providerID = pid
				break
			}
		}
	}

	cp := catalog.GetProvider(providerID)
	if cp == nil {
		stepStatus = "failed"
		emitAndStoreError(events, store, sessionID, fmt.Sprintf("Provider '%s' not found in catalog.", providerID))
		return
	}

	apiKey, hasKey := apiKeys[providerID]
	if !hasKey || apiKey == "" {
		if providerID != "opencode" {
			stepStatus = "failed"
			emitAndStoreError(events, store, sessionID, fmt.Sprintf("Provider '%s' needs an API key.", providerID))
			return
		}
		apiKey = "public"
	}

	apiURL := cp.API
	if apiURL == "" {
		stepStatus = "failed"
		emitAndStoreError(events, store, sessionID, fmt.Sprintf("Provider '%s' has no API URL.", providerID))
		return
	}

	// ── Resolve temperature from variant ──────────────────────────────
	var temperature *float64
	switch variant {
	case "minimal":
		t := 0.1
		temperature = &t
	case "low":
		t := 0.3
		temperature = &t
	case "medium":
		t := 0.5
		temperature = &t
	case "high":
		t := 0.7
		temperature = &t
	case "max":
		t := 0.9
		temperature = &t
	}

	// ── System prompt ─────────────────────────────────────────────────
	systemPrompt := a.SystemPrompt
	if systemPrompt == "" {
		systemPrompt = DefaultSystemPrompt
	}

	// ── Tool definitions ──────────────────────────────────────────────
	allTools := tools.GetAllTools()
	var filteredTools []llm.ToolDefinition
	if len(a.Tools) > 0 {
		filteredTools = make([]llm.ToolDefinition, 0, len(a.Tools))
		for _, t := range allTools {
			for _, name := range a.Tools {
				if t.Name == name {
					filteredTools = append(filteredTools, llm.ToolDefinition{
						Type: "function",
						Function: llm.ToolFunction{
							Name:        t.Name,
							Description: t.Description,
							Parameters: llm.ToolSchema{
								Type:       t.Parameters.Type,
								Properties: convertProperties(t.Parameters.Properties),
								Required:   t.Parameters.Required,
							},
						},
					})
					break
				}
			}
		}
	} else {
		filteredTools = make([]llm.ToolDefinition, len(allTools))
		for i, t := range allTools {
			filteredTools[i] = llm.ToolDefinition{
				Type: "function",
				Function: llm.ToolFunction{
					Name:        t.Name,
					Description: t.Description,
					Parameters: llm.ToolSchema{
						Type:       t.Parameters.Type,
						Properties: convertProperties(t.Parameters.Properties),
						Required:   t.Parameters.Required,
					},
				},
			}
		}
	}

	// Append skill tools
	if keys != nil && len(a.Skills) > 0 {
		skillTools := keys.GetSkillTools(a.Skills)
		for _, st := range skillTools {
			filteredTools = append(filteredTools, llm.ToolDefinition{
				Type: "function",
				Function: llm.ToolFunction{
					Name:        st.Name,
					Description: st.Description,
					Parameters: llm.ToolSchema{
						Type:       st.Parameters.Type,
						Properties: convertProperties(st.Parameters.Properties),
						Required:   st.Parameters.Required,
					},
				},
			})
			// Register skill tool handler
			tools.Register(tools.Tool{
				Name:        st.Name,
				Description: st.Description,
				Parameters:  st.Parameters,
				Handler:     tools.BuildSkillBuiltinHandler(st.Name),
			})
		}
	}

	// Restrict delegate tool to agents with CanDelegate permission
	if !a.CanDelegate {
		var noDelegate []llm.ToolDefinition
		for _, t := range filteredTools {
			if t.Function.Name != "delegate" {
				noDelegate = append(noDelegate, t)
			}
		}
		filteredTools = noDelegate
	}

	// ── Context injection: workspace, git, agent info ─────────────────
	var contextLines []string
	workDir := tools.GetWorkDir()
	contextLines = append(contextLines, "## Contexto actual\n")
	contextLines = append(contextLines, fmt.Sprintf("- **Workspace**: `%s`", workDir))
	contextLines = append(contextLines, fmt.Sprintf("- **Fecha**: %s", time.Now().Format("2006-01-02 15:04")))
	contextLines = append(contextLines, fmt.Sprintf("- **Agente**: %s (%s)", a.Name, a.ID))

	// Tools list
	toolNames := make([]string, 0, len(filteredTools))
	for _, t := range filteredTools {
		toolNames = append(toolNames, t.Function.Name)
	}
	contextLines = append(contextLines, fmt.Sprintf("- **Tools disponibles**: %s", strings.Join(toolNames, ", ")))

	// Git repo detection
	gitDir := filepath.Join(workDir, ".git")
	if info, err := os.Stat(gitDir); err == nil && info.IsDir() {
		branchBytes, _ := exec.Command("git", "-C", workDir, "rev-parse", "--abbrev-ref", "HEAD").Output()
		statusBytes, _ := exec.Command("git", "-C", workDir, "status", "--short").Output()
		commitBytes, _ := exec.Command("git", "-C", workDir, "log", "--oneline", "-1").Output()

		branch := strings.TrimSpace(string(branchBytes))
		status := ""
		if len(strings.TrimSpace(string(statusBytes))) > 0 {
			status = "dirty"
		} else {
			status = "clean"
		}
		lastCommit := strings.TrimSpace(string(commitBytes))

		contextLines = append(contextLines, "- **Git**: sí")
		contextLines = append(contextLines, fmt.Sprintf("  - Branch: `%s`", branch))
		contextLines = append(contextLines, fmt.Sprintf("  - Status: %s", status))
		if lastCommit != "" {
			contextLines = append(contextLines, fmt.Sprintf("  - Último commit: `%s`", lastCommit))
		}
	} else {
		contextLines = append(contextLines, "- **Git**: no (no es un repositorio git)")
	}

	systemPrompt = systemPrompt + "\n\n" + strings.Join(contextLines, "\n")

	// ── Memory injection: relevant memories ─────────────────────────────
	if memSys, ok := a.Memory.(memory.System); ok {
		lastUserMsg := getLastUserMessage(store.GetMessages(sessionID))

		var memoryLines []string

		// Working memory (current session state)
		if wmEntries, err := memSys.WorkingGetAll(sessionID); err == nil && len(wmEntries) > 0 {
			memoryLines = append(memoryLines, "## Estado de sesión\n")
			for _, e := range wmEntries {
				memoryLines = append(memoryLines, fmt.Sprintf("- %s: %s", e.Key, e.Value))
			}
		}

		// Query semantic memory by extracted keywords
		if semEntries, err := memSys.QuerySemantic(lastUserMsg, 0.3, 3); err == nil && len(semEntries) > 0 {
			memoryLines = append(memoryLines, "## Memorias relevantes\n")
			for _, e := range semEntries {
				memoryLines = append(memoryLines, fmt.Sprintf("- %s (confianza: %.0f%%)", e.Content, e.Confidence*100))
			}
		}

		// Query episodic memory (past experiences matching keywords)
		if epEntries, err := memSys.QueryEpisodic(lastUserMsg, 3); err == nil && len(epEntries) > 0 {
			memoryLines = append(memoryLines, "## Experiencias anteriores\n")
			for _, e := range epEntries {
				memoryLines = append(memoryLines, fmt.Sprintf("- [%s] %s → %s", e.Action, e.Observation, e.Outcome))
			}
		}

		if len(memoryLines) > 0 {
			systemPrompt = systemPrompt + "\n\n" + strings.Join(memoryLines, "\n")
		}
	}

	// ── Max turns ─────────────────────────────────────────────────────
	maxTurns := a.MaxTurns
	if maxTurns <= 0 {
		maxTurns = 20
	}

	// ── Context budget ────────────────────────────────────────────────
	modelLimit := catalog.GetModelContextLimit(modelRef)
	budget := NewContextBudget(modelLimit)

	// ── Context with cancellation (interrupt) ──────────────────────────
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runStateManager.RegisterCancel(sessionID, cancel) // enables external interrupt

	// ── 5-minute soft warning (does NOT kill the loop) ──────────────────
	timeoutWarning := time.AfterFunc(5*time.Minute, func() {
		events.Publish(sse.Event{
			Type: "session_5min_warning",
			Data: map[string]interface{}{
				"sessionId": sessionID,
				"message":   "La sesión lleva 5 minutos activa",
			},
		})
	})
	defer timeoutWarning.Stop()

	// Provider metadata to attach to stored messages
	providerMeta := &session.ProviderMetadata{
		ProviderID: providerID,
		ModelID:    modelID,
	}

	// ── Circuit Breaker ──
	const maxConsecutiveErrors = 3
	consecutiveErrors := 0
	const maxToolDepth = 10

	// ── Agent Loop ────────────────────────────────────────────────────
	for turn := 0; turn < maxTurns; turn++ {
		select {
		case <-ctx.Done():
			stepStatus = "interrupted"
			events.Publish(sse.NewInterruptRequestedEvent(sessionID, "Agente interrumpido por el usuario"))
			events.Publish(sse.NewTextEndedEvent(sessionID))
			return
		default:
		}

		// Get conversation history
		msgs := store.GetMessages(sessionID)

		// Check context budget and compact if needed
		if budget.ShouldCompact(msgs) {
			msgs = CompactMessages(msgs, budget.Available)
		}

		// Build LLM messages
		chatMsgs := buildLLMMessages(systemPrompt, msgs)

		// ── Call LLM with retry on transient errors ─────────────────
		startTime := time.Now()
		var chunkChan <-chan llm.LLMChunk
		var callErr error

		for attempt := 0; attempt <= len(retryBackoff); attempt++ {
			chunkChan, callErr = llmClient.CallWithToolsContext(ctx, apiURL, apiKey, modelID, chatMsgs, filteredTools, temperature)
			if callErr == nil {
				break
			}
			if isTransientError(callErr) && attempt < len(retryBackoff) {
				runStateManager.SetRetry(sessionID, attempt+1, fmt.Sprintf("LLM call attempt %d failed: %v", attempt+1, callErr))
				time.Sleep(retryBackoff[attempt])
				continue
			}
			// Context canceled → interrupt gracefully
			if ctx.Err() != nil {
				stepStatus = "interrupted"
				events.Publish(sse.NewInterruptRequestedEvent(sessionID, "Agente interrumpido por el usuario"))
				events.Publish(sse.NewTextEndedEvent(sessionID))
				return
			}
			// Non-transient or out of retries → bail
			stepStatus = "failed"
			emitAndStoreError(events, store, sessionID, fmt.Sprintf("LLM call failed: %v", callErr))
			return
		}
		if callErr != nil {
			if ctx.Err() != nil {
				stepStatus = "interrupted"
				events.Publish(sse.NewInterruptRequestedEvent(sessionID, "Agente interrumpido por el usuario"))
				events.Publish(sse.NewTextEndedEvent(sessionID))
				return
			}
			stepStatus = "failed"
			emitAndStoreError(events, store, sessionID, fmt.Sprintf("LLM call failed after retries: %v", callErr))
			return
		}

		latencyMs := time.Since(startTime).Milliseconds()

		// Process streaming response
		var fullText strings.Builder
		var fullReasoning strings.Builder
		var toolCalls []llm.ToolCallData

	chunkLoop:
		for chunk := range chunkChan {
			switch chunk.Type {
			case "text":
				fullText.WriteString(chunk.Text)
				events.Publish(sse.NewTextDeltaEvent(sessionID, chunk.Text))
			case "reasoning":
				fullReasoning.WriteString(chunk.Reasoning)
				events.Publish(sse.NewReasoningDeltaEvent(sessionID, chunk.Reasoning))
			case "tool_call":
				if chunk.ToolCall != nil {
					tc := llm.ToolCallData{
						ID:   chunk.ToolCall.ID,
						Type: chunk.ToolCall.Type,
						Function: llm.ToolCallFuncData{
							Name:      chunk.ToolCall.Function.Name,
							Arguments: chunk.ToolCall.Function.Arguments,
						},
					}
					toolCalls = append(toolCalls, tc)
				}
			case "error":
				if ctx.Err() != nil {
					stepStatus = "interrupted"
					break chunkLoop
				}
				stepStatus = "failed"
				emitAndStoreError(events, store, sessionID, fmt.Sprintf("Stream error: %s", chunk.Error))
				return
			case "done":
				// Stream ended
			}
		}

		// If interrupted, emit event and store what we have, then return
		if stepStatus == "interrupted" {
			events.Publish(sse.NewInterruptRequestedEvent(sessionID, "Agente interrumpido por el usuario"))
			events.Publish(sse.NewTextEndedEvent(sessionID))
			if len(toolCalls) > 0 {
				store.AddInterruptedMessageWithTools(sessionID, fullText.String(), fullReasoning.String(),
					convertToolCalls(toolCalls), providerMeta, latencyMs)
			} else if fullText.Len() > 0 || fullReasoning.Len() > 0 {
				store.AddInterruptedMessage(sessionID, fullText.String(), fullReasoning.String(), providerMeta, latencyMs)
			}
			events.Publish(sse.NewSessionUpdatedEvent(sessionID))
			return
		} else if len(toolCalls) > 0 {
			// ── If tool calls were received, execute them ───────────
			// Store assistant message with tool calls and metadata
			assistantMsg := store.AddMessageWithMetadata(sessionID, "assistant", fullText.String(), fullReasoning.String(), "",
				convertToolCalls(toolCalls), nil, providerMeta, latencyMs)
			assistantMsgID := ""
			if assistantMsg != nil {
				assistantMsgID = assistantMsg.ID
			}
			if DelegateTrackerInstance != nil {
				DelegateTrackerInstance.UpdateActivity(sessionID)
			}

			// ── Execute tool calls with circuit breaker ──
			for idx, tc := range toolCalls {
				select {
				case <-ctx.Done():
					stepStatus = "interrupted"
					events.Publish(sse.NewInterruptRequestedEvent(sessionID, "interrupted by user"))
					events.Publish(sse.NewTextEndedEvent(sessionID))
					return
				default:
				}

				events.Publish(sse.NewToolCalledEvent(sessionID, tc.ID, tc.Function.Name, tc.Function.Arguments))

				// Parse arguments
				var argsMap map[string]interface{}
				if err := json.Unmarshal([]byte(tc.Function.Arguments), &argsMap); err != nil {
					store.AddToolResultWithState(sessionID, assistantMsgID, tc.ID, tc.Function.Name,
						fmt.Sprintf("Error: invalid arguments JSON: %v", err), session.ToolCallFailed)
					continue
				}

				// Inject session ID for tools that need it
				if argsMap != nil {
					if tc.Function.Name == "delegate" || tc.Function.Name == "bash" {
						argsMap["sessionId"] = sessionID
					}
				}

				// Execute tool with safe wrapper (recover + circuit breaker)
				result, execErr := safeExecuteTool(tc.Function.Name, argsMap)

				// Track metrics if available
				if a.Metrics != nil {
					if m, ok := a.Metrics.(interface{ Add(name string, delta int64) }); ok {
						m.Add("toolCalls", 1)
					}
				}

				if execErr != nil {
					consecutiveErrors++
					log.Printf("[WARN] tool %s failed (error %d/%d): %v", tc.Function.Name, consecutiveErrors, maxConsecutiveErrors, execErr)
					events.Publish(sse.NewToolFailedEvent(sessionID, tc.ID, tc.Function.Name, execErr.Error()))
					store.AddToolResultWithState(sessionID, assistantMsgID, tc.ID, tc.Function.Name,
						fmt.Sprintf("Error executing %s (call %s): %v", tc.Function.Name, tc.ID, execErr), session.ToolCallFailed)

					if consecutiveErrors >= maxConsecutiveErrors {
						stepStatus = "error"
						log.Printf("[ERROR] circuit breaker: %d consecutive tool failures", maxConsecutiveErrors)
						events.Publish(sse.NewErrorEvent(sessionID, fmt.Sprintf("Circuit breaker: %d consecutive tool errors", maxConsecutiveErrors)))
						events.Publish(sse.NewTextEndedEvent(sessionID))
						return
					}
				} else {
					// Success — reset circuit breaker
					consecutiveErrors = 0
					events.Publish(sse.NewToolResultEvent(sessionID, tc.ID, tc.Function.Name, result))
					result = fmt.Sprintf("[Output from %s (call %s)]\n%s", tc.Function.Name, tc.ID, result)
					if idx < len(toolCalls)-1 {
						result += "\n\n---\n\n"
					}
					store.AddToolResultWithState(sessionID, assistantMsgID, tc.ID, tc.Function.Name, result, session.ToolCallCompleted)
				}
				if DelegateTrackerInstance != nil {
					DelegateTrackerInstance.UpdateActivity(sessionID)
				}
			}

			// Emit session updated event
			events.Publish(sse.NewSessionUpdatedEvent(sessionID))

			continue
		}

		// ── No tool calls: final text response ─────────────────────
		events.Publish(sse.NewTextEndedEvent(sessionID))

		// Store the assistant response with metadata (text, reasoning, or both)
		if fullText.Len() > 0 || fullReasoning.Len() > 0 {
			if stepStatus == "interrupted" {
				store.AddInterruptedMessage(sessionID, fullText.String(), fullReasoning.String(), providerMeta, latencyMs)
			} else {
				store.AddMessageWithMetadata(sessionID, "assistant", fullText.String(), fullReasoning.String(), "",
					nil, nil, providerMeta, latencyMs)
			}
			if DelegateTrackerInstance != nil {
				DelegateTrackerInstance.UpdateActivity(sessionID)
			}
		}

		events.Publish(sse.NewSessionUpdatedEvent(sessionID))

		return // done
	}

	// Max turns exceeded
	stepStatus = "failed"
	emitAndStoreError(events, store, sessionID, fmt.Sprintf("Agent stopped: exceeded maximum of %d turns.", maxTurns))
}

// ─── Helpers ───────────────────────────────────────────────────────────

// emitAndStoreError publishes an error event, ends the text stream,
// stores the error message in the session, and emits a session update.
func emitAndStoreError(events *sse.EventBus, store session.Store, sessionID, text string) {
	events.Publish(sse.NewErrorEvent(sessionID, text))
	time.Sleep(EmitDelay)
	events.Publish(sse.NewTextEndedEvent(sessionID))
	store.AddMessage(sessionID, "assistant", text)
	events.Publish(sse.NewSessionUpdatedEvent(sessionID))
}

// getLastUserMessage returns the content of the most recent user message.
func getLastUserMessage(msgs []session.Message) string {
	for i := len(msgs) - 1; i >= 0; i-- {
		if msgs[i].Role == "user" {
			return msgs[i].Content
		}
	}
	return ""
}

// isTransientError returns true if the error is likely transient
// (connection, rate limit, or server error) and worth retrying.
func isTransientError(err error) bool {
	if err == nil {
		return false
	}
	msg := strings.ToLower(err.Error())
	transientKeywords := []string{
		"timeout", "rate limit", "too many requests",
		"503", "502", "429",
		"connection refused", "connection reset",
		"temporary", "try again", "service unavailable",
		"could not connect", "eof",
	}
	for _, kw := range transientKeywords {
		if strings.Contains(msg, kw) {
			return true
		}
	}
	return false
}

// buildLLMMessages builds the LLM chat messages including system prompt.
func buildLLMMessages(systemPrompt string, msgs []session.Message) []llm.ChatMessage {
	chatMsgs := make([]llm.ChatMessage, 0, len(msgs)+1)
	chatMsgs = append(chatMsgs, llm.ChatMessage{
		Role:    "system",
		Content: systemPrompt,
	})
	for _, m := range msgs {
		cm := llm.ChatMessage{
			Role:       m.Role,
			ToolCallID: m.ToolCallID,
		}
		if m.Content != "" || len(m.ToolCalls) == 0 {
			cm.Content = m.Content
		}
		if len(m.ToolCalls) > 0 {
			cm.ToolCalls = make([]llm.ToolCallData, len(m.ToolCalls))
			for i, tc := range m.ToolCalls {
				cm.ToolCalls[i] = llm.ToolCallData{
					ID:   tc.ID,
					Type: tc.Type,
					Function: llm.ToolCallFuncData{
						Name:      tc.Function.Name,
						Arguments: tc.Function.Arguments,
					},
				}
			}
		}
		chatMsgs = append(chatMsgs, cm)
	}
	return chatMsgs
}

// convertProperties converts tools.ToolProperty to llm.ToolProperty.
func convertProperties(props map[string]tools.ToolProperty) map[string]llm.ToolProperty {
	result := make(map[string]llm.ToolProperty, len(props))
	for k, v := range props {
		result[k] = llm.ToolProperty{
			Type:        v.Type,
			Description: v.Description,
			Enum:        v.Enum,
		}
	}
	return result
}

// convertToolCalls converts llm.ToolCallData to session.ToolCallData,
// initializing each tool call state to pending.
func convertToolCalls(tcs []llm.ToolCallData) []session.ToolCallData {
	result := make([]session.ToolCallData, len(tcs))
	for i, tc := range tcs {
		result[i] = session.ToolCallData{
			ID:   tc.ID,
			Type: tc.Type,
			Function: session.ToolCallFuncData{
				Name:      tc.Function.Name,
				Arguments: tc.Function.Arguments,
			},
			State: session.ToolCallPending,
		}
	}
	return result
}

// ─── Context Budget ────────────────────────────────────────────────────

// charsPerToken is the approximate number of characters per token (4:1 ratio).
const charsPerToken = 4

// EstimateTokens estimates the token count from text using a simple heuristic.
func EstimateTokens(text string) int {
	return len(text) / charsPerToken
}

// ContextBudget calculates how many tokens are available for the conversation.
type ContextBudget struct {
	ModelLimit     int // model's total context limit
	Buffer         int // safety buffer (20,000)
	Available      int // usable tokens (ModelLimit - Buffer)
	KeepTailTokens int // tokens reserved for recent messages (8,000)
}

// NewContextBudget creates a new ContextBudget for the given model limit.
func NewContextBudget(modelLimit int) *ContextBudget {
	return &ContextBudget{
		ModelLimit:     modelLimit,
		Buffer:         20000,
		KeepTailTokens: 8000,
		Available:      modelLimit - 20000,
	}
}

// ShouldCompact checks if the conversation needs compaction.
func (cb *ContextBudget) ShouldCompact(messages []session.Message) bool {
	total := 0
	for _, m := range messages {
		total += EstimateTokens(m.Content)
	}
	return total > cb.Available
}

// CompactMessages truncates older messages to fit within the context budget,
// replacing dropped messages with a structured summary of key information.
func CompactMessages(messages []session.Message, maxTokens int) []session.Message {
	total := 0
	keepIdx := 0
	for i, m := range messages {
		tokens := EstimateTokens(m.Content)
		if total+tokens > maxTokens {
			keepIdx = i
			break
		}
		total += tokens
	}
	if keepIdx == 0 {
		return messages
	}

	// Build structured summary from messages being dropped
	dropped := messages[:keepIdx]
	var summaryParts []string
	summaryParts = append(summaryParts, "[resumen de mensajes anteriores]")
	for _, m := range dropped {
		switch m.Role {
		case "user":
			content := m.Content
			if len(content) > 80 {
				content = content[:80] + "..."
			}
			summaryParts = append(summaryParts, "Usuario: "+content)
		case "assistant":
			if len(m.ToolCalls) > 0 {
				for _, tc := range m.ToolCalls {
					summaryParts = append(summaryParts, "→ Tool: "+tc.Function.Name)
				}
			} else if m.Content != "" {
				content := m.Content
				if len(content) > 100 {
					content = content[:100] + "..."
				}
				summaryParts = append(summaryParts, "→ "+content)
			}
		case "tool":
			content := m.Content
			if len(content) > 80 {
				content = content[:80] + "..."
			}
			summaryParts = append(summaryParts, "  Resultado: "+content)
		}
	}
	summary := strings.Join(summaryParts, "\n")
	if len(summary) > 2000 {
		summary = summary[:2000] + "\n... (resumen truncado)"
	}

	compacted := make([]session.Message, len(messages)-keepIdx+1)
	compacted[0] = session.Message{
		Role:    "system",
		Content: summary,
	}
	copy(compacted[1:], messages[keepIdx:])
	return compacted
}

// ─── Safe Tool Execution ──────────────────────────────────────────────

// safeExecuteTool ejecuta una tool con recover() para evitar que un pánico mate el engine.
// Es el wrapper que prepara la integración con SessionToolManager.
func safeExecuteTool(name string, args map[string]interface{}) (result string, err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("panic in tool '%s': %v", name, r)
			log.Printf("[FATAL] recovered from panic in tool %s: %v", name, r)
		}
	}()
	return tools.ExecuteTool(name, args)
}
