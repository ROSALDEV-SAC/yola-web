package agent

import (
	"encoding/json"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/config"
	"github.com/ROSALDEV-SAC/yola-core/db"
	"github.com/ROSALDEV-SAC/yola-core/session"
	"github.com/ROSALDEV-SAC/yola-core/sse"
	"github.com/ROSALDEV-SAC/yola-core/tools"
)

// ─── Status Types ──────────────────────────────────────────────────────────

// DelegationStatus represents the lifecycle state of a delegation.
type DelegationStatus string

const (
	DelegationRunning   DelegationStatus = "running"
	DelegationCompleted DelegationStatus = "completed"
	DelegationFailed    DelegationStatus = "failed"
	DelegationIdle      DelegationStatus = "idle"
	DelegationRetrieved DelegationStatus = "retrieved"
	DelegationCancelled DelegationStatus = "cancelled"
)

// DelegationInfo holds all state for a single delegation.
type DelegationInfo struct {
	ID              string           `json:"id"`
	AgentID         string           `json:"agentId"`
	Objective       string           `json:"objective"`
	ChildSessionID  string           `json:"childSessionId"`
	ParentSessionID string           `json:"parentSessionId"`
	Status          DelegationStatus `json:"status"`
	StartTime       time.Time        `json:"startTime"`
	LastActivity    time.Time        `json:"lastActivity"`
	MessageCount    int              `json:"messageCount"`
	Result          string           `json:"result,omitempty"`
	Error           string           `json:"error,omitempty"`
	CancelReason    string           `json:"cancelReason,omitempty"`
}

// ─── Tracker ───────────────────────────────────────────────────────────────

// DelegateTracker manages asynchronous delegations with a conscious monitor.
// The monitor NEVER kills sub-agents — it only marks them as idle.
// Sub-agent sessions ALWAYS persist in the database.
type DelegateTracker struct {
	mu     sync.RWMutex
	active map[string]*DelegationInfo

	store  session.Store
	events *sse.EventBus
	stop   chan struct{}

	// How long without new messages before marking idle (default 2min)
	IdleThreshold time.Duration
	// How often the monitor checks (default 10s)
	MonitorInterval time.Duration
}

// NewDelegateTracker creates a new tracker with the given store and event bus.
func NewDelegateTracker(store session.Store, events *sse.EventBus) *DelegateTracker {
	return &DelegateTracker{
		active:          make(map[string]*DelegationInfo),
		store:           store,
		events:          events,
		stop:            make(chan struct{}),
		IdleThreshold:   2 * time.Minute,
		MonitorInterval: 10 * time.Second,
	}
}

// Start launches the background monitor goroutine.
func (t *DelegateTracker) Start() { go t.monitorLoop() }

// Stop signals the monitor to stop.
func (t *DelegateTracker) Stop() { close(t.stop) }

// ─── CRUD ──────────────────────────────────────────────────────────────────

// Register adds a new delegation and returns its ID.
func (t *DelegateTracker) Register(info *DelegationInfo) string {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.active[info.ID] = info
	return info.ID
}

// Get returns a copy of the delegation info (safe for reading).
func (t *DelegateTracker) Get(id string) *DelegationInfo {
	t.mu.RLock()
	defer t.mu.RUnlock()
	info, ok := t.active[id]
	if !ok {
		return nil
	}
	cpy := *info
	return &cpy
}

// ListActive returns all non-terminal delegations.
func (t *DelegateTracker) ListActive() []*DelegationInfo {
	t.mu.RLock()
	defer t.mu.RUnlock()
	var result []*DelegationInfo
	for _, info := range t.active {
		if info.Status == DelegationRunning || info.Status == DelegationIdle {
			cpy := *info
			result = append(result, &cpy)
		}
	}
	return result
}

// UpdateActivity refreshes the lastActivity timestamp for a delegation by child
// session ID. Called when the sub-agent adds a message to its session.
func (t *DelegateTracker) UpdateActivity(childSessionID string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	for _, info := range t.active {
		if info.ChildSessionID == childSessionID {
			info.LastActivity = time.Now()
			msgs := t.store.GetMessages(childSessionID)
			info.MessageCount = len(msgs)
			return
		}
	}
}

// SetStatus updates the status and optionally result/error for a delegation.
func (t *DelegateTracker) SetStatus(id string, status DelegationStatus, result, errMsg string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	info, ok := t.active[id]
	if !ok {
		return
	}
	info.Status = status
	if result != "" {
		info.Result = result
	}
	if errMsg != "" {
		info.Error = errMsg
	}
}

// ─── Monitor ───────────────────────────────────────────────────────────────

func (t *DelegateTracker) monitorLoop() {
	ticker := time.NewTicker(t.MonitorInterval)
	defer ticker.Stop()
	for {
		select {
		case <-t.stop:
			return
		case <-ticker.C:
			t.checkIdle()
		}
	}
}

func (t *DelegateTracker) checkIdle() {
	t.mu.Lock()
	defer t.mu.Unlock()
	now := time.Now()
	for id, info := range t.active {
		if info.Status != DelegationRunning {
			continue
		}
		msgs := t.store.GetMessages(info.ChildSessionID)
		currentCount := len(msgs)
		if currentCount > info.MessageCount {
			info.MessageCount = currentCount
			info.LastActivity = now
			continue
		}
		if now.Sub(info.LastActivity) >= t.IdleThreshold {
			info.Status = DelegationIdle
			log.Printf("[Tracker] Delegation %s (%s) marked idle (no activity for %v)",
				id, info.AgentID, t.IdleThreshold)
			if t.events != nil {
				t.events.Publish(sse.NewToolProgressEvent(info.ParentSessionID, id, "delegate", "idle"))
			}
		}
	}
}

// ─── Tool Handlers ─────────────────────────────────────────────────────────

// DelegateHandler launches a sub-agent asynchronously and returns immediately.
// Expected args: agentId (req), objective (req), context (opt), sessionId (opt).
func (t *DelegateTracker) DelegateHandler(args map[string]interface{}) (string, error) {
	agentId, err := getStringArg(args, "agentId")
	if err != nil {
		return "", err
	}
	objective, err := getStringArg(args, "objective")
	if err != nil {
		return "", err
	}
	contextStr := getOptionalStringArg(args, "context")
	parentSessionID := getOptionalStringArg(args, "sessionId")

	svc := &DelegateServices
	if svc.ProviderKeys == nil || svc.SessionStore == nil {
		return "", fmt.Errorf("delegate: engine not fully initialized")
	}

	// 1. Look up agent config (providers.json first, then DB)
	cfg, ok := svc.ProviderKeys.GetAgent(agentId)
	if !ok && svc.AgentStore != nil {
		dbCfg, dbErr := svc.AgentStore.Get(agentId)
		if dbErr == nil && dbCfg != nil {
			cfg = &config.AgentDef{
				Name:         dbCfg.Name,
				Description:  dbCfg.Description,
				SystemPrompt: dbCfg.SystemPrompt,
				Model:        dbCfg.Model,
				Tools:        dbCfg.Tools,
				Skills:       dbCfg.Skills,
			}
			ok = true
		}
	}
	if !ok {
		return "", fmt.Errorf("agent '%s' not found. Available agents are registered in providers.json under 'agents'", agentId)
	}

	// 2. Resolve model
	modelID := cfg.Model
	if modelID == "" {
		modelID = "deepseek-v4-flash-free"
	}
	providerID := "opencode"
	if svc.Catalog != nil {
		for pid, p := range svc.Catalog.Raw() {
			if _, ok := p.Models[modelID]; ok {
				providerID = pid
				break
			}
		}
	}
	modelRef := config.ModelRef{ID: modelID, ProviderID: providerID}

	// 3. Build sub-agent — inherit config but disable further delegation
	subAgent := &Agent{
		ID:           agentId,
		Name:         cfg.Name,
		SystemPrompt: cfg.SystemPrompt,
		Model:        modelID,
		MaxTurns:     20,
		Tools:        cfg.Tools,
		Skills:       cfg.Skills,
		CanDelegate:  false,
		Metrics:      svc.Metrics,
		Memory:       svc.Memory,
	}

	// 4. Create child session
	title := "delegate: " + objective
	if len(title) > 80 {
		title = title[:80] + "..."
	}
	childSession := svc.SessionStore.Create(agentId, &modelRef, "")
	if childSession == nil {
		return "", fmt.Errorf("failed to create delegate session")
	}

	// 5. Add user message (objective + optional context)
	msgContent := objective
	if contextStr != "" {
		msgContent = "Context:\n" + contextStr + "\n\nObjective:\n" + objective
	}
	svc.SessionStore.AddMessage(childSession.ID, "user", msgContent)

	// 6. Generate delegation ID and register in tracker
	delID := db.NewID("del")
	info := &DelegationInfo{
		ID:              delID,
		AgentID:         agentId,
		Objective:       objective,
		ChildSessionID:  childSession.ID,
		ParentSessionID: parentSessionID,
		Status:          DelegationRunning,
		StartTime:       time.Now(),
		LastActivity:    time.Now(),
		MessageCount:    1, // user message was just added
	}
	t.mu.Lock()
	t.active[delID] = info
	t.mu.Unlock()

	log.Printf("[Tracker] Delegation %s: agent '%s' started for session %s (parent: %s)",
		delID, agentId, childSession.ID, parentSessionID)

	// Emit step started event (to parent session)
	if t.events != nil && parentSessionID != "" {
		stepID := "delegate:" + agentId
		t.events.Publish(sse.NewStepStartedEvent(parentSessionID, stepID, objective))
	}

	// 7. Launch sub-agent in background goroutine (no timeout — NEVER kill)
	go func(delID, childID, stepID string) {
		defer func() {
			if r := recover(); r != nil {
				errMsg := fmt.Sprintf("panic in sub-agent: %v", r)
				log.Printf("[Tracker] %s", errMsg)
				t.SetStatus(delID, DelegationFailed, "", errMsg)
				if t.events != nil && parentSessionID != "" {
					t.events.Publish(sse.NewStepEndedEvent(parentSessionID, stepID, "failed"))
				}
			}
		}()

		// Run sub-agent (blocks until completion)
		subAgent.Run(childID, svc.SessionStore, svc.EventBus, svc.LLMClient,
			svc.Catalog, svc.ProviderKeys.GetAPIKeys(), modelRef, svc.ProviderKeys)

		// Sub-agent finished — collect result from last assistant message
		msgs := svc.SessionStore.GetMessages(childID)
		var resultText string
		for i := len(msgs) - 1; i >= 0; i-- {
			if msgs[i].Role == "assistant" {
				resultText = msgs[i].Content
				break
			}
		}

		if resultText == "" {
			// Check session status for cancellation
			sessionObj := svc.SessionStore.Get(childID)
			if sessionObj != nil && sessionObj.Status == "cancelled" {
				t.SetStatus(delID, DelegationFailed, "", "sub-agent session was cancelled")
				log.Printf("[Tracker] Delegation %s: session was cancelled", delID)
			} else {
				t.SetStatus(delID, DelegationCompleted, "(no assistant response found)", "")
				log.Printf("[Tracker] Delegation %s: completed with no assistant response", delID)
			}
		} else {
			t.SetStatus(delID, DelegationCompleted, resultText, "")
			log.Printf("[Tracker] Delegation %s (%s) completed successfully", delID, agentId)
		}

		// Record decision in memory
		if svc.Memory != nil {
			svc.Memory.RecordDecision(
				childID, "", 0,
				"delegate called",
				fmt.Sprintf("Agent %s completed task: %s", agentId, objective),
				"delegate_executed",
				"", "delegate", "",
				contextStr, "completed", resultText, 0.5,
			)
		}

		// Emit step ended event
		if t.events != nil && parentSessionID != "" {
			status := "completed"
			if resultText == "" {
				status = "failed"
			}
			t.events.Publish(sse.NewStepEndedEvent(parentSessionID, stepID, status))
		}
	}(delID, childSession.ID, "delegate:"+agentId)

	// 8. Return immediately with delegation ID and status
	resultJSON, _ := json.Marshal(map[string]interface{}{
		"delegationId": delID,
		"status":       "running",
		"sessionId":    childSession.ID,
	})
	return string(resultJSON), nil
}

// CheckDelegationHandler returns the current status and recent messages of a delegation.
// Expected args: delegationId (req).
func (t *DelegateTracker) CheckDelegationHandler(args map[string]interface{}) (string, error) {
	delID, err := getStringArg(args, "delegationId")
	if err != nil {
		return "", err
	}

	info := t.Get(delID)
	if info == nil {
		return "", fmt.Errorf("delegation '%s' not found", delID)
	}

	// Gather last 3 messages from child session (truncated)
	var lastMessages []map[string]string
	if info.ChildSessionID != "" {
		msgs := t.store.GetMessages(info.ChildSessionID)
		start := len(msgs) - 3
		if start < 0 {
			start = 0
		}
		for i := start; i < len(msgs); i++ {
			content := msgs[i].Content
			if len(content) > 200 {
				content = content[:200] + "..."
			}
			lastMessages = append(lastMessages, map[string]string{
				"role":    msgs[i].Role,
				"content": content,
			})
		}
	}

	result := map[string]interface{}{
		"delegationId": info.ID,
		"status":       info.Status,
		"agentId":      info.AgentID,
		"objective":    info.Objective,
		"sessionId":    info.ChildSessionID,
		"messageCount": info.MessageCount,
		"lastActivity": info.LastActivity.Format(time.RFC3339),
		"lastMessages": lastMessages,
	}

	if info.Status == DelegationIdle {
		result["warning"] = fmt.Sprintf("no activity since %s", info.LastActivity.Format(time.RFC3339))
	}

	data, _ := json.Marshal(result)
	return string(data), nil
}

// RetrieveDelegationHandler returns the result of a completed delegation, or
// partial results if still running. The child session ALWAYS persists.
// Expected args: delegationId (req).
func (t *DelegateTracker) RetrieveDelegationHandler(args map[string]interface{}) (string, error) {
	delID, err := getStringArg(args, "delegationId")
	if err != nil {
		return "", err
	}

	info := t.Get(delID)
	if info == nil {
		return "", fmt.Errorf("delegation '%s' not found", delID)
	}

	result := map[string]interface{}{
		"delegationId": info.ID,
		"status":       info.Status,
		"sessionId":    info.ChildSessionID,
		"messageCount": info.MessageCount,
	}

	switch info.Status {
	case DelegationCompleted:
		result["result"] = info.Result

	case DelegationRunning, DelegationIdle:
		// Mark as retrieved — LLM gets what we have so far
		t.mu.Lock()
		info.Status = DelegationRetrieved
		t.mu.Unlock()

		if info.ChildSessionID != "" {
			msgs := t.store.GetMessages(info.ChildSessionID)
			for i := len(msgs) - 1; i >= 0; i-- {
				if msgs[i].Role == "assistant" {
					result["partialResult"] = msgs[i].Content
					break
				}
			}
		}

	case DelegationFailed, DelegationCancelled:
		result["error"] = info.Error
		if info.CancelReason != "" {
			result["cancelReason"] = info.CancelReason
		}
		// Include last activity from child session
		if info.ChildSessionID != "" {
			msgs := t.store.GetMessages(info.ChildSessionID)
			if len(msgs) > 0 {
				last := msgs[len(msgs)-1]
				result["lastActivity"] = last.Content
			}
		}

	case DelegationRetrieved:
		result["result"] = info.Result
	}

	data, _ := json.Marshal(result)
	return string(data), nil
}

// CancelDelegationHandler cancels a delegation. The child session is preserved.
// Expected args: delegationId (req), reason (opt).
func (t *DelegateTracker) CancelDelegationHandler(args map[string]interface{}) (string, error) {
	delID, err := getStringArg(args, "delegationId")
	if err != nil {
		return "", err
	}
	reason := getOptionalStringArg(args, "reason")

	info := t.Get(delID)
	if info == nil {
		return "", fmt.Errorf("delegation '%s' not found", delID)
	}

	t.mu.Lock()
	info.Status = DelegationCancelled
	info.CancelReason = reason
	info.Error = "cancelled by parent"
	t.mu.Unlock()

	log.Printf("[Tracker] Delegation %s cancelled (reason: %s)", delID, reason)

	result := map[string]interface{}{
		"delegationId": info.ID,
		"status":       DelegationCancelled,
		"sessionId":    info.ChildSessionID,
		"messageCount": info.MessageCount,
	}

	data, _ := json.Marshal(result)
	return string(data), nil
}

// ─── Tool Registration ────────────────────────────────────────────────────

// RegisterTools registers the four delegation tools in the global tool registry.
func (t *DelegateTracker) RegisterTools() {
	tools.Register(tools.Tool{
		Name:        "delegate",
		Description: "Assign a task to a sub-agent and continue working immediately. Returns a delegationId. Use check_delegation to monitor progress and retrieve_delegation to get results. NEVER cancel a sub-agent without first checking its progress.",
		Parameters: tools.ToolSchema{
			Type: "object",
			Properties: map[string]tools.ToolProperty{
				"agentId": {
					Type:        "string",
					Description: "ID of the specialized agent to delegate to (e.g. 'build', 'chat')",
				},
				"objective": {
					Type:        "string",
					Description: "Clear objective of the task for the sub-agent",
				},
				"context": {
					Type:        "string",
					Description: "Additional context for the sub-agent",
				},
			},
			Required: []string{"agentId", "objective"},
		},
		Handler: t.DelegateHandler,
	})

	tools.Register(tools.Tool{
		Name:        "check_delegation",
		Description: "Check the status of a running delegation. Returns current status, last activity time, message count, and recent messages from the sub-agent. Use this BEFORE deciding to cancel.",
		Parameters: tools.ToolSchema{
			Type: "object",
			Properties: map[string]tools.ToolProperty{
				"delegationId": {
					Type:        "string",
					Description: "The delegation ID returned by the delegate tool",
				},
			},
			Required: []string{"delegationId"},
		},
		Handler: t.CheckDelegationHandler,
	})

	tools.Register(tools.Tool{
		Name:        "retrieve_delegation",
		Description: "Retrieve the result from a delegation. If the sub-agent is still running, returns what it has so far. The sub-agent's session persists in the database and can be forked. Never cancel without checking first.",
		Parameters: tools.ToolSchema{
			Type: "object",
			Properties: map[string]tools.ToolProperty{
				"delegationId": {
					Type:        "string",
					Description: "The delegation ID returned by the delegate tool",
				},
			},
			Required: []string{"delegationId"},
		},
		Handler: t.RetrieveDelegationHandler,
	})

	tools.Register(tools.Tool{
		Name:        "cancel_delegation",
		Description: "Explicitly cancel a running delegation. Only use this AFTER checking the sub-agent's progress with check_delegation and retrieving partial results with retrieve_delegation. The sub-agent's session is preserved and can be used later via fork.",
		Parameters: tools.ToolSchema{
			Type: "object",
			Properties: map[string]tools.ToolProperty{
				"delegationId": {
					Type:        "string",
					Description: "The delegation ID returned by the delegate tool",
				},
				"reason": {
					Type:        "string",
					Description: "Optional reason for cancellation",
				},
			},
			Required: []string{"delegationId"},
		},
		Handler: t.CancelDelegationHandler,
	})
}

// DelegateTrackerInstance is the package-level singleton set by server.go wiring.
var DelegateTrackerInstance *DelegateTracker
