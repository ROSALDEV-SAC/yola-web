package agent

import (
	_ "embed"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/config"
	"github.com/ROSALDEV-SAC/yola-core/db"
	"github.com/ROSALDEV-SAC/yola-core/session"
	"github.com/ROSALDEV-SAC/yola-core/sse"
)

//go:embed prompt_engineer.md
var promptEngineer string

// ─── Params ────────────────────────────────────────────────────────────────

// TaskParams are the parameters for the task tool.
type TaskParams struct {
	Description  string `json:"description"`
	Prompt       string `json:"prompt"`
	SubagentType string `json:"subagent_type"`
	Background   bool   `json:"background,omitempty"`
	TaskID       string `json:"task_id,omitempty"`
}

// ─── Constants ──────────────────────────────────────────────────────────────

// defaultTaskTimeout is the default timeout for synchronous task execution.
const defaultTaskTimeout = 5 * time.Minute

// ─── Predefined Agent Configs ───────────────────────────────────────────────

// PredefinedAgentConfigs returns default configurations for agent types.
// Only used when no config exists in providers.json.
func PredefinedAgentConfigs() map[string]AgentConfig {
	return map[string]AgentConfig{
		"engineer": {
			ID:   "engineer",
			Name: "YOLA Engineer",
			Description: "Engineering agent. Reads, modifies, and verifies code with surgical precision.",
			SystemPrompt: promptEngineer,
			Model:    "",
			Tools:    []string{"read", "write", "edit", "bash", "glob", "grep", "search_symbol", "trace_imports", "code_rag"},
			MaxTurns: 30,
		},
		"explore": {
			ID:   "explore",
			Name: "Explore Agent",
			Description: "Read-only exploration agent. Investigates code, searches files, and reports findings. Cannot modify files or delegate.",
			SystemPrompt: `You are an exploration agent. Your only task is to investigate and report.
You can read files, search code, and explore the codebase.
You CANNOT modify any files, execute commands, or delegate to other agents.
Report your findings clearly and concisely.`,
			Model:    "",
			Tools:    []string{"read", "glob", "grep", "search_symbol", "trace_imports", "code_rag"},
			MaxTurns: 15,
		},
		"general": {
			ID:   "general",
			Name: "General Purpose Agent",
			Description: "General-purpose agent for most tasks. Can read, write, edit files, execute commands, and delegate to other agents.",
			SystemPrompt: `You are a general-purpose engineering agent.
You can read, write, and edit files, execute shell commands, search code, and delegate tasks to specialized agents.
Be thorough, verify your work, and report results clearly.`,
			Model:    "",
			Tools:    []string{"read", "write", "edit", "bash", "glob", "grep", "search_symbol", "trace_imports", "code_rag", "task"},
			MaxTurns: 25,
		},
		"yola": {
			ID:   "yola",
			Name: "YOLA Agent",
			Description: "Primary engineering agent with full tool access. Can delegate to specialized sub-agents.",
			SystemPrompt: `Soy YOLA, asistente ejecutivo de ingeniería. Formal, preciso, proactivo.
Trabajo con herramientas de archivo, bash, búsqueda semántica y delegación.
Ante un error: diagnostico causa raíz, propongo solución mínima, ejecuto y verifico.`,
			Model:    "",
			Tools:    []string{"read", "write", "edit", "bash", "glob", "grep", "search_symbol", "trace_imports", "code_rag", "delegate", "task"},
			MaxTurns: 30,
		},
		"build": {
			ID:   "build",
			Name: "Build Agent",
			Description: "Build and deployment automation agent. Runs build commands, tests, and deployment scripts.",
			SystemPrompt: `You are a build automation agent. Your job is to build, test, and deploy code.
Focus on running build commands, interpreting compiler errors, running tests, and deploying artifacts.`,
			Model:    "",
			Tools:    []string{"bash", "read", "glob", "grep"},
			MaxTurns: 20,
		},
		"chat": {
			ID:   "chat",
			Name: "Chat",
			Description: "Simple conversational agent without tools.",
			SystemPrompt: "You are a helpful assistant.",
			Model:    "",
			Tools:    []string{},
			MaxTurns: 10,
		},
	}
}

// ─── Agent Type Resolution ─────────────────────────────────────────────────

// AgentTypeConfig resolves the config for a subagent_type.
// Priority: providers.json > predefined configs.
func AgentTypeConfig(agentType string, svc *DelegateService) *AgentConfig {
	// 1. Try providers.json
	if svc != nil && svc.ProviderKeys != nil {
		if def, ok := svc.ProviderKeys.GetAgent(agentType); ok {
			ac := &AgentConfig{
				ID:           agentType,
				Name:         def.Name,
				Description:  def.Description,
				SystemPrompt: def.SystemPrompt,
				Model:        def.Model,
				Tools:        def.Tools,
				Skills:       def.Skills,
				MaxTurns:     20,
			}
			return ac
		}
	}

	// 2. Try DB agent store
	if svc != nil && svc.AgentStore != nil {
		dbCfg, err := svc.AgentStore.Get(agentType)
		if err == nil && dbCfg != nil {
			return dbCfg
		}
	}

	// 3. Fallback to predefined
	predefined := PredefinedAgentConfigs()
	if cfg, ok := predefined[agentType]; ok {
		return &cfg
	}

	return nil
}

// ─── Valid Agent Types ─────────────────────────────────────────────────────

// canDelegate returns true if the agent type is allowed to use the task tool.
func canDelegate(agentType string) bool {
	switch agentType {
	case "explore", "chat":
		return false
	default:
		return true
	}
}

// ─── Task Handler Factory ──────────────────────────────────────────────────

// TaskHandlerFactory creates the handler for the task tool.
// It wraps DelegateTracker to provide both sync and async sub-agent execution
// with session forking for context inheritance.
func TaskHandlerFactory(svc *DelegateService) func(map[string]interface{}) (string, error) {
	return func(args map[string]interface{}) (string, error) {
		// 1. Parse args
		description, _ := getStringArg(args, "description")
		prompt, _ := getStringArg(args, "prompt")
		subagentType := getOptionalStringArg(args, "subagent_type")
		background := getOptionalBoolArg(args, "background", false)
		taskID := getOptionalStringArg(args, "task_id")
		parentSessionID := getOptionalStringArg(args, "sessionId")

		// Validate required fields
		if description == "" {
			return "", fmt.Errorf("task: 'description' is required")
		}
		if prompt == "" {
			return "", fmt.Errorf("task: 'prompt' is required")
		}
		if subagentType == "" {
			subagentType = "general"
		}

		// 2. Validate agent type
		cfg := AgentTypeConfig(subagentType, svc)
		if cfg == nil {
			return "", fmt.Errorf("task: unknown agent type '%s'. Available types: prototyper, builder, sweeper, grower, maintainer, mason, gardener, blacksmith, bear-killer, chef, teacher, philosopher, guide, designer, writer, explore, general, yola, build, chat", subagentType)
		}

		// 3. Check if this agent can delegate (for task tool)
		if !canDelegate(subagentType) {
			return "", fmt.Errorf("task: agent type '%s' cannot launch sub-agents (task tool restricted). Use 'general' or 'yola' instead", subagentType)
		}

		if svc == nil || svc.SessionStore == nil || svc.ProviderKeys == nil {
			return "", fmt.Errorf("task: engine not fully initialized")
		}

		// 4. Resolve model
		modelID := cfg.Model
		if modelID == "" {
			modelID = "deepseek-v4-flash-free"
		}
		providerID := "opencode"
		if svc.Catalog != nil {
			for pid, p := range svc.Catalog.Raw() {
				if _, ok := p.Models[modelID]; ok {
					providerID = pid
					break
				}
			}
		}
		modelRef := config.ModelRef{ID: modelID, ProviderID: providerID}

		// 5. Build sub-agent — inherit config, disable further delegation for non-yola
		subAgent := &Agent{
			ID:           subagentType,
			Name:         cfg.Name,
			SystemPrompt: cfg.SystemPrompt,
			Model:        modelID,
			MaxTurns:     cfg.MaxTurns,
			Tools:        cfg.Tools,
			Skills:       cfg.Skills,
			CanDelegate:  canDelegate(subagentType) && subagentType == "yola",
			Metrics:      svc.Metrics,
			Memory:       svc.Memory,
		}
		if subAgent.MaxTurns <= 0 {
			subAgent.MaxTurns = 20
		}

		// 6. Create child session via Fork (inherit parent context)
		var childSession *session.Session
		if parentSessionID != "" {
			childSession = svc.SessionStore.Fork(parentSessionID)
		}
		if childSession == nil {
			childSession = svc.SessionStore.Create(subagentType, &modelRef, "")
		}
		if childSession == nil {
			return "", fmt.Errorf("task: failed to create sub-agent session")
		}

		// Mark as sub-agent session for UI
		if childSession != nil {
			subTitle := "(" + description + " @" + subagentType + " subagent)"
			svc.SessionStore.UpdateSession(childSession.ID, subTitle, "")
		}

		// 7. Add the prompt as user message
		msgContent := prompt
		if description != "" {
			msgContent = "Task: " + description + "\n\n" + prompt
		}
		svc.SessionStore.AddMessage(childSession.ID, "user", msgContent)

		// 8. Generate task ID
		if taskID == "" {
			taskID = db.NewID("task")
		}

		// 9. Register with DelegateTracker if available
		tracker := DelegateTrackerInstance
		if tracker != nil {
			info := &DelegationInfo{
				ID:              taskID,
				AgentID:         subagentType,
				Objective:       description,
				ChildSessionID:  childSession.ID,
				ParentSessionID: parentSessionID,
				Status:          DelegationRunning,
				StartTime:       time.Now(),
				LastActivity:    time.Now(),
				MessageCount:    1,
			}
			tracker.Register(info)
		}

		// 10. Emit task started event
		if svc.EventBus != nil && parentSessionID != "" {
			svc.EventBus.Publish(sse.Event{
				Type: sse.EventTaskStarted,
				Data: map[string]interface{}{
					"sessionId": parentSessionID,
					"taskId":    taskID,
					"agentType": subagentType,
					"description": description,
				},
			})
		}

		// 11. Launch sub-agent in goroutine
		done := make(chan struct {
			result string
			err    string
		}, 1)

		emitTaskEvent := func(eventType, taskID, description, result, errMsg string) {
			if svc.EventBus == nil || parentSessionID == "" {
				return
			}
			svc.EventBus.Publish(sse.Event{
				Type: eventType,
				Data: map[string]interface{}{
					"sessionId":   parentSessionID,
					"taskId":      taskID,
					"agentType":   subagentType,
					"description": description,
					"result":      truncateString(result, 500),
					"error":       errMsg,
				},
			})
		}

		go func(taskID, childID, agentType, desc string) {
			defer func() {
				if r := recover(); r != nil {
					errMsg := fmt.Sprintf("panic in sub-agent: %v", r)
					log.Printf("[Task] %s", errMsg)
					if tracker != nil {
						tracker.SetStatus(taskID, DelegationFailed, "", errMsg)
					}
					emitTaskEvent(sse.EventTaskFailed, taskID, desc, "", errMsg)
					if !background {
						done <- struct {
							result string
							err    string
						}{"", errMsg}
					}
				}
			}()

			// Run sub-agent (blocks until completion)
			subAgent.Run(childID, svc.SessionStore, svc.EventBus, svc.LLMClient,
				svc.Catalog, svc.ProviderKeys.GetAPIKeys(), modelRef, svc.ProviderKeys)

			// Collect result from last assistant message
			msgs := svc.SessionStore.GetMessages(childID)
			var resultText string
			for i := len(msgs) - 1; i >= 0; i-- {
				if msgs[i].Role == "assistant" {
					resultText = msgs[i].Content
					break
				}
			}

			if resultText == "" {
				sessionObj := svc.SessionStore.Get(childID)
				if sessionObj != nil && sessionObj.Status == "cancelled" {
					if tracker != nil {
						tracker.SetStatus(taskID, DelegationFailed, "", "sub-agent session was cancelled")
					}
					emitTaskEvent(sse.EventTaskFailed, taskID, desc, "", "sub-agent session was cancelled")
					if !background {
						done <- struct {
							result string
							err    string
						}{"", "sub-agent session was cancelled"}
					}
					return
				}
				resultText = "(no assistant response)"
			}

			if tracker != nil {
				tracker.SetStatus(taskID, DelegationCompleted, resultText, "")
			}

			log.Printf("[Task] %s (%s) completed for session %s", taskID, agentType, parentSessionID)
			emitTaskEvent(sse.EventTaskCompleted, taskID, desc, resultText, "")

			if !background {
				done <- struct {
					result string
					err    string
				}{resultText, ""}
			}
		}(taskID, childSession.ID, subagentType, description)

		// 12. Sync vs Async
		if background {
			// Async: return immediately
			resultJSON, _ := json.Marshal(map[string]interface{}{
				"taskId":    taskID,
				"status":    "running",
				"sessionId": childSession.ID,
				"message":   fmt.Sprintf("Task launched in background. Use task ID '%s' to check status.", taskID),
			})
			return string(resultJSON), nil
		}

		// Sync: wait for completion with timeout
		select {
		case res := <-done:
			if res.err != "" {
				return "", fmt.Errorf("task %s failed: %s", taskID, res.err)
			}

			resultJSON, _ := json.Marshal(map[string]interface{}{
				"taskId":    taskID,
				"status":    "completed",
				"sessionId": childSession.ID,
				"result":    res.result,
			})
			return string(resultJSON), nil

		case <-time.After(defaultTaskTimeout):
			// Timeout — mark as idle (not failed, sub-agent keeps running)
			if tracker != nil {
				tracker.SetStatus(taskID, DelegationIdle, "", "timeout")
			}
			emitTaskEvent(sse.EventTaskFailed, taskID, description, "",
				fmt.Sprintf("timeout after %v (sub-agent continues in background)", defaultTaskTimeout))

			return "", fmt.Errorf("task %s: timeout after %v (sub-agent continues in background, session: %s)", taskID, defaultTaskTimeout, childSession.ID)
		}
	}
}

// ─── Helpers ────────────────────────────────────────────────────────────────

// getOptionalBoolArg returns an optional bool argument with a default value.
func getOptionalBoolArg(args map[string]interface{}, key string, defaultVal bool) bool {
	v, ok := args[key]
	if !ok {
		return defaultVal
	}
	b, ok := v.(bool)
	if !ok {
		return defaultVal
	}
	return b
}

// truncateString truncates a string to the given length.
func truncateString(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen] + "..."
}
