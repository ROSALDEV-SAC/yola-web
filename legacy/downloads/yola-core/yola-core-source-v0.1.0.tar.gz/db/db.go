package db

import (
	"context"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"

	_ "modernc.org/sqlite"
)

// Database wraps a SQLite connection with WAL mode and foreign keys enabled.
type Database struct {
	DB *sql.DB
}

// NewDatabase opens (or creates) a SQLite database at dbPath, enables WAL mode
// and foreign keys, and creates the schema tables if they don't exist.
func NewDatabase(dbPath string) (*Database, error) {
	dir := filepath.Dir(dbPath)
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, fmt.Errorf("create db dir: %w", err)
	}

	db, err := sql.Open("sqlite", dbPath)
	if err != nil {
		return nil, fmt.Errorf("open db: %w", err)
	}

	// Enable WAL mode for better concurrent reads
	if _, err := db.Exec("PRAGMA journal_mode=WAL"); err != nil {
		db.Close()
		return nil, fmt.Errorf("enable WAL: %w", err)
	}

	// Prevent "database is locked" errors under concurrent access
	if _, err := db.Exec("PRAGMA busy_timeout=5000"); err != nil {
		db.Close()
		return nil, fmt.Errorf("set busy_timeout: %w", err)
	}

	// Enable foreign key enforcement
	if _, err := db.Exec("PRAGMA foreign_keys=ON"); err != nil {
		db.Close()
		return nil, fmt.Errorf("enable foreign keys: %w", err)
	}

	if err := createTables(db); err != nil {
		db.Close()
		return nil, fmt.Errorf("create tables: %w", err)
	}
	if err := migrateSchema(db); err != nil {
		db.Close()
		return nil, fmt.Errorf("schema migration: %w", err)
	}

	return &Database{DB: db}, nil
}

// Close closes the underlying database connection.
func (d *Database) Close() error {
	return d.DB.Close()
}

// ExecContext executes a query with the given context.
func (d *Database) ExecContext(ctx context.Context, query string, args ...interface{}) (sql.Result, error) {
	return d.DB.ExecContext(ctx, query, args...)
}

// QueryContext executes a query that returns rows with the given context.
func (d *Database) QueryContext(ctx context.Context, query string, args ...interface{}) (*sql.Rows, error) {
	return d.DB.QueryContext(ctx, query, args...)
}

// QueryRowContext executes a query that returns at most one row with the given context.
func (d *Database) QueryRowContext(ctx context.Context, query string, args ...interface{}) *sql.Row {
	return d.DB.QueryRowContext(ctx, query, args...)
}

// Exec is a backward-compatible wrapper that uses context.Background().
func (d *Database) Exec(query string, args ...interface{}) (sql.Result, error) {
	return d.ExecContext(context.Background(), query, args...)
}

// Query is a backward-compatible wrapper that uses context.Background().
func (d *Database) Query(query string, args ...interface{}) (*sql.Rows, error) {
	return d.QueryContext(context.Background(), query, args...)
}

// QueryRow is a backward-compatible wrapper that uses context.Background().
func (d *Database) QueryRow(query string, args ...interface{}) *sql.Row {
	return d.QueryRowContext(context.Background(), query, args...)
}

// NewID generates a unique identifier with the given prefix.
func NewID(prefix string) string {
	b := make([]byte, 12)
	rand.Read(b)
	return prefix + "_" + hex.EncodeToString(b)
}

// GetRecentLearnings returns the most recent learnings, newest first.
func (d *Database) GetRecentLearnings(limit int) ([]map[string]string, error) {
	rows, err := d.DB.Query(
		`SELECT content, tags FROM learnings ORDER BY created_at DESC LIMIT ?`, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var results []map[string]string
	for rows.Next() {
		var content, tags string
		if err := rows.Scan(&content, &tags); err != nil {
			continue
		}
		results = append(results, map[string]string{"content": content, "tags": tags})
	}
	return results, nil
}

// ─── Schema ──────────────────────────────────────────────────────────────

func createTables(db *sql.DB) error {
	schema := `
	CREATE TABLE IF NOT EXISTS sessions (
		id TEXT PRIMARY KEY,
		parent_id TEXT,
		workspace_id TEXT,
		title TEXT NOT NULL DEFAULT '',
		agent TEXT,
		model TEXT,
		status TEXT NOT NULL DEFAULT 'active',
		created_at INTEGER NOT NULL,
		updated_at INTEGER NOT NULL
	);

	CREATE TABLE IF NOT EXISTS messages (
		id TEXT PRIMARY KEY,
		session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
		role TEXT NOT NULL,
		content TEXT NOT NULL DEFAULT '',
		tool_call_id TEXT,
		tool_calls TEXT,
		created_at INTEGER NOT NULL
	);

	CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, created_at);
	CREATE INDEX IF NOT EXISTS idx_sessions_updated ON sessions(updated_at);
	CREATE INDEX IF NOT EXISTS idx_sessions_workspace ON sessions(workspace_id);

	CREATE TABLE IF NOT EXISTS workspaces (
		id TEXT PRIMARY KEY,
		path TEXT UNIQUE NOT NULL,
		name TEXT NOT NULL DEFAULT '',
		added_at INTEGER NOT NULL,
		last_used_at INTEGER NOT NULL DEFAULT 0
	);

	CREATE TABLE IF NOT EXISTS learnings (
		id TEXT PRIMARY KEY,
		content TEXT NOT NULL,
		tags TEXT,
		source TEXT,
		session_id TEXT,
		created_at INTEGER NOT NULL
	);
	CREATE INDEX IF NOT EXISTS idx_learnings_created ON learnings(created_at);

	CREATE TABLE IF NOT EXISTS skills (
		id TEXT PRIMARY KEY,
		name TEXT UNIQUE NOT NULL,
		description TEXT NOT NULL DEFAULT '',
		command TEXT NOT NULL DEFAULT '',
		created_at INTEGER NOT NULL,
		updated_at INTEGER NOT NULL
	);

	CREATE TABLE IF NOT EXISTS agent_configs (
		id TEXT PRIMARY KEY,
		name TEXT NOT NULL,
		system_prompt TEXT NOT NULL DEFAULT '',
		model TEXT NOT NULL DEFAULT '',
		tools TEXT NOT NULL DEFAULT '[]',
		skills TEXT NOT NULL DEFAULT '[]',
		max_turns INTEGER NOT NULL DEFAULT 20,
		temperature REAL NOT NULL DEFAULT 0.7,
		provider TEXT DEFAULT '',
		created_at INTEGER NOT NULL,
		updated_at INTEGER NOT NULL
	);

	CREATE TABLE IF NOT EXISTS working_memory (
		session_id TEXT NOT NULL,
		key TEXT NOT NULL,
		value TEXT NOT NULL DEFAULT '',
		created_at INTEGER NOT NULL,
		updated_at INTEGER NOT NULL,
		PRIMARY KEY (session_id, key)
	);

	CREATE TABLE IF NOT EXISTS episodic_memory (
		id TEXT PRIMARY KEY,
		observation TEXT NOT NULL,
		action TEXT NOT NULL DEFAULT '',
		outcome TEXT NOT NULL DEFAULT '',
		context TEXT DEFAULT '',
		tags TEXT DEFAULT '',
		importance REAL NOT NULL DEFAULT 1.0,
		session_id TEXT DEFAULT '' REFERENCES sessions(id) ON DELETE CASCADE,
		workspace_id TEXT DEFAULT '' REFERENCES workspaces(id) ON DELETE SET NULL,
		created_at INTEGER NOT NULL
	);
	CREATE INDEX IF NOT EXISTS idx_episodic_created ON episodic_memory(created_at);
	CREATE INDEX IF NOT EXISTS idx_episodic_session ON episodic_memory(session_id);

	CREATE TABLE IF NOT EXISTS semantic_memory (
		id TEXT PRIMARY KEY,
		content TEXT NOT NULL,
		source TEXT DEFAULT '',
		confidence REAL NOT NULL DEFAULT 0.5,
		tags TEXT DEFAULT '',
		episode_id TEXT DEFAULT '' REFERENCES episodic_memory(id) ON DELETE SET NULL,
		created_at INTEGER NOT NULL,
		last_accessed_at INTEGER NOT NULL,
		access_count INTEGER NOT NULL DEFAULT 0
	);
	CREATE INDEX IF NOT EXISTS idx_semantic_confidence ON semantic_memory(confidence);
	CREATE INDEX IF NOT EXISTS idx_semantic_accessed ON semantic_memory(last_accessed_at);

	CREATE TABLE IF NOT EXISTS policy_rules (
		id TEXT PRIMARY KEY,
		layer TEXT NOT NULL,
		name TEXT NOT NULL,
		action TEXT NOT NULL,
		resource TEXT NOT NULL,
		effect TEXT NOT NULL,
		priority INTEGER DEFAULT 0,
		enabled INTEGER DEFAULT 1,
		created_at INTEGER NOT NULL
	);
	CREATE INDEX IF NOT EXISTS idx_policy_layer ON policy_rules(layer, enabled);

	CREATE TABLE IF NOT EXISTS decision_journal (
		id TEXT PRIMARY KEY,
		session_id TEXT,
		workspace_id TEXT,
		turn INTEGER,
		observation TEXT NOT NULL,
		inference TEXT,
		decision TEXT NOT NULL,
		alternatives TEXT,
		outcome TEXT,
		outcome_detail TEXT,
		tool_name TEXT,
		tool_args TEXT,
		context TEXT,
		importance REAL DEFAULT 0.5,
		created_at INTEGER NOT NULL
	);
	CREATE INDEX IF NOT EXISTS idx_decision_session ON decision_journal(session_id);
	CREATE INDEX IF NOT EXISTS idx_decision_created ON decision_journal(created_at);

	CREATE TABLE IF NOT EXISTS user_profiles (
		id TEXT PRIMARY KEY,
		preferred_language TEXT DEFAULT '',
		preferred_model TEXT DEFAULT '',
		skill_level TEXT DEFAULT 'intermediate',
		common_tasks TEXT DEFAULT '[]',
		feedback_patterns TEXT DEFAULT '[]',
		knowledge_areas TEXT DEFAULT '[]',
		interaction_count INTEGER DEFAULT 0,
		last_active_at INTEGER,
		created_at INTEGER NOT NULL,
		updated_at INTEGER NOT NULL,
		territory TEXT DEFAULT '',
		onboarding_purpose TEXT DEFAULT ''
	);

	CREATE TABLE IF NOT EXISTS proposals (
		id TEXT PRIMARY KEY,
		title TEXT NOT NULL,
		description TEXT NOT NULL DEFAULT '',
		context TEXT DEFAULT '',
		analysis TEXT DEFAULT '',
		plan_text TEXT DEFAULT '',
		status TEXT NOT NULL DEFAULT 'draft',
		priority TEXT NOT NULL DEFAULT 'medium',
		agent_type TEXT DEFAULT '',
		session_id TEXT DEFAULT '' REFERENCES sessions(id) ON DELETE SET NULL,
		decision_id TEXT DEFAULT '' REFERENCES decisions(id) ON DELETE SET NULL,
		tags TEXT DEFAULT '[]',
		created_at INTEGER NOT NULL,
		updated_at INTEGER NOT NULL
	);
	CREATE INDEX IF NOT EXISTS idx_proposals_status ON proposals(status);
	CREATE INDEX IF NOT EXISTS idx_proposals_updated ON proposals(updated_at);
	`
	_, err := db.Exec(schema)
	return err
}

// migrateSchema applies any schema changes that require ALTER TABLE.
func migrateSchema(db *sql.DB) error {
	type migration struct {
		table  string
		column string
		stmt   string
	}
	migrations := []migration{
		{table: "sessions", column: "workspace_id", stmt: `ALTER TABLE sessions ADD COLUMN workspace_id TEXT`},
		{table: "episodic_memory", column: "session_id", stmt: `ALTER TABLE episodic_memory ADD COLUMN session_id TEXT DEFAULT '' REFERENCES sessions(id) ON DELETE CASCADE`},
		{table: "episodic_memory", column: "workspace_id", stmt: `ALTER TABLE episodic_memory ADD COLUMN workspace_id TEXT DEFAULT '' REFERENCES workspaces(id) ON DELETE SET NULL`},
		{table: "semantic_memory", column: "episode_id", stmt: `ALTER TABLE semantic_memory ADD COLUMN episode_id TEXT DEFAULT '' REFERENCES episodic_memory(id) ON DELETE SET NULL`},
		{table: "proposals", column: "session_id", stmt: `ALTER TABLE proposals ADD COLUMN session_id TEXT DEFAULT '' REFERENCES sessions(id) ON DELETE SET NULL`},
		{table: "proposals", column: "decision_id", stmt: `ALTER TABLE proposals ADD COLUMN decision_id TEXT DEFAULT '' REFERENCES decisions(id) ON DELETE SET NULL`},
		{table: "user_profiles", column: "territory", stmt: `ALTER TABLE user_profiles ADD COLUMN territory TEXT DEFAULT ''`},
		{table: "user_profiles", column: "onboarding_purpose", stmt: `ALTER TABLE user_profiles ADD COLUMN onboarding_purpose TEXT DEFAULT ''`},
		{table: "agent_configs", column: "provider", stmt: `ALTER TABLE agent_configs ADD COLUMN provider TEXT DEFAULT ''`},
		{table: "messages", column: "reasoning", stmt: `ALTER TABLE messages ADD COLUMN reasoning TEXT DEFAULT ''`},
		{table: "messages", column: "interrupted", stmt: `ALTER TABLE messages ADD COLUMN interrupted INTEGER NOT NULL DEFAULT 0`},
	}
	for _, m := range migrations {
		exists, err := columnExists(db, m.table, m.column)
		if err != nil {
			return fmt.Errorf("check column %s.%s: %w", m.table, m.column, err)
		}
		if exists {
			continue
		}
		if _, err := db.Exec(m.stmt); err != nil {
			return fmt.Errorf("migrate %s.%s: %w", m.table, m.column, err)
		}
	}
	return nil
}

// columnExists checks whether a column exists in a table using PRAGMA table_info.
func columnExists(db *sql.DB, table, column string) (bool, error) {
	rows, err := db.Query("PRAGMA table_info(" + table + ")")
	if err != nil {
		return false, err
	}
	defer rows.Close()
	for rows.Next() {
		var cid int
		var name, ctype string
		var notnull int
		var dflt sql.NullString
		var pk int
		if err := rows.Scan(&cid, &name, &ctype, &notnull, &dflt, &pk); err != nil {
			return false, err
		}
		if name == column {
			return true, nil
		}
	}
	return false, rows.Err()
}
