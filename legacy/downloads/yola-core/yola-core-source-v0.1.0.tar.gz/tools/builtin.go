package tools

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/sse"
)

// ─── Init ────────────────────────────────────────────────────────────────

func init() {
	// workDir is set later by workspace restoreCurrent or main.go
	wd, err := os.Getwd()
	if err != nil {
		home, hErr := os.UserHomeDir()
		if hErr != nil {
			workDir = "."
		} else {
			workDir = home
		}
	} else {
		workDir = wd
	}
	rebuildAllowedPrefixes(workDir)

	registry = make(map[string]Tool, 8)
	// Delegate tool is registered separately via SetDelegateHandler
	for _, t := range []Tool{
		buildReadTool(),
		buildWriteTool(),
		buildEditTool(),
		buildBashTool(),
		buildGlobTool(),
		buildGrepTool(),
		buildCodeRagTool(),
	} {
		registry[t.Name] = t
	}
}

// ─── Argument Helpers ────────────────────────────────────────────────────

func getStringArg(args map[string]interface{}, key string) (string, error) {
	v, ok := args[key]
	if !ok {
		return "", fmt.Errorf("missing required argument '%s'", key)
	}
	s, ok := v.(string)
	if !ok {
		return "", fmt.Errorf("argument '%s' must be a string, got %T", key, v)
	}
	return s, nil
}

func getOptionalStringArg(args map[string]interface{}, key string) string {
	v, ok := args[key]
	if !ok {
		return ""
	}
	s, _ := v.(string)
	return s
}

func getIntArg(args map[string]interface{}, key string, defaultVal int) int {
	v, ok := args[key]
	if !ok {
		return defaultVal
	}
	switch n := v.(type) {
	case float64:
		return int(n)
	case int:
		return n
	case int64:
		return int(n)
	default:
		return defaultVal
	}
}

func getBoolArg(args map[string]interface{}, key string, defaultVal bool) bool {
	v, ok := args[key]
	if !ok {
		return defaultVal
	}
	b, ok := v.(bool)
	if !ok {
		return defaultVal
	}
	return b
}

// ─── Execution Engine ────────────────────────────────────────────────────

// ExecuteTool runs a tool by name with the given arguments.
// It returns the tool's output as a string, or an error if the tool is not found
// or the handler fails.
func ExecuteTool(name string, args map[string]interface{}) (string, error) {
	regMu.RLock()
	tool, ok := registry[name]
	regMu.RUnlock()

	if !ok {
		if MCPManager != nil && MCPManager.HasTool(name) {
			return MCPManager.CallTool(name, args)
		}
		return "", fmt.Errorf("tool '%s' not found", name)
	}

	return tool.Handler(args)
}

// SetDelegateHandler registers the delegate tool handler (called from main.go wiring).
func SetDelegateHandler(fn ToolHandler) {
	regMu.Lock()
	defer regMu.Unlock()
	registry["delegate"] = Tool{
		Name:        "delegate",
		Description: "Delegate a task to a specialized sub-agent.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"agentId": {
					Type:        "string",
					Description: "ID of the specialized agent to delegate to (e.g. 'build', 'chat')",
				},
				"objective": {
					Type:        "string",
					Description: "Clear objective of the task for the sub-agent",
				},
				"context": {
					Type:        "string",
					Description: "Additional context for the sub-agent",
				},
				"timeout": {
					Type:        "number",
					Description: "Timeout in seconds (default: 300 = 5 minutes)",
				},
			},
			Required: []string{"agentId", "objective"},
		},
		Handler: fn,
	}
}

// SetTaskHandler registers the task tool handler (called from server.go wiring).
func SetTaskHandler(fn ToolHandler) {
	regMu.Lock()
	defer regMu.Unlock()
	registry["task"] = Tool{
		Name:        "task",
		Description: "Launch a sub-agent to handle a complex task. Use for multi-step work that benefits from a focused agent. Default is synchronous (waits for result); use background=true for fire-and-forget.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"description": {
					Type:        "string",
					Description: "Short description of the task objective",
				},
				"prompt": {
					Type:        "string",
					Description: "Detailed instructions for the sub-agent",
				},
			"subagent_type": {
				Type:        "string",
				Description: "Type of agent to launch. Available types: prototyper (ideas, prototypes), builder (production-grade code), sweeper (cleanup, optimization), grower (growth, iteration), maintainer (stability, security), mason (foundations, architecture), gardener (exploration, discovery), blacksmith (repair, debt reduction), bear-killer (crisis, critical bugs), chef (cohesion, integration), teacher (explanations, tutoring), philosopher (purpose, ethics), guide (onboarding, orientation), designer (UI/UX, visual), writer (documentation, copy), explore (read-only search), general (purpose tasks), yola (full agent), build (build/deploy), chat (conversational)",
			},
				"background": {
					Type:        "boolean",
					Description: "Run in background and return immediately (default: false, waits for completion)",
				},
				"task_id": {
					Type:        "string",
					Description: "Optional explicit task ID for tracking",
				},
			},
			Required: []string{"description", "prompt"},
		},
		Handler: fn,
	}
}

// ─── Tool: read ─────────────────────────────────────────────────────────

func buildReadTool() Tool {
	return Tool{
		Name:        "read",
		Description: "Read the contents of a file. Returns the file content or an error message. Use for configuration files, source code, logs, etc.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"filePath": {
					Type:        "string",
					Description: "The absolute path to the file to read",
				},
				"offset": {
					Type:        "number",
					Description: "Starting line number (1-indexed, optional)",
				},
				"limit": {
					Type:        "number",
					Description: "Max lines to read (optional, default 2000)",
				},
			},
			Required: []string{"filePath"},
		},
		Handler: readHandler,
	}
}

func readHandler(args map[string]interface{}) (string, error) {
	filePath, err := getStringArg(args, "filePath")
	if err != nil {
		return "", err
	}
	offset := getIntArg(args, "offset", 0)
	limit := getIntArg(args, "limit", 0)

	fullPath, err := SafePath(filePath)
	if err != nil {
		return "", fmt.Errorf("read: %w", err)
	}

	info, err := os.Stat(fullPath)
	if err != nil {
		return "", fmt.Errorf("read: %w", err)
	}
	if info.IsDir() {
		return "", fmt.Errorf("read: '%s' is a directory, not a file", filePath)
	}

	data, err := os.ReadFile(fullPath)
	if err != nil {
		return "", fmt.Errorf("read: %w", err)
	}

	lines := strings.Split(string(data), "\n")
	totalLines := len(lines)

	if offset > 0 {
		if offset > totalLines {
			return "", fmt.Errorf("read: offset %d exceeds file length %d", offset, totalLines)
		}
		lines = lines[offset-1:]
	}

	if limit > 0 && limit < len(lines) {
		lines = lines[:limit]
	}

	result := strings.Join(lines, "\n")
	if len(result) > 50000 {
		result = result[:50000] + "\n... (truncated at 50000 chars)"
	}

	meta := fmt.Sprintf("File: %s (%d lines, showing %d)\n\n", fullPath, totalLines, len(lines))
	return meta + result, nil
}

// ─── Tool: write ────────────────────────────────────────────────────────

func buildWriteTool() Tool {
	return Tool{
		Name:        "write",
		Description: "Write content to a file (creates or overwrites). Use for creating new files or complete rewrites of small files.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"filePath": {
					Type:        "string",
					Description: "The absolute path to the file to write",
				},
				"content": {
					Type:        "string",
					Description: "The content to write to the file",
				},
			},
			Required: []string{"filePath", "content"},
		},
		Handler: writeHandler,
	}
}

func writeHandler(args map[string]interface{}) (string, error) {
	filePath, err := getStringArg(args, "filePath")
	if err != nil {
		return "", err
	}
	content, err := getStringArg(args, "content")
	if err != nil {
		return "", err
	}

	fullPath, err := SafePath(filePath)
	if err != nil {
		return "", fmt.Errorf("write: %w", err)
	}

	// Ensure parent directory exists
	parent := filepath.Dir(fullPath)
	if err := os.MkdirAll(parent, 0755); err != nil {
		return "", fmt.Errorf("write: create parent dir: %w", err)
	}

	if err := os.WriteFile(fullPath, []byte(content), 0644); err != nil {
		return "", fmt.Errorf("write: %w", err)
	}

	return fmt.Sprintf("Successfully wrote %d bytes to %s", len(content), fullPath), nil
}

// ─── Tool: edit ─────────────────────────────────────────────────────────

func buildEditTool() Tool {
	return Tool{
		Name:        "edit",
		Description: "Apply a surgical string replacement to an existing file. Use for targeted changes instead of rewriting entire files.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"filePath": {
					Type:        "string",
					Description: "The absolute path to the file to edit",
				},
				"oldString": {
					Type:        "string",
					Description: "The exact text to search for (must exist in the file)",
				},
				"newString": {
					Type:        "string",
					Description: "The replacement text",
				},
				"replaceAll": {
					Type:        "boolean",
					Description: "When true, replace ALL occurrences of oldString; when false (default), only replace the first occurrence",
				},
			},
			Required: []string{"filePath", "oldString", "newString"},
		},
		Handler: editHandler,
	}
}

func editHandler(args map[string]interface{}) (string, error) {
	filePath, err := getStringArg(args, "filePath")
	if err != nil {
		return "", err
	}
	oldStr, err := getStringArg(args, "oldString")
	if err != nil {
		return "", err
	}
	newStr, err := getStringArg(args, "newString")
	if err != nil {
		return "", err
	}
	replaceAll := getBoolArg(args, "replaceAll", false)

	fullPath, err := SafePath(filePath)
	if err != nil {
		return "", fmt.Errorf("edit: %w", err)
	}

	data, err := os.ReadFile(fullPath)
	if err != nil {
		return "", fmt.Errorf("edit: read: %w", err)
	}

	content := string(data)
	if !strings.Contains(content, oldStr) {
		return "", fmt.Errorf("edit: oldString not found in file '%s'", filePath)
	}

	var newContent string
	count := 0
	if replaceAll {
		newContent = strings.ReplaceAll(content, oldStr, newStr)
		count = strings.Count(content, oldStr)
	} else {
		newContent = strings.Replace(content, oldStr, newStr, 1)
		count = 1
	}

	if err := os.WriteFile(fullPath, []byte(newContent), 0644); err != nil {
		return "", fmt.Errorf("edit: write: %w", err)
	}

	return fmt.Sprintf("Applied %d edit(s) to %s", count, fullPath), nil
}

// ─── Tool: bash ─────────────────────────────────────────────────────────

func buildBashTool() Tool {
	return Tool{
		Name:        "bash",
		Description: "Execute a bash command in the workspace directory. Returns stdout and stderr. Timeout is 120 seconds by default.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"command": {
					Type:        "string",
					Description: "The bash command to execute",
				},
				"description": {
					Type:        "string",
					Description: "A short description of what this command does (for logging)",
				},
				"timeout": {
					Type:        "number",
					Description: "Timeout in milliseconds (optional, default 120000 = 2 minutes)",
				},
				"workdir": {
					Type:        "string",
					Description: "Working directory for the command (optional, defaults to workspace root)",
				},
			},
			Required: []string{"command"},
		},
		Handler: bashHandler,
	}
}

func generateShellID() string {
	b := make([]byte, 4)
	if _, err := rand.Read(b); err != nil {
		return "00000000"
	}
	return hex.EncodeToString(b)
}

func bashHandler(args map[string]interface{}) (string, error) {
	cmdStr, err := getStringArg(args, "command")
	if err != nil {
		return "", err
	}

	timeoutMs := getIntArg(args, "timeout", 120000)
	workDirArg := getOptionalStringArg(args, "workdir")

	if timeoutMs <= 0 {
		timeoutMs = 120000
	}
	if timeoutMs > 300000 {
		timeoutMs = 300000
	}

	workDirMu.RLock()
	wd := workDir
	workDirMu.RUnlock()

	if workDirArg != "" {
		wd = workDirArg
	}

	// Shell event metadata
	shellID := generateShellID()
	sessionID := getOptionalStringArg(args, "sessionId")

	// Emit shell started event
	if ShellEventBus != nil && sessionID != "" {
		ShellEventBus.Publish(sse.NewShellStartedEvent(sessionID, shellID, cmdStr))
	}

	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeoutMs)*time.Millisecond)
	defer cancel()

	cmd := exec.CommandContext(ctx, "bash", "-c", cmdStr)
	cmd.Dir = wd

	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr

	runErr := cmd.Run()

	// Determine exit code
	exitCode := 0
	if runErr != nil {
		if ctx.Err() == context.DeadlineExceeded {
			exitCode = -1
		} else if exitErr, ok := runErr.(*exec.ExitError); ok {
			exitCode = exitErr.ExitCode()
		} else {
			exitCode = -2
		}
	}

	var result strings.Builder
	result.WriteString(strings.TrimSpace(stdout.String()))

	if stderr.Len() > 0 {
		if result.Len() > 0 {
			result.WriteString("\n")
		}
		result.WriteString("STDERR:\n")
		result.WriteString(strings.TrimSpace(stderr.String()))
	}

	if runErr != nil {
		if ctx.Err() == context.DeadlineExceeded {
			return "", fmt.Errorf("command timed out after %dms", timeoutMs)
		}
		// Return partial output even on error
		result.WriteString(fmt.Sprintf("\n\nExit code: %v", runErr))
	}

	output := result.String()
	if len(output) > 50000 {
		output = output[:50000] + "\n...(truncated at 50000 chars)"
	}

	// Emit shell ended event
	if ShellEventBus != nil && sessionID != "" {
		ShellEventBus.Publish(sse.NewShellEndedEvent(sessionID, shellID, output, exitCode))
	}

	return output, nil
}

// ─── Tool: glob ─────────────────────────────────────────────────────────

func buildGlobTool() Tool {
	return Tool{
		Name:        "glob",
		Description: "Fast file pattern matching. Find files by glob patterns (e.g. '**/*.ts', 'src/**/*.go').",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"pattern": {
					Type:        "string",
					Description: "The glob pattern to match files against (e.g. '**/*.ts')",
				},
				"path": {
					Type:        "string",
					Description: "The directory to search in (optional, defaults to workspace)",
				},
			},
			Required: []string{"pattern"},
		},
		Handler: globHandler,
	}
}

// Glob pattern matching using filepath.Match
type globEngine struct{}

func (g *globEngine) glob(pattern, basePath string) ([]string, error) {
	if !filepath.IsAbs(basePath) {
		basePath = filepath.Join(GetWorkDir(), basePath)
	}

	var matches []string
	err := filepath.Walk(basePath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil // skip errors
		}
		rel, _ := filepath.Rel(basePath, path)
		if rel == "." {
			return nil
		}
		matched, err := filepath.Match(pattern, rel)
		if err != nil {
			return nil
		}
		if matched {
			matches = append(matches, path)
		}
		return nil
	})
	return matches, err
}

func globHandler(args map[string]interface{}) (string, error) {
	pattern, err := getStringArg(args, "pattern")
	if err != nil {
		return "", err
	}
	path := getOptionalStringArg(args, "path")
	if path == "" {
		workDirMu.RLock()
		path = workDir
		workDirMu.RUnlock()
	}

	engine := &globEngine{}
	matches, err := engine.glob(pattern, path)
	if err != nil {
		return "", fmt.Errorf("glob: %w", err)
	}
	if len(matches) == 0 {
		return fmt.Sprintf("No files matched pattern '%s' in %s", pattern, path), nil
	}

	sort.Strings(matches)
	result := fmt.Sprintf("Found %d file(s) matching '%s':\n", len(matches), pattern)
	for _, m := range matches {
		result += m + "\n"
	}
	return result, nil
}

// ─── Tool: grep ─────────────────────────────────────────────────────────

func buildGrepTool() Tool {
	return Tool{
		Name:        "grep",
		Description: "Fast content search using regex patterns. Searches file contents and returns matching lines.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"pattern": {
					Type:        "string",
					Description: "The regex pattern to search for in file contents",
				},
				"path": {
					Type:        "string",
					Description: "The directory to search in (optional, defaults to workspace)",
				},
				"include": {
					Type:        "string",
					Description: "File pattern to include (e.g. '*.ts', optional)",
				},
			},
			Required: []string{"pattern"},
		},
		Handler: grepHandler,
	}
}

func grepHandler(args map[string]interface{}) (string, error) {
	pattern, err := getStringArg(args, "pattern")
	if err != nil {
		return "", err
	}
	path := getOptionalStringArg(args, "path")
	include := getOptionalStringArg(args, "include")

	workDirMu.RLock()
	searchDir := workDir
	workDirMu.RUnlock()

	if path != "" {
		resolved, err := SafePath(path)
		if err != nil {
			return "", fmt.Errorf("grep: invalid path: %w", err)
		}
		searchDir = resolved
	}

	re, err := regexp.Compile(pattern)
	if err != nil {
		return "", fmt.Errorf("grep: invalid regex: %w", err)
	}

	type match struct {
		file    string
		lineNum int
		line    string
	}
	var matches []match

	filepath.Walk(searchDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		if include != "" {
			matched, err := filepath.Match(include, info.Name())
			if err != nil || !matched {
				return nil
			}
		}
		// Skip binary files
		data, err := os.ReadFile(path)
		if err != nil {
			return nil
		}
		lines := strings.Split(string(data), "\n")
		for i, line := range lines {
			if re.MatchString(line) {
				relPath, _ := filepath.Rel(searchDir, path)
				matches = append(matches, match{relPath, i + 1, strings.TrimSpace(line)})
			}
		}
		return nil
	})

	if len(matches) == 0 {
		return fmt.Sprintf("No matches for '%s' in %s", pattern, searchDir), nil
	}

	var result strings.Builder
	result.WriteString(fmt.Sprintf("Found %d match(es) for '%s':\n\n", len(matches), pattern))
	for _, m := range matches {
		result.WriteString(fmt.Sprintf("%s:%d: %s\n", m.file, m.lineNum, m.line))
	}
	output := result.String()
	if len(output) > 50000 {
		output = output[:50000] + "\n...(truncated at 50000 chars)"
	}
	return output, nil
}

// ─── Tool: code_rag ─────────────────────────────────────────────────────

func buildCodeRagTool() Tool {
	return Tool{
		Name:        "code_rag",
		Description: "Search the codebase using semantic code search. Returns relevant code chunks with file paths and line numbers.",
		Parameters: ToolSchema{
			Type: "object",
			Properties: map[string]ToolProperty{
				"query": {
					Type:        "string",
					Description: "The search query (natural language or keywords)",
				},
			},
			Required: []string{"query"},
		},
		Handler: codeRagHandler,
	}
}

func codeRagHandler(args map[string]interface{}) (string, error) {
	query, err := getStringArg(args, "query")
	if err != nil {
		return "", err
	}

	// Try semantic search first (more relevant results)
	if semanticSearchFn != nil {
		result, err := semanticSearchFn(query)
		if err == nil && result != "" {
			return result, nil
		}
	}

	// Fall back to keyword search
	if codeSearchFn != nil {
		return codeSearchFn(query)
	}
	return "code_rag: not available (no index)", nil
}

// codeSearchFn is set by main.go to bridge to the rag package.
var codeSearchFn func(query string) (string, error)

// SetCodeSearch sets the code search function (called from main.go).
func SetCodeSearch(fn func(query string) (string, error)) {
	codeSearchFn = fn
}

// semanticSearchFn is set by main.go to enable embedding-based search.
var semanticSearchFn func(query string) (string, error)

// SetSemanticSearch registers a semantic search function that uses embeddings.
// When set, codeRagHandler will try semantic search before falling back to keyword search.
func SetSemanticSearch(fn func(query string) (string, error)) {
	semanticSearchFn = fn
}

// BuildSkillBuiltinHandler creates a handler that delegates to an existing tool.
// Captures the original handler at construction time to prevent self-recursion.
func BuildSkillBuiltinHandler(toolName string) ToolHandler {
	// Capture the handler that currently exists in the global registry
	// BEFORE this skill handler gets registered (which would replace it)
	regMu.RLock()
	existing, ok := registry[toolName]
	regMu.RUnlock()

	if !ok {
		return func(args map[string]interface{}) (string, error) {
			return "", fmt.Errorf("skill references unknown tool '%s'", toolName)
		}
	}

	// Store the original handler — this breaks the self-recursion cycle
	originalHandler := existing.Handler
	return func(args map[string]interface{}) (string, error) {
		return originalHandler(args)
	}
}
