package tools

import "fmt"

// ─── Tool Error Types ──────────────────────────────────────────────

// ToolError clasifica errores de ejecución de tools
type ToolError struct {
	ToolName string
	Kind     ToolErrorKind
	Message  string
	Cause    error
}

// ToolErrorKind categoriza el tipo de error
type ToolErrorKind int

const (
	ToolErrorNotFound      ToolErrorKind = iota
	ToolErrorTimeout                     = iota
	ToolErrorDepthExceeded               = iota
	ToolErrorPanic                       = iota
	ToolErrorRecoverable                 = iota
	ToolErrorFatal                       = iota
)

func (e *ToolError) Error() string {
	return fmt.Sprintf("[%s] %s: %s", e.Kind.String(), e.ToolName, e.Message)
}

func (k ToolErrorKind) String() string {
	switch k {
	case ToolErrorNotFound:
		return "NOT_FOUND"
	case ToolErrorTimeout:
		return "TIMEOUT"
	case ToolErrorDepthExceeded:
		return "DEPTH_EXCEEDED"
	case ToolErrorPanic:
		return "PANIC"
	case ToolErrorRecoverable:
		return "RECOVERABLE"
	case ToolErrorFatal:
		return "FATAL"
	default:
		return "UNKNOWN"
	}
}
