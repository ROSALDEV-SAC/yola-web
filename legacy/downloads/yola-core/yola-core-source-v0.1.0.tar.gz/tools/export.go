package tools

// SessionToolManager — interfaz pública para que el agent loop use tools
type SessionToolManager struct {
	Registry *SessionRegistry
}

// NewSessionToolManager crea un nuevo manager de tools para una sesión.
func NewSessionToolManager() *SessionToolManager {
	return &SessionToolManager{
		Registry: NewSessionRegistry(),
	}
}

// Execute ejecuta un tool por nombre con límite de profundidad.
func (stm *SessionToolManager) Execute(name string, args map[string]interface{}, depth int) (string, error) {
	return stm.Registry.ExecuteTool(name, args, depth)
}

// RegisterSkill registra un tool de skill en el registry de sesión.
func (stm *SessionToolManager) RegisterSkill(t Tool) {
	stm.Registry.Register(t)
}
