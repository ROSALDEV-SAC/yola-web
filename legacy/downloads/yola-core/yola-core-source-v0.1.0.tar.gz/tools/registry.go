package tools

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/sse"
)

// ─── Types ───────────────────────────────────────────────────────────────

// ToolSchema is JSON Schema for tool parameters.
type ToolSchema struct {
	Type       string                  `json:"type"`
	Properties map[string]ToolProperty `json:"properties"`
	Required   []string                `json:"required,omitempty"`
}

// ToolProperty describes a single parameter of a tool.
type ToolProperty struct {
	Type        string   `json:"type"`
	Description string   `json:"description,omitempty"`
	Enum        []string `json:"enum,omitempty"`
}

// Tool defines a function the LLM can call via the tool calling API.
type Tool struct {
	Name        string      `json:"name"`
	Description string      `json:"description"`
	Parameters  ToolSchema  `json:"parameters"`
	Handler     ToolHandler `json:"-"`
}

// ToolHandler executes a tool with the given arguments and returns a result string.
type ToolHandler func(args map[string]interface{}) (string, error)

// ─── Registry ─────────────────────────────────────────────────────────────

var (
	registry map[string]Tool
	regMu    sync.RWMutex
)

// Register adds a tool to the registry.
func Register(t Tool) {
	regMu.Lock()
	defer regMu.Unlock()
	if registry == nil {
		registry = make(map[string]Tool)
	}
	registry[t.Name] = t
}

// GetAllTools returns a copy of all registered tools.
func GetAllTools() []Tool {
	regMu.RLock()
	defer regMu.RUnlock()
	tools := make([]Tool, 0, len(registry))
	for _, t := range registry {
		tools = append(tools, t)
	}
	return tools
}

// GetRegistrySize returns the number of registered tools.
func GetRegistrySize() int {
	regMu.RLock()
	defer regMu.RUnlock()
	return len(registry)
}

// ─── Globals (set by main.go) ─────────────────────────────────────────

// These package-level globals are set by main.go after construction.
// They allow ExecuteTool to access cross-cutting services without
// creating circular import dependencies between domain packages.

// MCPManager is the global MCP server manager.
var MCPManager MCPManagerInterface

// MCPManagerInterface defines what tools needs from the MCP manager.
type MCPManagerInterface interface {
	HasTool(name string) bool
	CallTool(name string, args map[string]interface{}) (string, error)
}

// ShellEventBus is the global SSE event bus for shell execution events.
// Set from server.go wiring.
var ShellEventBus *sse.EventBus

// ─── Working Directory ─────────────────────────────────────────────────

var (
	workDir   string
	workDirMu sync.RWMutex
)

// SetWorkDir sets the global working directory.
func SetWorkDir(dir string) {
	workDirMu.Lock()
	workDir = dir
	workDirMu.Unlock()
	rebuildAllowedPrefixes(dir)
}

// GetWorkDir returns the current working directory.
func GetWorkDir() string {
	workDirMu.RLock()
	defer workDirMu.RUnlock()
	return workDir
}

// ─── Allowed Paths ─────────────────────────────────────────────────────

var (
	allowedPrefixes []string
	allowedMu       sync.RWMutex
)

func rebuildAllowedPrefixes(dir string) {
	prefixes := []string{filepath.Clean(dir), "/tmp"}
	if home, err := os.UserHomeDir(); err == nil {
		absHome := filepath.Clean(home)
		hasHome := false
		for _, p := range prefixes {
			if p == absHome {
				hasHome = true
				break
			}
		}
		if !hasHome {
			prefixes = append(prefixes, absHome)
		}
	}
	allowedMu.Lock()
	allowedPrefixes = prefixes
	allowedMu.Unlock()
}

// SafePath resolves a target path, cleans it, and verifies it stays within
// allowed directories to prevent path traversal attacks.
func SafePath(target string) (string, error) {
	if strings.TrimSpace(target) == "" {
		return "", fmt.Errorf("path is empty")
	}

	var abs string
	if filepath.IsAbs(target) {
		abs = filepath.Clean(target)
	} else {
		abs = filepath.Clean(filepath.Join(GetWorkDir(), target))
	}

	// Resolve symlinks and .. components fully
	resolved, err := filepath.EvalSymlinks(abs)
	if err != nil {
		resolved = abs
	}

	// Check against all allowed prefixes (thread-safe copy)
	allowedMu.RLock()
	prefixes := make([]string, len(allowedPrefixes))
	copy(prefixes, allowedPrefixes)
	allowedMu.RUnlock()

	allowed := false
	for _, prefix := range prefixes {
		absPrefix, err := filepath.Abs(prefix)
		if err != nil {
			continue
		}
		// Ensure the resolved path starts with the allowed prefix.
		// Append a separator to prevent prefix partial matches
		// (e.g., /home/foo matching /home/foobar).
		if strings.HasPrefix(resolved+"/", absPrefix+"/") || resolved == absPrefix {
			allowed = true
			break
		}
	}
	if !allowed {
		return "", fmt.Errorf("path '%s' is outside allowed directories", target)
	}
	return resolved, nil
}

// ─── Session Registry ────────────────────────────────────────────────

// SessionRegistry — registry aislado por sesión con depth limiting, timeout y panic recovery.
type SessionRegistry struct {
	mu    sync.RWMutex
	tools map[string]Tool
	depth int // profundidad actual de tool calls
}

// NewSessionRegistry crea un nuevo registry de sesión vacío.
func NewSessionRegistry() *SessionRegistry {
	return &SessionRegistry{
		tools: make(map[string]Tool),
	}
}

// Register añade un tool al registry de sesión.
func (sr *SessionRegistry) Register(t Tool) {
	sr.mu.Lock()
	defer sr.mu.Unlock()
	sr.tools[t.Name] = t
}

// ExecuteTool ejecuta un tool por nombre con límite de profundidad, timeout y recover.
// Si no encuentra el tool en el registry de sesión, fallbackea al registry global
// y luego a MCPManager.
func (sr *SessionRegistry) ExecuteTool(name string, args map[string]interface{}, parentDepth int) (string, error) {
	// Límite de profundidad: máximo 10 niveles de anidación de tools
	const maxDepth = 10
	if parentDepth >= maxDepth {
		return "", &ToolError{
			ToolName: name,
			Kind:     ToolErrorDepthExceeded,
			Message:  fmt.Sprintf("max tool depth %d exceeded", maxDepth),
		}
	}

	// Recover de pánico
	defer func() {
		if r := recover(); r != nil {
			errMsg := fmt.Sprintf("panic in tool '%s': %v", name, r)
			fmt.Printf("[FATAL] %s\n", errMsg)
		}
	}()

	sr.mu.RLock()
	tool, ok := sr.tools[name]
	sr.mu.RUnlock()

	if !ok {
		// Fallback a registry global para built-in tools
		regMu.RLock()
		globalTool, globalOk := registry[name]
		regMu.RUnlock()
		if !globalOk {
			if MCPManager != nil && MCPManager.HasTool(name) {
				return MCPManager.CallTool(name, args)
			}
			return "", &ToolError{
				ToolName: name,
				Kind:     ToolErrorNotFound,
				Message:  fmt.Sprintf("tool '%s' not found in session or global registry", name),
			}
		}
		tool = globalTool
	}

	// Ejecutar con timeout (30s por defecto)
	type result struct {
		output string
		err    error
	}
	ch := make(chan result, 1)
	go func() {
		defer func() {
			if r := recover(); r != nil {
				ch <- result{"", &ToolError{
					ToolName: name,
					Kind:     ToolErrorPanic,
					Message:  fmt.Sprintf("panic in tool handler: %v", r),
				}}
			}
		}()
		out, err := tool.Handler(args)
		ch <- result{out, err}
	}()

	select {
	case res := <-ch:
		if res.err != nil {
			return res.output, &ToolError{
				ToolName: name,
				Kind:     ToolErrorRecoverable,
				Message:  res.err.Error(),
				Cause:    res.err,
			}
		}
		return res.output, nil
	case <-time.After(30 * time.Second):
		return "", &ToolError{
			ToolName: name,
			Kind:     ToolErrorTimeout,
			Message:  fmt.Sprintf("tool '%s' timed out after 30s", name),
		}
	}
}
