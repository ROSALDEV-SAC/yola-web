package memory

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/db"
	"github.com/ROSALDEV-SAC/yola-core/rag"
)

// stopwords are common Spanish/English words with no semantic value.
var stopwords = map[string]bool{
	"el": true, "la": true, "los": true, "las": true, "un": true, "una": true,
	"de": true, "del": true, "en": true, "para": true, "por": true, "con": true,
	"sin": true, "es": true, "son": true, "se": true, "su": true, "lo": true,
	"como": true, "mas": true, "pero": true, "que": true, "y": true, "e": true,
	"o": true, "a": true, "ante": true, "bajo": true, "the": true, "and": true,
	"for": true, "are": true, "was": true, "has": true, "had": true, "not": true,
	"this": true, "that": true, "with": true, "from": true, "you": true, "your": true,
}

// tokenizeQuery extracts meaningful keywords from a query string.
func tokenizeQuery(query string) []string {
	query = strings.ToLower(query)
	raw := strings.Fields(query)
	seen := make(map[string]bool)
	var tokens []string
	for _, w := range raw {
		w = strings.Trim(w, ".,;:!?\"'()[]{}")
		if len(w) < 2 {
			continue
		}
		if stopwords[w] {
			continue
		}
		if seen[w] {
			continue
		}
		seen[w] = true
		tokens = append(tokens, w)
	}
	return tokens
}

// buildKeywordClause builds a WHERE clause searching across multiple columns
// for any of the given keywords. Returns the clause and args.
func buildKeywordClause(keywords []string, columns ...string) (string, []interface{}) {
	if len(keywords) == 0 {
		return "1=0", nil
	}
	var clauses []string
	var args []interface{}
	for _, kw := range keywords {
		pattern := "%" + kw + "%"
		for _, col := range columns {
			clauses = append(clauses, col+" LIKE ?")
			args = append(args, pattern)
		}
	}
	return "(" + strings.Join(clauses, " OR ") + ")", args
}

// SQLiteMemory implements System using SQLite for all memory layers.
type SQLiteMemory struct {
	database       *sql.DB
	semanticSearch *rag.SemanticSearch
}

// SetSemanticSearch attaches a SemanticSearch instance to enable
// embedding-based relevance ranking as a fallback in QuerySemantic and QueryEpisodic.
func (ms *SQLiteMemory) SetSemanticSearch(ss *rag.SemanticSearch) {
	ms.semanticSearch = ss
}

// NewSystem creates a new SQLiteMemory.
func NewSystem(database *sql.DB) *SQLiteMemory {
	return &SQLiteMemory{database: database}
}

// ─── Working Memory ─────────────────────────────────────────────────────

func (ms *SQLiteMemory) WorkingSet(sessionID, key, value string) error {
	now := time.Now().UnixMilli()
	_, err := ms.database.Exec(
		`INSERT INTO working_memory (session_id, key, value, created_at, updated_at)
		 VALUES (?, ?, ?, ?, ?)
		 ON CONFLICT(session_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
		sessionID, key, value, now, now,
	)
	return err
}

func (ms *SQLiteMemory) WorkingGet(sessionID, key string) (string, error) {
	row := ms.database.QueryRow(
		`SELECT value FROM working_memory WHERE session_id = ? AND key = ?`, sessionID, key,
	)
	var value string
	err := row.Scan(&value)
	if err == sql.ErrNoRows {
		return "", nil
	}
	return value, err
}

func (ms *SQLiteMemory) WorkingGetAll(sessionID string) ([]WorkingMemoryEntry, error) {
	rows, err := ms.database.Query(
		`SELECT session_id, key, value, created_at, updated_at FROM working_memory WHERE session_id = ?`, sessionID,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []WorkingMemoryEntry
	for rows.Next() {
		var e WorkingMemoryEntry
		if err := rows.Scan(&e.SessionID, &e.Key, &e.Value, &e.CreatedAt, &e.UpdatedAt); err != nil {
			continue
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

func (ms *SQLiteMemory) WorkingClear(sessionID string) error {
	_, err := ms.database.Exec(`DELETE FROM working_memory WHERE session_id = ?`, sessionID)
	return err
}

// ─── Episodic Memory ────────────────────────────────────────────────────

func (ms *SQLiteMemory) RecordEpisode(sessionID, observation, action, outcome, tags string, context map[string]interface{}) error {
	now := time.Now().UnixMilli()
	id := db.NewID("epi")
	ctxJSON, err := json.Marshal(context)
	if err != nil {
		return fmt.Errorf("marshal context: %w", err)
	}
	_, err = ms.database.Exec(
		`INSERT INTO episodic_memory (id, observation, action, outcome, context, tags, importance, session_id, created_at)
		 VALUES (?, ?, ?, ?, ?, ?, 1.0, ?, ?)`,
		id, observation, action, outcome, string(ctxJSON), tags, sessionID, now,
	)
	if err != nil {
		return fmt.Errorf("record episode: %w", err)
	}
	return nil
}

func (ms *SQLiteMemory) QueryEpisodic(query string, limit int) ([]EpisodicMemoryEntry, error) {
	if limit <= 0 {
		limit = 20
	}

	// Try semantic search first when available
	if ms.semanticSearch != nil && ms.semanticSearch.IsAvailable() {
		return ms.queryEpisodicSemantic(query, limit)
	}

	// Fallback to keyword LIKE search
	keywords := tokenizeQuery(query)
	if len(keywords) == 0 {
		return ms.GetRecentEpisodes(limit)
	}
	whereClause, args := buildKeywordClause(keywords, "observation", "tags", "action", "outcome")
	rows, err := ms.database.Query(
		`SELECT id, observation, COALESCE(action,''), COALESCE(outcome,''), COALESCE(context,''), COALESCE(tags,''), importance, COALESCE(session_id,''), COALESCE(workspace_id,''), created_at
		 FROM episodic_memory
		 WHERE `+whereClause+`
		 ORDER BY importance DESC, created_at DESC LIMIT ?`,
		append(args, limit)...,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []EpisodicMemoryEntry
	for rows.Next() {
		var e EpisodicMemoryEntry
		var ctxStr string
		if err := rows.Scan(&e.ID, &e.Observation, &e.Action, &e.Outcome, &ctxStr, &e.Tags, &e.Importance, &e.SessionID, &e.WorkspaceID, &e.CreatedAt); err != nil {
			continue
		}
		if ctxStr != "" {
			e.Context = json.RawMessage(ctxStr)
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

// queryEpisodicSemantic uses the embeddings plugin to rank episodic memory by relevance.
func (ms *SQLiteMemory) queryEpisodicSemantic(query string, limit int) ([]EpisodicMemoryEntry, error) {
	// Fetch recent episodes as candidates (up to 200 for ranking)
	candidates, err := ms.database.Query(
		`SELECT id, observation, COALESCE(action,''), COALESCE(outcome,''), COALESCE(context,''), COALESCE(tags,''), importance, COALESCE(session_id,''), COALESCE(workspace_id,''), created_at
		 FROM episodic_memory ORDER BY created_at DESC LIMIT 200`,
	)
	if err != nil {
		return nil, err
	}
	defer candidates.Close()

	var entries []EpisodicMemoryEntry
	var contents []string
	for candidates.Next() {
		var e EpisodicMemoryEntry
		var ctxStr string
		if err := candidates.Scan(&e.ID, &e.Observation, &e.Action, &e.Outcome, &ctxStr, &e.Tags, &e.Importance, &e.SessionID, &e.WorkspaceID, &e.CreatedAt); err != nil {
			continue
		}
		if ctxStr != "" {
			e.Context = json.RawMessage(ctxStr)
		}
		entries = append(entries, e)
		contents = append(contents, e.Observation)
	}
	if err := candidates.Err(); err != nil {
		return nil, err
	}

	results, err := ms.semanticSearch.Search(query, contents, limit)
	if err != nil {
		// Fallback to keyword on error
		log.Printf("[QueryEpisodic] semantic search error, falling back: %v", err)
		keywords := tokenizeQuery(query)
		if len(keywords) == 0 {
			return ms.GetRecentEpisodes(limit)
		}
		whereClause, args := buildKeywordClause(keywords, "observation", "tags", "action", "outcome")
		rows, err2 := ms.database.Query(
			`SELECT id, observation, COALESCE(action,''), COALESCE(outcome,''), COALESCE(context,''), COALESCE(tags,''), importance, COALESCE(session_id,''), COALESCE(workspace_id,''), created_at
			 FROM episodic_memory WHERE `+whereClause+`
			 ORDER BY importance DESC, created_at DESC LIMIT ?`,
			append(args, limit)...,
		)
		if err2 != nil {
			return nil, err2
		}
		defer rows.Close()
		var fallback []EpisodicMemoryEntry
		for rows.Next() {
			var e EpisodicMemoryEntry
			var ctxStr string
			if err := rows.Scan(&e.ID, &e.Observation, &e.Action, &e.Outcome, &ctxStr, &e.Tags, &e.Importance, &e.SessionID, &e.WorkspaceID, &e.CreatedAt); err != nil {
				continue
			}
			if ctxStr != "" {
				e.Context = json.RawMessage(ctxStr)
			}
			fallback = append(fallback, e)
		}
		return fallback, rows.Err()
	}

	// Map search results back to entries by content match
	ranked := make([]EpisodicMemoryEntry, 0, len(results))
	used := make(map[int]bool)
	for _, r := range results {
		for i, e := range entries {
			if used[i] {
				continue
			}
			if e.Observation == r.Content {
				ranked = append(ranked, e)
				used[i] = true
				break
			}
		}
	}
	return ranked, nil
}

func (ms *SQLiteMemory) GetRecentEpisodes(limit int) ([]EpisodicMemoryEntry, error) {
	if limit <= 0 {
		limit = 20
	}
	rows, err := ms.database.Query(
		`SELECT id, observation, COALESCE(action,''), COALESCE(outcome,''), COALESCE(context,''), COALESCE(tags,''), importance, COALESCE(session_id,''), COALESCE(workspace_id,''), created_at
		 FROM episodic_memory ORDER BY created_at DESC LIMIT ?`, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []EpisodicMemoryEntry
	for rows.Next() {
		var e EpisodicMemoryEntry
		var ctxStr string
		if err := rows.Scan(&e.ID, &e.Observation, &e.Action, &e.Outcome, &ctxStr, &e.Tags, &e.Importance, &e.SessionID, &e.WorkspaceID, &e.CreatedAt); err != nil {
			continue
		}
		if ctxStr != "" {
			e.Context = json.RawMessage(ctxStr)
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

// ─── Semantic Memory ────────────────────────────────────────────────────

func (ms *SQLiteMemory) StoreSemantic(content, source string, confidence float64, tags string, episodeID string) (string, error) {
	now := time.Now().UnixMilli()
	id := db.NewID("sem")
	_, err := ms.database.Exec(
		`INSERT INTO semantic_memory (id, content, source, confidence, tags, episode_id, created_at, last_accessed_at, access_count)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)`,
		id, content, source, confidence, tags, episodeID, now, now,
	)
	if err != nil {
		return "", fmt.Errorf("store semantic: %w", err)
	}
	return id, nil
}

func (ms *SQLiteMemory) QuerySemantic(query string, minConfidence float64, limit int) ([]SemanticMemoryEntry, error) {
	if limit <= 0 {
		limit = 20
	}

	// Try semantic search first when available
	if ms.semanticSearch != nil && ms.semanticSearch.IsAvailable() {
		return ms.querySemanticSemantic(query, minConfidence, limit)
	}

	// Fallback to keyword LIKE search
	keywords := tokenizeQuery(query)
	if len(keywords) == 0 {
		return nil, nil
	}
	whereClause, args := buildKeywordClause(keywords, "content", "tags")
	rows, err := ms.database.Query(
		`SELECT id, content, COALESCE(source,''), confidence, COALESCE(tags,''), COALESCE(episode_id,''), created_at, last_accessed_at, access_count
		 FROM semantic_memory
		 WHERE (`+whereClause+`) AND confidence >= ?
		 ORDER BY confidence DESC, last_accessed_at DESC LIMIT ?`,
		append(args, minConfidence, limit)...,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []SemanticMemoryEntry
	for rows.Next() {
		var e SemanticMemoryEntry
		if err := rows.Scan(&e.ID, &e.Content, &e.Source, &e.Confidence, &e.Tags, &e.EpisodeID, &e.CreatedAt, &e.LastAccessedAt, &e.AccessCount); err != nil {
			continue
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

// querySemanticSemantic uses the embeddings plugin to rank semantic memory by relevance.
func (ms *SQLiteMemory) querySemanticSemantic(query string, minConfidence float64, limit int) ([]SemanticMemoryEntry, error) {
	// Fetch candidate entries above confidence threshold (up to 200)
	candidates, err := ms.database.Query(
		`SELECT id, content, COALESCE(source,''), confidence, COALESCE(tags,''), COALESCE(episode_id,''), created_at, last_accessed_at, access_count
		 FROM semantic_memory WHERE confidence >= ?
		 ORDER BY confidence DESC, last_accessed_at DESC LIMIT 200`,
		minConfidence,
	)
	if err != nil {
		return nil, err
	}
	defer candidates.Close()

	var entries []SemanticMemoryEntry
	var contents []string
	for candidates.Next() {
		var e SemanticMemoryEntry
		if err := candidates.Scan(&e.ID, &e.Content, &e.Source, &e.Confidence, &e.Tags, &e.EpisodeID, &e.CreatedAt, &e.LastAccessedAt, &e.AccessCount); err != nil {
			continue
		}
		entries = append(entries, e)
		contents = append(contents, e.Content)
	}
	if err := candidates.Err(); err != nil {
		return nil, err
	}
	if len(contents) == 0 {
		return nil, nil
	}

	results, err := ms.semanticSearch.Search(query, contents, limit)
	if err != nil {
		// Fallback to keyword on error
		log.Printf("[QuerySemantic] semantic search error, falling back: %v", err)
		keywords := tokenizeQuery(query)
		if len(keywords) == 0 {
			return nil, nil
		}
		whereClause, args := buildKeywordClause(keywords, "content", "tags")
		rows, err2 := ms.database.Query(
			`SELECT id, content, COALESCE(source,''), confidence, COALESCE(tags,''), COALESCE(episode_id,''), created_at, last_accessed_at, access_count
			 FROM semantic_memory WHERE (`+whereClause+`) AND confidence >= ?
			 ORDER BY confidence DESC, last_accessed_at DESC LIMIT ?`,
			append(args, minConfidence, limit)...,
		)
		if err2 != nil {
			return nil, err2
		}
		defer rows.Close()
		var fallback []SemanticMemoryEntry
		for rows.Next() {
			var e SemanticMemoryEntry
			if err := rows.Scan(&e.ID, &e.Content, &e.Source, &e.Confidence, &e.Tags, &e.EpisodeID, &e.CreatedAt, &e.LastAccessedAt, &e.AccessCount); err != nil {
				continue
			}
			fallback = append(fallback, e)
		}
		return fallback, rows.Err()
	}

	// Map search results back to entries by content match
	ranked := make([]SemanticMemoryEntry, 0, len(results))
	used := make(map[int]bool)
	for _, r := range results {
		for i, e := range entries {
			if used[i] {
				continue
			}
			if e.Content == r.Content {
				ranked = append(ranked, e)
				used[i] = true
				break
			}
		}
	}
	return ranked, nil
}

func (ms *SQLiteMemory) ReinforceSemantic(id string) error {
	now := time.Now().UnixMilli()
	_, err := ms.database.Exec(
		`UPDATE semantic_memory SET access_count = access_count + 1, last_accessed_at = ? WHERE id = ?`,
		now, id,
	)
	return err
}

// ─── Decision Journal ───────────────────────────────────────────────────

func (ms *SQLiteMemory) RecordDecision(sessionID, workspaceID string, turn int, observation, inference, decision, alternatives, toolName, toolArgs, context, outcome, outcomeDetail string, importance float64) string {
	now := time.Now().UnixMilli()
	id := db.NewID("dec")
	_, err := ms.database.Exec(
		`INSERT INTO decision_journal (id, session_id, workspace_id, turn, observation, inference, decision, alternatives, tool_name, tool_args, context, outcome, outcome_detail, importance, created_at)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		id, sessionID, workspaceID, turn, observation, inference, decision, alternatives, toolName, toolArgs, context, outcome, outcomeDetail, importance, now,
	)
	if err != nil {
		log.Printf("[DB] RecordDecision: %v", err)
		return ""
	}
	return id
}

func (ms *SQLiteMemory) UpdateDecision(id, outcome, outcomeDetail string) error {
	_, err := ms.database.Exec(
		`UPDATE decision_journal SET outcome = ?, outcome_detail = ? WHERE id = ?`,
		outcome, outcomeDetail, id,
	)
	return err
}

func (ms *SQLiteMemory) QueryDecisions(query string, limit int) ([]DecisionEntry, error) {
	if limit <= 0 {
		limit = 20
	}
	rows, err := ms.database.Query(
		`SELECT id, COALESCE(session_id,''), COALESCE(workspace_id,''), turn, observation,
		        COALESCE(inference,''), decision, COALESCE(alternatives,''), COALESCE(outcome,''),
		        COALESCE(outcome_detail,''), COALESCE(tool_name,''), COALESCE(tool_args,''),
		        COALESCE(context,''), importance, created_at
		 FROM decision_journal
		 WHERE observation LIKE '%' || ? || '%' OR decision LIKE '%' || ? || '%'
		 ORDER BY created_at DESC LIMIT ?`, query, query, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []DecisionEntry
	for rows.Next() {
		var e DecisionEntry
		if err := rows.Scan(&e.ID, &e.SessionID, &e.WorkspaceID, &e.Turn, &e.Observation,
			&e.Inference, &e.Decision, &e.Alternatives, &e.Outcome, &e.OutcomeDetail,
			&e.ToolName, &e.ToolArgs, &e.Context, &e.Importance, &e.CreatedAt); err != nil {
			continue
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

func (ms *SQLiteMemory) GetDecisionByID(id string) *DecisionEntry {
	row := ms.database.QueryRow(
		`SELECT id, COALESCE(session_id,''), COALESCE(workspace_id,''), turn, observation,
		        COALESCE(inference,''), decision, COALESCE(alternatives,''), COALESCE(outcome,''),
		        COALESCE(outcome_detail,''), COALESCE(tool_name,''), COALESCE(tool_args,''),
		        COALESCE(context,''), importance, created_at
		 FROM decision_journal WHERE id = ?`, id,
	)
	var e DecisionEntry
	err := row.Scan(&e.ID, &e.SessionID, &e.WorkspaceID, &e.Turn, &e.Observation,
		&e.Inference, &e.Decision, &e.Alternatives, &e.Outcome, &e.OutcomeDetail,
		&e.ToolName, &e.ToolArgs, &e.Context, &e.Importance, &e.CreatedAt)
	if err != nil {
		return nil
	}
	return &e
}

func (ms *SQLiteMemory) GetRecentDecisions(limit int) ([]DecisionEntry, error) {
	if limit <= 0 {
		limit = 20
	}
	rows, err := ms.database.Query(
		`SELECT id, COALESCE(session_id,''), COALESCE(workspace_id,''), turn, observation,
		        COALESCE(inference,''), decision, COALESCE(alternatives,''), COALESCE(outcome,''),
		        COALESCE(outcome_detail,''), COALESCE(tool_name,''), COALESCE(tool_args,''),
		        COALESCE(context,''), importance, created_at
		 FROM decision_journal ORDER BY created_at DESC LIMIT ?`, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []DecisionEntry
	for rows.Next() {
		var e DecisionEntry
		if err := rows.Scan(&e.ID, &e.SessionID, &e.WorkspaceID, &e.Turn, &e.Observation,
			&e.Inference, &e.Decision, &e.Alternatives, &e.Outcome, &e.OutcomeDetail,
			&e.ToolName, &e.ToolArgs, &e.Context, &e.Importance, &e.CreatedAt); err != nil {
			continue
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}
