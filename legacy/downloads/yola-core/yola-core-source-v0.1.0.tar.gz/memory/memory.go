package memory

import (
	"encoding/json"

	"github.com/ROSALDEV-SAC/yola-core/rag"
)

// ─── Types ────────────────────────────────────────────────────────────────

// WorkingMemoryEntry represents a key-value pair in working memory.
type WorkingMemoryEntry struct {
	SessionID string `json:"sessionId"`
	Key       string `json:"key"`
	Value     string `json:"value"`
	CreatedAt int64  `json:"createdAt"`
	UpdatedAt int64  `json:"updatedAt"`
}

// EpisodicMemoryEntry represents a recorded experience.
type EpisodicMemoryEntry struct {
	ID          string          `json:"id"`
	Observation string          `json:"observation"`
	Action      string          `json:"action"`
	Outcome     string          `json:"outcome"`
	Context     json.RawMessage `json:"context,omitempty"`
	Tags        string          `json:"tags"`
	Importance  float64         `json:"importance"`
	SessionID   string          `json:"sessionId"`
	WorkspaceID string          `json:"workspaceId"`
	CreatedAt   int64           `json:"createdAt"`
}

// SemanticMemoryEntry represents extracted knowledge.
type SemanticMemoryEntry struct {
	ID             string  `json:"id"`
	Content        string  `json:"content"`
	Source         string  `json:"source"`
	Confidence     float64 `json:"confidence"`
	Tags           string  `json:"tags"`
	EpisodeID      string  `json:"episodeId,omitempty"`
	CreatedAt      int64   `json:"createdAt"`
	LastAccessedAt int64   `json:"lastAccessedAt"`
	AccessCount    int     `json:"accessCount"`
}

// DecisionEntry represents a recorded decision in the decision journal.
type DecisionEntry struct {
	ID            string  `json:"id"`
	SessionID     string  `json:"sessionId"`
	WorkspaceID   string  `json:"workspaceId"`
	Turn          int     `json:"turn"`
	Observation   string  `json:"observation"`
	Inference     string  `json:"inference,omitempty"`
	Decision      string  `json:"decision"`
	Alternatives  string  `json:"alternatives,omitempty"`
	Outcome       string  `json:"outcome,omitempty"`
	OutcomeDetail string  `json:"outcomeDetail,omitempty"`
	ToolName      string  `json:"toolName,omitempty"`
	ToolArgs      string  `json:"toolArgs,omitempty"`
	Context       string  `json:"context,omitempty"`
	Importance    float64 `json:"importance"`
	CreatedAt     int64   `json:"createdAt"`
}

// System defines the interface for the 3-layer memory system plus decision journal.
type System interface {
	// Working Memory
	WorkingSet(sessionID, key, value string) error
	WorkingGet(sessionID, key string) (string, error)
	WorkingGetAll(sessionID string) ([]WorkingMemoryEntry, error)
	WorkingClear(sessionID string) error

	// Episodic Memory
	RecordEpisode(sessionID, observation, action, outcome, tags string, context map[string]interface{}) error
	QueryEpisodic(query string, limit int) ([]EpisodicMemoryEntry, error)
	GetRecentEpisodes(limit int) ([]EpisodicMemoryEntry, error)

	// Semantic Memory
	StoreSemantic(content, source string, confidence float64, tags string, episodeID string) (string, error)
	QuerySemantic(query string, minConfidence float64, limit int) ([]SemanticMemoryEntry, error)
	ReinforceSemantic(id string) error

	// Decision Journal
	RecordDecision(sessionID, workspaceID string, turn int, observation, inference, decision, alternatives, toolName, toolArgs, context, outcome, outcomeDetail string, importance float64) string
	UpdateDecision(id, outcome, outcomeDetail string) error
	QueryDecisions(query string, limit int) ([]DecisionEntry, error)
	GetDecisionByID(id string) *DecisionEntry
	GetRecentDecisions(limit int) ([]DecisionEntry, error)

	// Semantic Search (embeddings via MCP plugin)
	SetSemanticSearch(ss *rag.SemanticSearch)
}
