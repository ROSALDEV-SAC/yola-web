package config

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

// ─── Raw Catalog Types (models.dev/api.json format) ────────────────────

// CatalogProvider represents a provider in the model catalog.
type CatalogProvider struct {
	ID     string                  `json:"id"`
	Name   string                  `json:"name"`
	API    string                  `json:"api"`             // base URL string
	NPM    string                  `json:"npm,omitempty"`   // SDK package name
	Env    []string                `json:"env"`             // required env vars
	Doc    string                  `json:"doc,omitempty"`
	Models map[string]CatalogModel `json:"models"`
}

// CatalogModel represents a model in the catalog.
type CatalogModel struct {
	ID              string          `json:"id"`
	Name            string          `json:"name"`
	Description     string          `json:"description,omitempty"`
	Family          string          `json:"family,omitempty"`
	Attachment      bool            `json:"attachment"`
	Reasoning       bool            `json:"reasoning"`
	ToolCall        bool            `json:"tool_call"`
	Temperature     bool            `json:"temperature"`
	Interleaved     interface{}     `json:"interleaved,omitempty"`
	StructuredOutput bool           `json:"structured_output,omitempty"`
	Modalities      *ModalitiesRaw  `json:"modalities,omitempty"`
	Cost            *CostRaw        `json:"cost,omitempty"`
	Limit           *LimitRaw       `json:"limit,omitempty"`
	ReleaseDate     string          `json:"release_date,omitempty"`
	Knowledge       string          `json:"knowledge,omitempty"`
	OpenWeights     bool            `json:"open_weights,omitempty"`
}

// ModalitiesRaw describes input/output modalities.
type ModalitiesRaw struct {
	Input  []string `json:"input"`
	Output []string `json:"output"`
}

// CostRaw describes per-token costs (can be string or number in JSON).
type CostRaw struct {
	Input  interface{} `json:"input,omitempty"`
	Output interface{} `json:"output,omitempty"`
}

// LimitRaw describes model limits.
type LimitRaw struct {
	Context     int `json:"context,omitempty"`
	OutputMax   int `json:"output_max,omitempty"`
	InputMax    int `json:"input_max,omitempty"`
}

// ─── Processed Catalog ─────────────────────────────────────────────────

// ProviderEntry is the processed provider entry used by the API.
type ProviderEntry struct {
	ID            string                  `json:"id"`
	Name          string                  `json:"name"`
	API           string                  `json:"api"`
	Models        map[string]ModelEntry   `json:"models"`
}

// ModelEntry is the processed model entry used by the API.
type ModelEntry struct {
	ID              string       `json:"id"`
	Name            string       `json:"name,omitempty"`
	Description     string       `json:"description,omitempty"`
	Family          string       `json:"family,omitempty"`
	Attachment      bool         `json:"attachment"`
	Reasoning       bool         `json:"reasoning"`
	ToolCall        bool         `json:"tool_call"`
	Temperature     bool         `json:"temperature"`
	StructuredOutput bool        `json:"structured_output,omitempty"`
	Context         int          `json:"context"`
	OutputMax       int          `json:"outputMax"`
	InputMax        int          `json:"inputMax"`
	CostInput       string       `json:"costInput,omitempty"`
	CostOutput      string       `json:"costOutput,omitempty"`
	Variants        []VariantDef `json:"variants,omitempty"`
}

// VariantDef defines a named variant configuration for a model.
type VariantDef struct {
	ID          string  `json:"id"`
	Label       string  `json:"label,omitempty"`
	Temperature float64 `json:"temperature,omitempty"`
}

// ─── Catalog ───────────────────────────────────────────────────────────

// Catalog manages the model catalog fetched from models.dev.
type Catalog struct {
	raw      map[string]*CatalogProvider
	builtins map[string]*CatalogProvider
	cacheDir string
}

// NewCatalog creates a new Catalog with the given cache directory.
func NewCatalog(cacheDir string) *Catalog {
	return &Catalog{
		raw:      make(map[string]*CatalogProvider),
		cacheDir: cacheDir,
		builtins: buildBuiltinCatalog(),
	}
}

// Load loads the catalog from cache or fetches it from the network.
// It merges the built-in providers with the remote catalog.
func (c *Catalog) Load() error {
	// Try to load from cache first
	cacheFile := filepath.Join(c.cacheDir, "catalog.json")
	if data, err := os.ReadFile(cacheFile); err == nil {
		var raw map[string]*CatalogProvider
		if json.Unmarshal(data, &raw) == nil {
			c.raw = raw
			c.mergeBuiltins()
			log.Printf("[Catalog] loaded %d providers from cache", len(raw))
			return nil
		}
	}

	// Fetch from models.dev
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Get("https://models.dev/api.json")
	if err != nil {
		// Fall back to builtins only
		log.Printf("[Catalog] fetch failed: %v, using builtins", err)
		c.raw = make(map[string]*CatalogProvider)
		c.mergeBuiltins()
		return nil
	}
	defer resp.Body.Close()

	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("reading response: %w", err)
	}

	var raw map[string]*CatalogProvider
	if err := json.Unmarshal(data, &raw); err != nil {
		return fmt.Errorf("parsing catalog: %w", err)
	}

	// Cache to disk
	if err := os.MkdirAll(c.cacheDir, 0755); err == nil {
		os.WriteFile(cacheFile, data, 0644)
	}

	c.raw = raw
	c.mergeBuiltins()
	log.Printf("[Catalog] loaded %d providers from network", len(raw))
	return nil
}

// mergeBuiltins adds built-in providers (opencode, etc.) to the catalog.
func (c *Catalog) mergeBuiltins() {
	for id, bp := range c.builtins {
		if _, exists := c.raw[id]; !exists {
			c.raw[id] = bp
		}
	}
}

// GetProvider returns a provider by ID.
func (c *Catalog) GetProvider(id string) *CatalogProvider {
	return c.raw[id]
}

// GetModelContextLimit returns the context limit for a given model.
func (c *Catalog) GetModelContextLimit(modelRef ModelRef) int {
	// Default context limit
	const defaultLimit = 128000

	// Extract provider ID and model ID
	providerID := modelRef.ProviderID
	modelID := modelRef.ID

	if providerID == "" {
		// Auto-resolve provider
		for pid, cp := range c.raw {
			if _, ok := cp.Models[modelID]; ok {
				providerID = pid
				break
			}
		}
	}

	cp := c.raw[providerID]
	if cp == nil {
		return defaultLimit
	}
	cm, ok := cp.Models[modelID]
	if !ok {
		return defaultLimit
	}
	if cm.Limit != nil && cm.Limit.Context > 0 {
		return cm.Limit.Context
	}
	return defaultLimit
}

// BuildResponse builds the full provider response for the API.
func (c *Catalog) BuildResponse(apiKeys map[string]string, getVariants func(providerID, modelID string) map[string]interface{}) map[string]interface{} {
	resp := make(map[string]interface{})
	for id, cp := range c.raw {
		key := apiKeys[id]
		connected := key != "" || len(cp.Env) == 0
		entry := ProviderEntry{
			ID:     id,
			Name:   cp.Name,
			API:    cp.API,
			Models: make(map[string]ModelEntry),
		}
		for mid, cm := range cp.Models {
			me := ModelEntry{
				ID:              cm.ID,
				Name:            cm.Name,
				Description:     cm.Description,
				Family:          cm.Family,
				Attachment:      cm.Attachment,
				Reasoning:       cm.Reasoning,
				ToolCall:        cm.ToolCall,
				Temperature:     cm.Temperature,
				StructuredOutput: cm.StructuredOutput,
			}
			if cm.Limit != nil {
				me.Context = cm.Limit.Context
				me.OutputMax = cm.Limit.OutputMax
				me.InputMax = cm.Limit.InputMax
			}
			if cm.Cost != nil {
				me.CostInput = fmt.Sprintf("%v", cm.Cost.Input)
				me.CostOutput = fmt.Sprintf("%v", cm.Cost.Output)
			}
			// Add variants if configured
			if variants := getVariants(id, mid); variants != nil {
				for vid, v := range variants {
					if m, ok := v.(map[string]interface{}); ok {
						var temp float64
						if t, ok := m["temperature"].(float64); ok {
							temp = t
						}
						me.Variants = append(me.Variants, VariantDef{
							ID:          vid,
							Label:       vid,
							Temperature: temp,
						})
					}
				}
			}
			entry.Models[mid] = me
		}
		resp[id] = map[string]interface{}{
			"id":        entry.ID,
			"name":      entry.Name,
			"api":       entry.API,
			"connected": connected,
			"models":    entry.Models,
		}
	}
	return resp
}

// Raw returns the raw catalog data (used by model resolution in agent loop).
func (c *Catalog) Raw() map[string]*CatalogProvider {
	return c.raw
}

// ─── Built-in Providers ────────────────────────────────────────────────

func buildBuiltinCatalog() map[string]*CatalogProvider {
	opencodeProvider := &CatalogProvider{
		ID:   "opencode",
		Name: "OpenCode",
		API:  "https://api.opencode.ai/v1",
		Env:  []string{},
		Models: map[string]CatalogModel{
			"deepseek-v4-flash-free": {
				ID:          "deepseek-v4-flash-free",
				Name:        "DeepSeek v4 Flash (Free)",
				Family:      "deepseek",
				Attachment:  true,
				Reasoning:   true,
				ToolCall:    true,
				Temperature: true,
				Limit: &LimitRaw{
					Context:   200000,
					OutputMax: 8192,
				},
			},
		},
	}

	openaiProvider := &CatalogProvider{
		ID:   "openai",
		Name: "OpenAI",
		API:  "https://api.openai.com/v1",
		Env:  []string{"OPENAI_API_KEY"},
		Models: map[string]CatalogModel{
			"gpt-4o": {
				ID:              "gpt-4o",
				Name:            "GPT-4o",
				Family:          "gpt4",
				Attachment:      true,
				Reasoning:       false,
				ToolCall:        true,
				Temperature:     true,
				StructuredOutput: true,
				Limit: &LimitRaw{Context: 128000, OutputMax: 4096},
			},
			"gpt-4o-mini": {
				ID:              "gpt-4o-mini",
				Name:            "GPT-4o Mini",
				Family:          "gpt4",
				Attachment:      true,
				Reasoning:       false,
				ToolCall:        true,
				Temperature:     true,
				StructuredOutput: true,
				Limit: &LimitRaw{Context: 128000, OutputMax: 4096},
			},
		},
	}

	anthropicProvider := &CatalogProvider{
		ID:   "anthropic",
		Name: "Anthropic",
		API:  "https://api.anthropic.com/v1",
		Env:  []string{"ANTHROPIC_API_KEY"},
		Models: map[string]CatalogModel{
			"claude-sonnet-4": {
				ID:          "claude-sonnet-4",
				Name:        "Claude Sonnet 4",
				Family:      "claude",
				Attachment:  true,
				Reasoning:   false,
				ToolCall:    true,
				Temperature: true,
				Limit:       &LimitRaw{Context: 200000, OutputMax: 8192},
			},
			"claude-haiku-3": {
				ID:          "claude-haiku-3",
				Name:        "Claude Haiku 3",
				Family:      "claude",
				Attachment:  true,
				Reasoning:   false,
				ToolCall:    true,
				Temperature: true,
				Limit:       &LimitRaw{Context: 200000, OutputMax: 4096},
			},
		},
	}

	googleProvider := &CatalogProvider{
		ID:   "google",
		Name: "Google AI",
		API:  "https://generativelanguage.googleapis.com/v1beta",
		Env:  []string{"GEMINI_API_KEY"},
		Models: map[string]CatalogModel{
			"gemini-2.5-pro": {
				ID:          "gemini-2.5-pro",
				Name:        "Gemini 2.5 Pro",
				Family:      "gemini",
				Attachment:  true,
				Reasoning:   true,
				ToolCall:    true,
				Temperature: true,
				Limit:       &LimitRaw{Context: 1000000, OutputMax: 8192},
			},
		},
	}

	return map[string]*CatalogProvider{
		"opencode":  opencodeProvider,
		"openai":    openaiProvider,
		"anthropic": anthropicProvider,
		"google":    googleProvider,
	}
}
