package config

import (
	"encoding/json"
	"fmt"
	"os"
	"sync"

	"github.com/ROSALDEV-SAC/yola-core/tools"
)

// ─── ModelRef ──────────────────────────────────────────────────────────

// ModelRef identifies a model by provider and optional variant.
type ModelRef struct {
	ID         string `json:"id"`
	ProviderID string `json:"providerId"`
	Variant    string `json:"variant,omitempty"`
}

// GetID returns the model ID (satisfies the ModelRefInterface for catalog lookup).
func (m ModelRef) GetID() string { return m.ID }

// GetProviderID returns the provider ID.
func (m ModelRef) GetProviderID() string { return m.ProviderID }

// ─── Config File (providers.json) ───────────────────────────────────────

// ModelVariantDef maps variant name -> config values.
type ModelVariantDef map[string]interface{}

// ProviderVariantDef maps modelID -> variants.
type ProviderVariantDef map[string]ModelVariantDef

// AgentDef defines an agent from the providers.json config.
type AgentDef struct {
	Name         string   `json:"name"`
	Description  string   `json:"description"`
	SystemPrompt string   `json:"systemPrompt,omitempty"`
	Model        string   `json:"model,omitempty"`
	Provider     string   `json:"provider,omitempty"`
	Tools        []string `json:"tools,omitempty"`
	Skills       []string `json:"skills,omitempty"`
	CanDelegate  bool     `json:"canDelegate,omitempty"`
}

// SkillDef defines a skill bundle of tools from the config.
type SkillDef struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	Tools       []SkillToolDef `json:"tools"`
}

// SkillToolDef defines a single tool within a skill.
type SkillToolDef struct {
	Name            string     `json:"name"`
	Description     string     `json:"description"`
	Parameters      tools.ToolSchema `json:"parameters"`
	Handler         string     `json:"handler"` // "bash" or "builtin"
	Command         string     `json:"command,omitempty"`
	CommandTemplate string     `json:"command_template,omitempty"`
}

// MCPServerConfig defines the configuration for an MCP server from providers.json.
type MCPServerConfig struct {
	Name    string            `json:"-"` // set from map key
	Command string            `json:"command"`
	Args    []string          `json:"args"`
	Env     map[string]string `json:"env,omitempty"`
}

// ConfigFile is the top-level structure of providers.json.
type ConfigFile struct {
	Version       int                            `json:"version"`
	APIKeys       map[string]string              `json:"apiKeys"`
	ModelVariants map[string]ProviderVariantDef  `json:"modelVariants,omitempty"`
	Agents        map[string]*AgentDef           `json:"agents,omitempty"`
	Skills        map[string]*SkillDef           `json:"skills,omitempty"`
	MCPServers    map[string]*MCPServerConfig    `json:"mcpServers,omitempty"`
}

// ─── Runtime State ─────────────────────────────────────────────────────

// ProviderKeys holds the runtime API keys, model variants, agents, skills, and MCP servers.
type ProviderKeys struct {
	mu            sync.RWMutex
	apiKeys       map[string]string
	modelVariants map[string]ProviderVariantDef
	agents        map[string]*AgentDef
	skills        map[string]*SkillDef
	mcpServers    map[string]*MCPServerConfig
}

// LoadProviderKeys reads providers.json and returns a ProviderKeys instance.
func LoadProviderKeys(path string) (*ProviderKeys, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("reading %s: %w", path, err)
	}

	var cfg ConfigFile
	if err := json.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("parsing %s: %w", path, err)
	}

	pk := &ProviderKeys{
		apiKeys:       make(map[string]string),
		modelVariants: make(map[string]ProviderVariantDef),
		agents:        make(map[string]*AgentDef),
		skills:        make(map[string]*SkillDef),
		mcpServers:    make(map[string]*MCPServerConfig),
	}
	for id, key := range cfg.APIKeys {
		pk.apiKeys[id] = key
	}
	if cfg.ModelVariants != nil {
		pk.modelVariants = cfg.ModelVariants
	}
	if cfg.Agents != nil {
		pk.agents = cfg.Agents
	}
	if cfg.Skills != nil {
		pk.skills = cfg.Skills
	}
	if cfg.MCPServers != nil {
		for name, sc := range cfg.MCPServers {
			sc.Name = name
			pk.mcpServers[name] = sc
		}
	}

	return pk, nil
}

// ─── Methods ────────────────────────────────────────────────────────────

func (pk *ProviderKeys) GetKey(providerID string) (string, bool) {
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	key, ok := pk.apiKeys[providerID]
	return key, ok
}

func (pk *ProviderKeys) SetKey(providerID, apiKey string) {
	pk.mu.Lock()
	defer pk.mu.Unlock()
	pk.apiKeys[providerID] = apiKey
}

// Snapshot returns a thread-safe copy of all API keys.
func (pk *ProviderKeys) Snapshot() map[string]string {
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	snap := make(map[string]string, len(pk.apiKeys))
	for k, v := range pk.apiKeys {
		snap[k] = v
	}
	return snap
}

// SaveToFile writes the current API keys back to the config file on disk.
func (pk *ProviderKeys) SaveToFile(path string) error {
	snap := pk.Snapshot()
	data, err := os.ReadFile(path)
	if err != nil {
		return fmt.Errorf("reading %s: %w", path, err)
	}
	var cfg map[string]interface{}
	if err := json.Unmarshal(data, &cfg); err != nil {
		return fmt.Errorf("parsing %s: %w", path, err)
	}
	apiKeysMap := make(map[string]interface{})
	for k, v := range snap {
		apiKeysMap[k] = v
	}
	cfg["apiKeys"] = apiKeysMap
	out, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return fmt.Errorf("marshaling: %w", err)
	}
	if err := os.WriteFile(path, out, 0644); err != nil {
		return fmt.Errorf("writing %s: %w", path, err)
	}
	return nil
}

func (pk *ProviderKeys) GetVariants(providerID, modelID string) map[string]interface{} {
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	pv, ok := pk.modelVariants[providerID]
	if !ok {
		return nil
	}
	variants, ok := pv[modelID]
	if !ok {
		return nil
	}
	return variants
}

func (pk *ProviderKeys) GetAgent(id string) (*AgentDef, bool) {
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	a, ok := pk.agents[id]
	if !ok {
		return nil, false
	}
	return a, true
}

func (pk *ProviderKeys) GetAgentList() []struct {
	ID          string   `json:"id"`
	Name        string   `json:"name,omitempty"`
	Description string   `json:"description,omitempty"`
	Mode        string   `json:"mode,omitempty"`
	Model       string   `json:"model,omitempty"`
	Provider    string   `json:"provider,omitempty"`
	Tools       []string `json:"tools,omitempty"`
	Skills      []string `json:"skills,omitempty"`
} {
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	// Return type adapted for API response
	type AgentInfo struct {
		ID          string   `json:"id"`
		Name        string   `json:"name,omitempty"`
		Description string   `json:"description,omitempty"`
		Mode        string   `json:"mode,omitempty"`
		Model       string   `json:"model,omitempty"`
		Provider    string   `json:"provider,omitempty"`
		Tools       []string `json:"tools,omitempty"`
		Skills      []string `json:"skills,omitempty"`
	}
	list := make([]AgentInfo, 0, len(pk.agents))
	for id, a := range pk.agents {
		list = append(list, AgentInfo{
			ID:          id,
			Name:        a.Name,
			Description: a.Description,
			Mode:        "primary",
			Model:       a.Model,
			Provider:    a.Provider,
			Tools:       a.Tools,
			Skills:      a.Skills,
		})
	}
	// Can't return local type, convert to anonymous
	result := make([]struct {
		ID          string   `json:"id"`
		Name        string   `json:"name,omitempty"`
		Description string   `json:"description,omitempty"`
		Mode        string   `json:"mode,omitempty"`
		Model       string   `json:"model,omitempty"`
		Provider    string   `json:"provider,omitempty"`
		Tools       []string `json:"tools,omitempty"`
		Skills      []string `json:"skills,omitempty"`
	}, len(list))
	for i, a := range list {
		result[i] = struct {
			ID          string   `json:"id"`
			Name        string   `json:"name,omitempty"`
			Description string   `json:"description,omitempty"`
			Mode        string   `json:"mode,omitempty"`
			Model       string   `json:"model,omitempty"`
			Provider    string   `json:"provider,omitempty"`
			Tools       []string `json:"tools,omitempty"`
			Skills      []string `json:"skills,omitempty"`
		}{a.ID, a.Name, a.Description, a.Mode, a.Model, a.Provider, a.Tools, a.Skills}
	}
	return result
}

func (pk *ProviderKeys) GetSkills() map[string]*SkillDef {
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	skills := make(map[string]*SkillDef, len(pk.skills))
	for k, v := range pk.skills {
		skills[k] = v
	}
	return skills
}

func (pk *ProviderKeys) AddSkill(name string, def *SkillDef) {
	pk.mu.Lock()
	defer pk.mu.Unlock()
	pk.skills[name] = def
}

func (pk *ProviderKeys) GetSkillTools(skillIDs []string) []struct {
	Name        string      `json:"name"`
	Description string      `json:"description"`
	Parameters  tools.ToolSchema  `json:"parameters"`
	Handler     interface{} `json:"-"` // actual handler, set by tools
} {
	// Returns tool-like structs; the caller (tools) wraps them with handlers
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	type toolLike struct {
		Name        string     `json:"name"`
		Description string     `json:"description"`
		Parameters  tools.ToolSchema `json:"parameters"`
		Handler     interface{} `json:"-"`
	}
	var result []toolLike
	for _, sid := range skillIDs {
		skill, ok := pk.skills[sid]
		if !ok {
			continue
		}
		for _, t := range skill.Tools {
			result = append(result, toolLike{
				Name:        t.Name,
				Description: t.Description,
				Parameters:  t.Parameters,
			})
		}
	}
	// Convert to anonymous structs
	out := make([]struct {
		Name        string      `json:"name"`
		Description string      `json:"description"`
		Parameters  tools.ToolSchema  `json:"parameters"`
		Handler     interface{} `json:"-"`
	}, len(result))
	for i, r := range result {
		out[i] = struct {
			Name        string      `json:"name"`
			Description string      `json:"description"`
			Parameters  tools.ToolSchema  `json:"parameters"`
			Handler     interface{} `json:"-"`
		}{r.Name, r.Description, r.Parameters, nil}
	}
	return out
}

func (pk *ProviderKeys) GetMCPServers() []*MCPServerConfig {
	pk.mu.RLock()
	defer pk.mu.RUnlock()
	list := make([]*MCPServerConfig, 0, len(pk.mcpServers))
	for _, sc := range pk.mcpServers {
		list = append(list, sc)
	}
	return list
}

// SetAgents replaces the agents map (used by MCP dynamic tool registration).
func (pk *ProviderKeys) SetAgents(agents map[string]*AgentDef) {
	pk.mu.Lock()
	defer pk.mu.Unlock()
	pk.agents = agents
}

// LoadDBSkills loads user-created skills from the database into the runtime config.
func (pk *ProviderKeys) LoadDBSkills(execer interface {
	Query(query string, args ...interface{}) (interface {
		Next() bool
		Scan(dest ...interface{}) error
		Close() error
	}, error)
}) {
	// This is a simplified version; actual implementation uses database/sql rows.
	// The real implementation is in the original main.go wiring.
}

// GetAPIKeys returns a copy of all API keys (for agent loop usage).
func (pk *ProviderKeys) GetAPIKeys() map[string]string {
	return pk.Snapshot()
}
