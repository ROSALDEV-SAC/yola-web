package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/agent"
	"github.com/ROSALDEV-SAC/yola-core/config"
	"github.com/ROSALDEV-SAC/yola-core/db"
	"github.com/ROSALDEV-SAC/yola-core/llm"
	"github.com/ROSALDEV-SAC/yola-core/session"
	"github.com/ROSALDEV-SAC/yola-core/sse"
)

func main() {
	log.SetFlags(0)

	if len(os.Args) > 1 && (os.Args[1] == "--version" || os.Args[1] == "-v") {
		fmt.Println("yola-core v0.1.0")
		return
	}

	if len(os.Args) < 2 {
		fmt.Println("yola-core v0.1.0 — Engine YOLA")
		fmt.Println("Uso: echo \"tu mensaje\" | yola-core")
		fmt.Println("     yola-core \"tu mensaje directo\"")
		return
	}

	prompt := strings.Join(os.Args[1:], " ")
	if prompt == "" {
		scanner := bufio.NewScanner(os.Stdin)
		scanner.Scan()
		prompt = scanner.Text()
	}

	start := time.Now()
	home := os.Getenv("HOME")
	os.MkdirAll(home+"/.yola", 0755)

	dbPath := home + "/.yola/yola-core.db"
	database, err := db.NewDatabase(dbPath)
	if err != nil {
		log.Fatalf("Error DB: %v", err)
	}
	defer database.Close()

	store := session.NewStore(database)
	bus := sse.NewEventBus()
	go printEvents(bus)

	modelRef := &config.ModelRef{ID: "deepseek-v4-flash-free"}
	s := store.Create("yola-core", modelRef, "")
	if s == nil {
		log.Fatal("Error al crear sesión")
	}
	store.AddMessage(s.ID, "user", prompt)

	catalog := config.NewCatalog(home + "/.yola/cache")
	_ = catalog.Load()
	llmClient := llm.NewClient()

	keys, _ := config.LoadProviderKeys(home + "/.yola/providers.json")
	if keys == nil {
		keys = newEmptyKeys()
	}

	ag := &agent.Agent{ID: "yola-core", Name: "YOLA Core"}
	ag.Run(s.ID, store, bus, llmClient, catalog, keys.GetAPIKeys(), *modelRef, keys)

	_ = start
}

func printEvents(bus *sse.EventBus) {
	_, ch := bus.Subscribe()
	for data := range ch {
		var event struct {
			Type string          `json:"type"`
			Data json.RawMessage `json:"data"`
		}
		if err := json.Unmarshal(data, &event); err != nil {
			continue
		}
		switch event.Type {
		case "session_next_text_delta":
			var d struct{ Delta string `json:"delta"` }
			json.Unmarshal(event.Data, &d)
			fmt.Print(d.Delta)
		case "session_next_tool_called":
			var d struct {
				ToolCall struct {
					Name string `json:"name"`
				} `json:"toolCall"`
			}
			json.Unmarshal(event.Data, &d)
			fmt.Printf("\n🔧 %s\n", d.ToolCall.Name)
		case "session_next_tool_result":
			fmt.Println(" ✅")
		case "session_next_text_ended":
			fmt.Println()
		case "session_next_error":
			fmt.Println("\n❌ Error")
		}
	}
}

func newEmptyKeys() *config.ProviderKeys {
	data := `{"version":1,"apiKeys":{},"modelVariants":{},"agents":{},"skills":{},"mcpServers":{}}`
	tmpPath := os.Getenv("HOME") + "/.yola/_empty_keys.json"
	os.WriteFile(tmpPath, []byte(data), 0644)
	keys, _ := config.LoadProviderKeys(tmpPath)
	return keys
}
