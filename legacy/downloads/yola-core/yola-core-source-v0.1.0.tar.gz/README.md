# yola-core

Engine YOLA como librería Go independiente. Sin HTTP, sin servidor, sin UI. Solo el agente, las herramientas y la persistencia.

## Paquetes

| Package | Propósito |
|---------|-----------|
| `agent` | Loop principal del agente, delegación, tasks |
| `tools` | Ejecución de herramientas (read, write, bash, grep, etc.) |
| `session` | Persistencia de sesiones en SQLite |
| `llm` | Clientes LLM (OpenCode, OpenAI, compatibles) |
| `db` | Conexión a base de datos SQLite |
| `sse` | Sistema de eventos Server-Sent Events |
| `config` | Catálogo de proveedores y configuración |
| `governor` | Clasificador de mensajes |
| `memory` | Memoria episódica y semántica |

## Uso

```go
import "github.com/ROSALDEV-SAC/yola-core/agent"
import "github.com/ROSALDEV-SAC/yola-core/session"
```

## Ecosistema

| Producto | Qué hace | Dónde está |
|----------|----------|------------|
| **yola-core** | ⬅️ Engine puro | github.com/ROSALDEV-SAC/yola-core |
| [yola-cli](https://github.com/ROSALDEV-SAC/yola-cli) | YOLA desde la terminal | github.com/ROSALDEV-SAC/yola-cli |
| [no-yolaCEO](https://github.com/ROSALDEV-SAC/no-yolaCEO) | Buscador multirepo sin IA | github.com/ROSALDEV-SAC/no-yolaCEO |
