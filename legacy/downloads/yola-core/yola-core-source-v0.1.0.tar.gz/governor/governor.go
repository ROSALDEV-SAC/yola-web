package governor

import (
	"fmt"
	"strings"
)

// DirectCall represents a parsed direct tool invocation (no LLM needed).
type DirectCall struct {
	ToolName string
	Args     map[string]interface{}
}

// Classification holds the result of classifying a user request.
type Classification struct {
	DirectCall *DirectCall // populated when input is a direct command
}

// Context provides session context for classification (reserved for future use).
type Context struct {
	WorkspaceID string
	SessionID   string
}

// Governor classifies user requests.
// Only detects direct tool commands. Everything else goes to the LLM.
type Governor struct{}

// NewGovernor creates a new Governor.
func NewGovernor(_ interface{}) *Governor {
	return &Governor{}
}

// Classify analyzes a user request and returns a Classification.
// Returns a DirectCall only if the input is parseable as a direct tool command.
// Returns nil DirectCall for everything else (let the LLM handle it).
func (g *Governor) Classify(text string, _ Context) Classification {
	if dc := parseDirectCall(text); dc != nil {
		return Classification{DirectCall: dc}
	}
	return Classification{}
}

// parseDirectCall attempts to parse text as a direct tool invocation.
func parseDirectCall(text string) *DirectCall {
	text = strings.TrimSpace(text)
	if text == "" {
		return nil
	}

	parts := strings.SplitN(text, " ", 2)
	if len(parts) == 0 {
		return nil
	}

	toolName := strings.ToLower(strings.TrimSpace(parts[0]))

	// Only recognize registered tool names
	if !isRegisteredTool(toolName) {
		return nil
	}

	dc := &DirectCall{ToolName: toolName, Args: make(map[string]interface{})}

	if len(parts) > 1 {
		arg := strings.TrimSpace(parts[1])
		if arg != "" {
			switch toolName {
			case "read", "write", "edit":
				dc.Args["filePath"] = arg
			case "grep", "glob":
				dc.Args["pattern"] = arg
			case "bash":
				dc.Args["command"] = arg
			case "code_rag":
				dc.Args["query"] = arg
			case "search_symbol":
				dc.Args["name"] = arg
			case "webfetch":
				dc.Args["url"] = arg
			case "websearch":
				dc.Args["query"] = arg
			default:
				dc.Args["input"] = arg
			}
		}
	}

	return dc
}

// isRegisteredTool checks if a tool name is recognized for direct invocation.
var registeredTools = map[string]bool{
	"read": true, "write": true, "edit": true, "bash": true,
	"grep": true, "glob": true, "code_rag": true, "search_symbol": true,
	"trace_imports": true, "websearch": true, "webfetch": true,
}

func isRegisteredTool(name string) bool {
	return registeredTools[name]
}

// Ensure DirectCall remains non-nil usage compatible with existing handlers.
func (c Classification) IsDirect() bool {
	return c.DirectCall != nil
}

// String representation for debugging.
func (dc *DirectCall) String() string {
	return fmt.Sprintf("%s(%v)", dc.ToolName, dc.Args)
}
