package sse

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"sync"
	"time"
)

// ─── Event Types ────────────────────────────────────────────────────────

const (
	// ── Session events ───
	EventSessionCreated   = "session_created"
	EventSessionDeleted   = "session_deleted"
	EventSessionUpdated   = "session_updated"
	EventMessageUpdated   = "message_updated"

	// ── Text / streaming events ───
	EventTextDelta = "session_next_text_delta"
	EventTextEnded = "session_next_text_ended"

	// ── Step events ───
	EventStepStarted = "session_next_step_started"
	EventStepEnded   = "session_next_step_ended"
	EventStepFailed  = "session_next_step_failed"

	// ── Tool events ───
	EventToolCalled   = "session_next_tool_called"
	EventToolResult   = "session_next_tool_result"
	EventToolProgress = "session_next_tool_progress"
	EventToolFailed   = "session_next_tool_failed"

	// ── Reasoning events ───
	EventReasoningStarted = "session_next_reasoning_started"
	EventReasoningDelta   = "session_next_reasoning_delta"
	EventReasoningEnded   = "session_next_reasoning_ended"

	// ── Shell events ───
	EventShellStarted = "session_next_shell_started"
	EventShellEnded   = "session_next_shell_ended"

	// ── Interrupt / context ───
	EventInterruptRequested = "session_next_interrupt_requested"
	EventContextUpdated     = "session_next_context_updated"

	// ── Task events ───
	EventTaskStarted   = "task_started"
	EventTaskCompleted = "task_completed"
	EventTaskFailed    = "task_failed"

	// ── Error ───
	EventError = "session_next_error"
)

// Event represents a single event to be broadcast to subscribers.
type Event struct {
	Type string      `json:"type"`
	Data interface{} `json:"data,omitempty"`
}

// ─── Helper Constructors ─────────────────────────────────────────────────

// NewTextDeltaEvent creates a text delta (streaming) event.
func NewTextDeltaEvent(sessionID, delta string) Event {
	return Event{
		Type: EventTextDelta,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"delta":     delta,
		},
	}
}

// NewTextEndedEvent creates a text ended event.
func NewTextEndedEvent(sessionID string) Event {
	return Event{
		Type: EventTextEnded,
		Data: map[string]interface{}{
			"sessionId": sessionID,
		},
	}
}

// NewSessionUpdatedEvent creates a session updated event.
func NewSessionUpdatedEvent(sessionID string) Event {
	return Event{
		Type: EventSessionUpdated,
		Data: map[string]interface{}{
			"sessionId": sessionID,
		},
	}
}

// NewMessageUpdatedEvent creates a message updated event.
func NewMessageUpdatedEvent(sessionID, msgID string) Event {
	return Event{
		Type: EventMessageUpdated,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"messageId": msgID,
		},
	}
}

// NewErrorEvent creates an error event.
// NOTE: Both "message" and "delta" fields are included for compatibility:
// - "message" is read by the web UI frontends (chat.js, index.html)
// - "delta" is used internally by SSE stream consumers
func NewErrorEvent(sessionID, errMsg string) Event {
	return Event{
		Type: EventError,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"message":   errMsg,
			"delta":     errMsg,
		},
	}
}

// NewStepStartedEvent creates a step started event.
func NewStepStartedEvent(sessionID, stepID, title string) Event {
	return Event{
		Type: EventStepStarted,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"stepId":    stepID,
			"title":     title,
		},
	}
}

// NewStepEndedEvent creates a step ended event.
func NewStepEndedEvent(sessionID, stepID, status string) Event {
	return Event{
		Type: EventStepEnded,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"stepId":    stepID,
			"status":    status,
		},
	}
}

// NewStepFailedEvent creates a step failed event.
func NewStepFailedEvent(sessionID, stepID, errMsg string) Event {
	return Event{
		Type: EventStepFailed,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"stepId":    stepID,
			"error":     errMsg,
		},
	}
}

// NewToolCalledEvent creates a tool called event.
func NewToolCalledEvent(sessionID, callID, toolName, args string) Event {
	return Event{
		Type: EventToolCalled,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"toolCall": map[string]interface{}{
				"id":        callID,
				"name":      toolName,
				"arguments": args,
				"status":    "running",
			},
		},
	}
}

// NewToolResultEvent creates a tool result event.
func NewToolResultEvent(sessionID, callID, toolName, result string) Event {
	return Event{
		Type: EventToolResult,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"toolCall": map[string]interface{}{
				"id":     callID,
				"name":   toolName,
				"result": result,
			},
		},
	}
}

// NewToolProgressEvent creates a tool progress event.
func NewToolProgressEvent(sessionID, callID, toolName, status string) Event {
	return Event{
		Type: EventToolProgress,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"toolCall": map[string]interface{}{
				"id":     callID,
				"name":   toolName,
				"status": status,
			},
		},
	}
}

// NewToolFailedEvent creates a tool failed event.
func NewToolFailedEvent(sessionID, callID, toolName, errMsg string) Event {
	return Event{
		Type: EventToolFailed,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"toolCall": map[string]interface{}{
				"id":     callID,
				"name":   toolName,
				"error":  errMsg,
			},
		},
	}
}

// NewReasoningStartedEvent creates a reasoning started event.
func NewReasoningStartedEvent(sessionID string) Event {
	return Event{
		Type: EventReasoningStarted,
		Data: map[string]interface{}{
			"sessionId": sessionID,
		},
	}
}

// NewReasoningDeltaEvent creates a reasoning delta event.
func NewReasoningDeltaEvent(sessionID, delta string) Event {
	return Event{
		Type: EventReasoningDelta,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"delta":     delta,
		},
	}
}

// NewReasoningEndedEvent creates a reasoning ended event.
func NewReasoningEndedEvent(sessionID string) Event {
	return Event{
		Type: EventReasoningEnded,
		Data: map[string]interface{}{
			"sessionId": sessionID,
		},
	}
}

// NewShellStartedEvent creates a shell started event.
func NewShellStartedEvent(sessionID, shellID, command string) Event {
	return Event{
		Type: EventShellStarted,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"shellId":   shellID,
			"command":   command,
		},
	}
}

// NewShellEndedEvent creates a shell ended event.
func NewShellEndedEvent(sessionID, shellID, output string, exitCode int) Event {
	return Event{
		Type: EventShellEnded,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"shellId":   shellID,
			"output":    output,
			"exitCode":  exitCode,
		},
	}
}

// NewInterruptRequestedEvent creates an interrupt requested event.
func NewInterruptRequestedEvent(sessionID, reason string) Event {
	return Event{
		Type: EventInterruptRequested,
		Data: map[string]interface{}{
			"sessionId": sessionID,
			"reason":    reason,
		},
	}
}

// NewContextUpdatedEvent creates a context updated event.
func NewContextUpdatedEvent(sessionID string, contextSize int) Event {
	return Event{
		Type: EventContextUpdated,
		Data: map[string]interface{}{
			"sessionId":   sessionID,
			"contextSize": contextSize,
		},
	}
}

// ─── Task Event Constructors ──────────────────────────────────────────────

// NewTaskStartedEvent creates a task started event.
func NewTaskStartedEvent(parentSessionID, taskID, agentType, description string) Event {
	return Event{
		Type: EventTaskStarted,
		Data: map[string]interface{}{
			"sessionId":   parentSessionID,
			"taskId":      taskID,
			"agentType":   agentType,
			"description": description,
		},
	}
}

// NewTaskCompletedEvent creates a task completed event.
func NewTaskCompletedEvent(parentSessionID, taskID, summary, result string) Event {
	return Event{
		Type: EventTaskCompleted,
		Data: map[string]interface{}{
			"sessionId": parentSessionID,
			"taskId":    taskID,
			"summary":   summary,
			"result":    result,
		},
	}
}

// NewTaskFailedEvent creates a task failed event.
func NewTaskFailedEvent(parentSessionID, taskID, error string) Event {
	return Event{
		Type: EventTaskFailed,
		Data: map[string]interface{}{
			"sessionId": parentSessionID,
			"taskId":    taskID,
			"error":     error,
		},
	}
}

// ─── Subscriber ─────────────────────────────────────────────────────────

// subscriber wraps a channel for SSE event streaming.
type subscriber struct {
	ch chan []byte
}

// ─── Bus ────────────────────────────────────────────────────────────────

// EventBus is a publish-subscribe bus for streaming server-sent events.
type EventBus struct {
	mu       sync.RWMutex
	channels map[string]*subscriber
}

// NewEventBus creates a new EventBus.
func NewEventBus() *EventBus {
	return &EventBus{
		channels: make(map[string]*subscriber),
	}
}

func newSubID() string {
	b := make([]byte, 8)
	rand.Read(b)
	return "sub_" + hex.EncodeToString(b)
}

// Subscribe registers a new subscriber and returns the subscriber ID and channel.
func (eb *EventBus) Subscribe() (string, <-chan []byte) {
	id := newSubID()
	sub := &subscriber{ch: make(chan []byte, 4096)}
	eb.mu.Lock()
	eb.channels[id] = sub
	eb.mu.Unlock()
	return id, sub.ch
}

// Unsubscribe removes a subscriber by ID and cleans up its channel.
// NOTE: we do NOT close the channel here — the subscriber's reader loop
// exits via ctx.Done() (see handlers_sse.go). Closing while a concurrent
// Publish is sending to the channel would panic "send on closed channel".
// The channel will be garbage collected when no longer referenced.
func (eb *EventBus) Unsubscribe(id string) {
	eb.mu.Lock()
	delete(eb.channels, id)
	eb.mu.Unlock()
}

// Publish sends an event to all subscribers. It tries a blocking send first
// with a 100ms timeout per subscriber. If the subscriber doesn't drain in time
// (e.g. disconnected without Unsubscribe), the event is dropped for that
// subscriber to prevent the publisher from blocking indefinitely.
// This guarantees no event is dropped for healthy subscribers running at
// real-time streaming speeds, while preventing deadlocks from zombie clients.
func (eb *EventBus) Publish(event Event) {
	data, err := json.Marshal(event)
	if err != nil {
		return
	}
	eb.mu.RLock()
	subs := make([]*subscriber, 0, len(eb.channels))
	for _, sub := range eb.channels {
		subs = append(subs, sub)
	}
	eb.mu.RUnlock()

	timer := time.NewTimer(100 * time.Millisecond)
	defer timer.Stop()

	for _, sub := range subs {
		// Reset timer for each subscriber.
		// Use a non-blocking drain: if timer.C was already consumed by the
		// select's timeout case in the previous iteration, the channel is
		// empty and we skip the drain. If it has a value (timer fired
		// concurrently with a successful send), we drain it.
		if !timer.Stop() {
			select {
			case <-timer.C:
			default:
			}
		}
		timer.Reset(100 * time.Millisecond)

		select {
		case sub.ch <- data:
		case <-timer.C:
			// Subscriber too slow or disconnected — drop event for this subscriber
		}
	}
}
