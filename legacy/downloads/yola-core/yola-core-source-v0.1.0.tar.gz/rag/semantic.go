package rag

import (
	"encoding/json"
	"fmt"
	"log"
	"sync"
)

// ─── Interface ───────────────────────────────────────────────────────────

// MCPCaller defines the subset of MCP operations needed for semantic search.
// The main MCPManager (in package main) satisfies this interface.
type MCPCaller interface {
	CallTool(name string, args map[string]interface{}) (string, error)
	HasTool(name string) bool
}

// ─── Types ───────────────────────────────────────────────────────────────

// SearchResult represents a ranked semantic search result.
type SearchResult struct {
	Content string  `json:"content"`
	Score   float64 `json:"score"`
}

// SemanticSearch provides embedding-based semantic search via an MCP plugin.
// It connects to an embeddings plugin (JSON-RPC over stdio) through the
// MCP caller interface and maintains a cache of recent embeddings.
type SemanticSearch struct {
	caller  MCPCaller
	enabled bool
	cache   *embedCache
}

// embedCache is a simple bounded cache for embedding vectors.
type embedCache struct {
	mu      sync.RWMutex
	max     int
	entries map[string][]float64
}

func newEmbedCache(max int) *embedCache {
	return &embedCache{
		max:     max,
		entries: make(map[string][]float64),
	}
}

func (c *embedCache) Get(key string) ([]float64, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	v, ok := c.entries[key]
	return v, ok
}

func (c *embedCache) Set(key string, val []float64) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if len(c.entries) >= c.max {
		// Evict first entry (simple FIFO-like)
		for k := range c.entries {
			delete(c.entries, k)
			break
		}
	}
	c.entries[key] = val
}

// ─── Constructor ─────────────────────────────────────────────────────────

// NewSemanticSearch creates a SemanticSearch backed by the given MCP caller.
// It detects availability by checking for the "rag_embed" tool.
func NewSemanticSearch(caller MCPCaller) *SemanticSearch {
	ss := &SemanticSearch{
		caller:  caller,
		enabled: caller != nil && caller.HasTool("rag_embed"),
		cache:   newEmbedCache(100),
	}
	if !ss.enabled {
		log.Println("[SemanticSearch] not available: no MCP plugin with 'rag_embed' tool")
	} else {
		log.Println("[SemanticSearch] available via MCP plugin")
	}
	return ss
}

// IsAvailable returns true if the embeddings plugin is connected and ready.
func (s *SemanticSearch) IsAvailable() bool {
	return s.enabled
}

// ─── Embed ───────────────────────────────────────────────────────────────

// Embed generates an embedding vector for the given text via the MCP plugin.
// Results are cached for reuse.
func (s *SemanticSearch) Embed(text string) ([]float64, error) {
	if !s.enabled {
		return nil, fmt.Errorf("semantic search not available")
	}

	// Check cache first
	if emb, ok := s.cache.Get(text); ok {
		return emb, nil
	}

	result, err := s.caller.CallTool("rag_embed", map[string]interface{}{
		"text": text,
	})
	if err != nil {
		return nil, fmt.Errorf("embed MCP call: %w", err)
	}

	var resp struct {
		Embedding []float64 `json:"embedding"`
	}
	if err := json.Unmarshal([]byte(result), &resp); err != nil {
		return nil, fmt.Errorf("parse embed response: %w", err)
	}

	s.cache.Set(text, resp.Embedding)
	return resp.Embedding, nil
}

// ─── Search ──────────────────────────────────────────────────────────────

// Search performs semantic search over the given items, returning the topK
// results ranked by relevance score.
func (s *SemanticSearch) Search(query string, items []string, topK int) ([]SearchResult, error) {
	if !s.enabled {
		return nil, fmt.Errorf("semantic search not available")
	}
	if len(items) == 0 {
		return nil, nil
	}
	if topK <= 0 {
		topK = 10
	}

	result, err := s.caller.CallTool("rag_search", map[string]interface{}{
		"query": query,
		"items": items,
		"topK":  topK,
	})
	if err != nil {
		return nil, fmt.Errorf("search MCP call: %w", err)
	}

	var resp struct {
		Results []SearchResult `json:"results"`
	}
	if err := json.Unmarshal([]byte(result), &resp); err != nil {
		return nil, fmt.Errorf("parse search response: %w", err)
	}

	return resp.Results, nil
}
