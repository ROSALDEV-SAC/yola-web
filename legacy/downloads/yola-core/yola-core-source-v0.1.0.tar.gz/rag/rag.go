package rag

import (
	"log"
	"os"
	"path/filepath"
	"strings"
	"unicode"
)

// CodeChunk represents a section of source code with its location.
type CodeChunk struct {
	File      string `json:"file"`
	StartLine int    `json:"startLine"`
	EndLine   int    `json:"endLine"`
	Content   string `json:"content"`
}

// CodeIndex is a lightweight keyword-based search index over Go source files.
type CodeIndex struct {
	chunks []CodeChunk
	index  map[string][]int // keyword -> indices into chunks
}

// NewCodeIndex builds an index from all .go files under the given directory.
func NewCodeIndex(rootDir string) *CodeIndex {
	ci := &CodeIndex{index: make(map[string][]int)}

	// Walk Go source files (skip test files and vendor)
	filepath.Walk(rootDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		if !strings.HasSuffix(path, ".go") || strings.HasSuffix(path, "_test.go") {
			return nil
		}

		data, err := os.ReadFile(path)
		if err != nil {
			return nil
		}
		lines := strings.Split(string(data), "\n")
		relPath := strings.TrimPrefix(path, rootDir+string(filepath.Separator))

		// Split into chunks by function/type declarations (50-line sliding windows)
		const chunkSize = 50
		const chunkOverlap = 15
		for i := 0; i < len(lines); i += chunkSize - chunkOverlap {
			end := i + chunkSize
			if end > len(lines) {
				end = len(lines)
			}
			content := strings.Join(lines[i:end], "\n")
			chunkIdx := len(ci.chunks)
			ci.chunks = append(ci.chunks, CodeChunk{
				File:      relPath,
				StartLine: i + 1,
				EndLine:   end,
				Content:   content,
			})
			// Index keywords from this chunk
			words := tokenize(content)
			for _, word := range words {
				if len(word) < 3 {
					continue
				}
				ci.index[word] = append(ci.index[word], chunkIdx)
			}
		}
		return nil
	})

	log.Printf("[CodeIndex] indexed %d chunks from %s", len(ci.chunks), rootDir)
	return ci
}

// Search performs a keyword search and returns up to maxResults matching chunks.
// Matching chunks are scored by keyword frequency and returned in descending order.
func (ci *CodeIndex) Search(query string, maxResults int) []CodeChunk {
	if maxResults <= 0 {
		maxResults = 10
	}

	words := tokenize(query)
	if len(words) == 0 {
		return nil
	}

	// Score each chunk by keyword frequency
	scores := make(map[int]int)
	for _, word := range words {
		if indices, ok := ci.index[word]; ok {
			for _, idx := range indices {
				scores[idx]++
			}
		}
	}

	if len(scores) == 0 {
		return nil
	}

	// Sort by score descending
	type scored struct {
		idx   int
		score int
	}
	sorted := make([]scored, 0, len(scores))
	for idx, score := range scores {
		sorted = append(sorted, scored{idx, score})
	}
	// Simple bubble sort for small result sets
	for i := 0; i < len(sorted); i++ {
		for j := i + 1; j < len(sorted); j++ {
			if sorted[j].score > sorted[i].score {
				sorted[i], sorted[j] = sorted[j], sorted[i]
			}
		}
	}

	// Collect top results (deduplicate by chunk index)
	seen := make(map[int]bool)
	results := make([]CodeChunk, 0, maxResults)
	for _, s := range sorted {
		if seen[s.idx] {
			continue
		}
		seen[s.idx] = true
		results = append(results, ci.chunks[s.idx])
		if len(results) >= maxResults {
			break
		}
	}
	return results
}

// tokenize splits text into lowercase words, removing punctuation.
func tokenize(text string) []string {
	var words []string
	var current strings.Builder
	for _, r := range text {
		if unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '.' {
			current.WriteRune(r)
		} else {
			if current.Len() > 0 {
				words = append(words, strings.ToLower(current.String()))
				current.Reset()
			}
		}
	}
	if current.Len() > 0 {
		words = append(words, strings.ToLower(current.String()))
	}
	return words
}
