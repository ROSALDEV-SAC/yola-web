package llm

import (
	"context"
)

// ─── Types ───────────────────────────────────────────────────────────────

// ChatMessage represents a message in the OpenAI chat format.
type ChatMessage struct {
	Role       string         `json:"role"`
	Content    interface{}    `json:"content"`              // string or nil (for tool calls)
	ToolCallID string         `json:"tool_call_id,omitempty"`
	ToolCalls  []ToolCallData `json:"tool_calls,omitempty"`
}

// ToolCallData represents a tool call within an assistant message.
type ToolCallData struct {
	ID       string           `json:"id"`
	Type     string           `json:"type"`
	Function ToolCallFuncData `json:"function"`
}

// ToolCallFuncData holds the function name and arguments for a tool call.
type ToolCallFuncData struct {
	Name      string `json:"name"`
	Arguments string `json:"arguments"`
}

// ToolDefinition is the JSON schema for a tool sent to the LLM API.
type ToolDefinition struct {
	Type     string       `json:"type"`
	Function ToolFunction `json:"function"`
}

// ToolFunction describes a callable function for the LLM.
type ToolFunction struct {
	Name        string     `json:"name"`
	Description string     `json:"description"`
	Parameters  ToolSchema `json:"parameters"`
}

// ToolSchema is JSON Schema for tool parameters.
type ToolSchema struct {
	Type       string                  `json:"type"`
	Properties map[string]ToolProperty `json:"properties"`
	Required   []string                `json:"required,omitempty"`
}

// ToolProperty describes a single parameter of a tool.
type ToolProperty struct {
	Type        string   `json:"type"`
	Description string   `json:"description,omitempty"`
	Enum        []string `json:"enum,omitempty"`
}

// ToolCallDelta is a streaming delta for a tool call.
type ToolCallDelta struct {
	Index    int              `json:"index"`
	ID       string           `json:"id,omitempty"`
	Type     string           `json:"type,omitempty"`
	Function ToolCallFuncDelta `json:"function,omitempty"`
}

// ToolCallFuncDelta holds streaming function name/arguments for a tool call.
type ToolCallFuncDelta struct {
	Name      string `json:"name,omitempty"`
	Arguments string `json:"arguments,omitempty"`
}

// LLMChunk is emitted by CallWithTools for each streaming event.
type LLMChunk struct {
	Type      string        `json:"type"`      // "text", "tool_call", "reasoning", "error", "done"
	Text      string        `json:"text,omitempty"`
	Reasoning string        `json:"reasoning,omitempty"`
	ToolCall  *ToolCallInfo `json:"toolCall,omitempty"`
	Error     string        `json:"error,omitempty"`
}

// ToolCallInfo holds a complete tool call from the LLM.
type ToolCallInfo struct {
	ID       string              `json:"id"`
	Type     string              `json:"type"`
	Function ToolCallInfoFunction `json:"function"`
}

// ToolCallInfoFunction holds the function details for a tool call.
type ToolCallInfoFunction struct {
	Name      string `json:"name"`
	Arguments string `json:"arguments"`
}

// ─── Request / Response Types ──────────────────────────────────────────

// ChatRequest is the request body for the OpenAI chat completions API.
type ChatRequest struct {
	Model       string           `json:"model"`
	Messages    []ChatMessage    `json:"messages"`
	Temperature *float64         `json:"temperature,omitempty"`
	Stream      bool             `json:"stream,omitempty"`
	Tools       []ToolDefinition `json:"tools,omitempty"`
}

// ChatResponse is the response from the OpenAI chat completions API (non-streaming).
type ChatResponse struct {
	Choices []Choice `json:"choices"`
}

// StreamChunk is a single chunk from the streaming API.
type StreamChunk struct {
	Choices []StreamChoice `json:"choices"`
}

// Choice represents a choice in a non-streaming response.
type Choice struct {
	Message      ChatMessage `json:"message"`
	FinishReason string      `json:"finish_reason"`
}

// StreamChoice represents a choice in a streaming response.
type StreamChoice struct {
	Delta        DeltaData `json:"delta"`
	FinishReason string    `json:"finish_reason"`
}

// DeltaData holds the delta content and tool calls for streaming.
type DeltaData struct {
	Content          string          `json:"content,omitempty"`
	ReasoningContent string          `json:"reasoning_content,omitempty"`
	ToolCalls        []ToolCallDelta `json:"tool_calls,omitempty"`
}

// ─── Client Interface ──────────────────────────────────────────────────

// Client defines the interface for LLM API calls.
type Client interface {
	CallStreamingContext(ctx context.Context, baseURL, apiKey, model string, messages []ChatMessage, variant string) (<-chan string, error)
	CallStreaming(baseURL, apiKey, model string, messages []ChatMessage, variant string) (<-chan string, error)
	CallWithToolsContext(ctx context.Context, baseURL, apiKey, model string, messages []ChatMessage, tools []ToolDefinition, temperature *float64) (<-chan LLMChunk, error)
	CallWithTools(baseURL, apiKey, model string, messages []ChatMessage, tools []ToolDefinition, temperature *float64) (<-chan LLMChunk, error)
}
