package llm

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"time"
)

// OpenAILLMClient implements Client for OpenAI-compatible APIs.
type OpenAILLMClient struct {
	httpClient *http.Client
}

// NewClient creates a new OpenAILLMClient.
func NewClient() *OpenAILLMClient {
	return &OpenAILLMClient{
		httpClient: &http.Client{
			Timeout: 5 * time.Minute,
			Transport: &http.Transport{
				DialContext: (&net.Dialer{
					Timeout:   30 * time.Second,
					KeepAlive: 30 * time.Second,
				}).DialContext,
				ResponseHeaderTimeout: 30 * time.Second,
				MaxIdleConns:          10,
				IdleConnTimeout:       90 * time.Second,
			},
		},
	}
}

// CallStreamingContext calls the API with streaming and returns text deltas.
func (c *OpenAILLMClient) CallStreamingContext(
	ctx context.Context,
	baseURL string,
	apiKey string,
	model string,
	messages []ChatMessage,
	variant string,
) (<-chan string, error) {
	deltas := make(chan string, 256)

	req := ChatRequest{
		Model:    model,
		Messages: messages,
		Stream:   true,
	}

	var temp float64
	switch variant {
	case "minimal":
		temp = 0.1
	case "low":
		temp = 0.3
	case "medium":
		temp = 0.5
	case "high":
		temp = 0.7
	case "max":
		temp = 0.9
	default:
		temp = 0.5
	}
	req.Temperature = &temp

	url := strings.TrimRight(baseURL, "/") + "/chat/completions"
	body, err := json.Marshal(req)
	if err != nil {
		close(deltas)
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewReader(body))
	if err != nil {
		close(deltas)
		return nil, fmt.Errorf("creating request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/json")
	if apiKey != "" {
		httpReq.Header.Set("Authorization", "Bearer "+apiKey)
	}

	go func() {
		defer close(deltas)

		resp, err := c.httpClient.Do(httpReq)
		if err != nil {
			deltas <- fmt.Sprintf("\n\n[Error: %v]", err)
			return
		}
		defer resp.Body.Close()

		if resp.StatusCode != 200 {
			respBody, _ := io.ReadAll(resp.Body)
			deltas <- fmt.Sprintf("\n\n[Error %d: %s]", resp.StatusCode, strings.TrimSpace(string(respBody)))
			return
		}

		reader := bufio.NewReader(resp.Body)
		for {
			lineBytes, err := reader.ReadBytes('\n')
			if err != nil {
				if err == io.EOF {
					break
				}
				deltas <- fmt.Sprintf("\n\n[Stream error: %v]", err)
				return
			}
			line := strings.TrimRight(string(lineBytes), "\r\n")
			if line == "" {
				continue
			}
			if !strings.HasPrefix(line, "data: ") {
				continue
			}
			data := strings.TrimPrefix(line, "data: ")
			if data == "[DONE]" {
				return
			}

			var chunk StreamChunk
			if err := json.Unmarshal([]byte(data), &chunk); err != nil {
				continue
			}
			if len(chunk.Choices) > 0 {
				deltas <- chunk.Choices[0].Delta.Content
			}
		}
	}()

	return deltas, nil
}

// CallStreaming is a convenience wrapper without context.
func (c *OpenAILLMClient) CallStreaming(baseURL, apiKey, model string, messages []ChatMessage, variant string) (<-chan string, error) {
	return c.CallStreamingContext(context.Background(), baseURL, apiKey, model, messages, variant)
}

// CallWithToolsContext calls the API with tool definitions and returns structured chunks.
func (c *OpenAILLMClient) CallWithToolsContext(
	ctx context.Context,
	baseURL string,
	apiKey string,
	model string,
	messages []ChatMessage,
	tools []ToolDefinition,
	temperature *float64,
) (<-chan LLMChunk, error) {
	chunks := make(chan LLMChunk, 256)

	req := ChatRequest{
		Model:       model,
		Messages:    messages,
		Stream:      true,
		Tools:       tools,
		Temperature: temperature,
	}

	url := strings.TrimRight(baseURL, "/") + "/chat/completions"
	body, err := json.Marshal(req)
	if err != nil {
		close(chunks)
		return nil, fmt.Errorf("marshaling request: %w", err)
	}

	httpReq, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewReader(body))
	if err != nil {
		close(chunks)
		return nil, fmt.Errorf("creating request: %w", err)
	}
	httpReq.Header.Set("Content-Type", "application/json")
	if apiKey != "" {
		httpReq.Header.Set("Authorization", "Bearer "+apiKey)
	}

	go func() {
		defer close(chunks)

		resp, err := c.httpClient.Do(httpReq)
		if err != nil {
			chunks <- LLMChunk{Type: "error", Error: fmt.Sprintf("API call failed: %v", err)}
			return
		}
		defer resp.Body.Close()

		if resp.StatusCode != 200 {
			respBody, _ := io.ReadAll(resp.Body)
			chunks <- LLMChunk{Type: "error", Error: fmt.Sprintf("API error %d: %s", resp.StatusCode, strings.TrimSpace(string(respBody)))}
			return
		}

		// Accumulate tool call data across chunks
		var toolAccum map[int]*ToolCallInfo
		var toolEmitted bool

		reader := bufio.NewReader(resp.Body)
		for {
			lineBytes, err := reader.ReadBytes('\n')
			if err != nil {
				if err == io.EOF {
					break
				}
				chunks <- LLMChunk{Type: "error", Error: fmt.Sprintf("Stream error: %v", err)}
				return
			}
			line := strings.TrimRight(string(lineBytes), "\r\n")
			if line == "" {
				continue
			}
			if !strings.HasPrefix(line, "data: ") {
				continue
			}
			data := strings.TrimPrefix(line, "data: ")
			if data == "[DONE]" {
				break
			}

			var chunk StreamChunk
			if err := json.Unmarshal([]byte(data), &chunk); err != nil {
				continue
			}
			if len(chunk.Choices) == 0 {
				continue
			}
			choice := chunk.Choices[0]

			// Handle text content delta
			if choice.Delta.Content != "" {
				chunks <- LLMChunk{Type: "text", Text: choice.Delta.Content}
			}

			// Handle reasoning content delta (used by models like DeepSeek-R1, Qwen-Thinker, etc.)
			if choice.Delta.ReasoningContent != "" {
				chunks <- LLMChunk{Type: "reasoning", Reasoning: choice.Delta.ReasoningContent}
			}

			// Handle tool call deltas — accumulate multi-chunk tool calls by index
			if len(choice.Delta.ToolCalls) > 0 {
				for _, tc := range choice.Delta.ToolCalls {
					if toolAccum == nil {
						toolAccum = make(map[int]*ToolCallInfo)
					}
					if _, exists := toolAccum[tc.Index]; !exists {
						toolAccum[tc.Index] = &ToolCallInfo{
							Type: "function",
						}
					}
					ti := toolAccum[tc.Index]
					if tc.ID != "" {
						ti.ID = tc.ID
					}
					if tc.Function.Name != "" {
						ti.Function.Name = tc.Function.Name
					}
					if tc.Function.Arguments != "" {
						ti.Function.Arguments += tc.Function.Arguments
					}
				}
			}

			// When finish_reason is "tool_calls", emit accumulated tool calls once
			if choice.FinishReason == "tool_calls" && toolAccum != nil && !toolEmitted {
				toolEmitted = true
				for _, ti := range toolAccum {
					chunks <- LLMChunk{Type: "tool_call", ToolCall: ti}
				}
				if choice.Delta.Content == "" {
					chunks <- LLMChunk{Type: "done"}
				}
				toolAccum = nil
			}
		}

		// Emit any remaining tool calls if finish_reason wasn't set in the stream
		if toolAccum != nil && !toolEmitted {
			for _, ti := range toolAccum {
				chunks <- LLMChunk{Type: "tool_call", ToolCall: ti}
			}
		}
	}()

	return chunks, nil
}

// CallWithTools is a convenience wrapper without context.
func (c *OpenAILLMClient) CallWithTools(baseURL, apiKey, model string, messages []ChatMessage, tools []ToolDefinition, temperature *float64) (<-chan LLMChunk, error) {
	return c.CallWithToolsContext(context.Background(), baseURL, apiKey, model, messages, tools, temperature)
}
