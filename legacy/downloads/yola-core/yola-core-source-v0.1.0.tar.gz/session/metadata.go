package session

// TokenUsage tracks token consumption for an LLM call.
type TokenUsage struct {
	Input           int `json:"input"`
	Output          int `json:"output"`
	Reasoning       int `json:"reasoning,omitempty"`
	CacheReadInput  int `json:"cacheReadInput,omitempty"`
	CacheWriteInput int `json:"cacheWriteInput,omitempty"`
}

// ProviderMetadata captures provider-level information for a tool call or LLM call.
type ProviderMetadata struct {
	ProviderID string `json:"providerId,omitempty"`
	ModelID    string `json:"modelId,omitempty"`
	LatencyMs  int64  `json:"latencyMs,omitempty"`
}

// ToolCallState represents the lifecycle state of a tool call.
type ToolCallState string

const (
	ToolCallPending   ToolCallState = "pending"
	ToolCallRunning   ToolCallState = "running"
	ToolCallCompleted ToolCallState = "completed"
	ToolCallFailed    ToolCallState = "failed"
)
