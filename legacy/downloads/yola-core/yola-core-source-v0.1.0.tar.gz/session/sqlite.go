package session

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"sync"
	"time"

	"github.com/ROSALDEV-SAC/yola-core/config"
	"github.com/ROSALDEV-SAC/yola-core/db"
)

// scanner is satisfied by both *sql.Row and *sql.Rows.
type scanner interface {
	Scan(dest ...interface{}) error
}

// SQLiteSessionStore provides SQLite-backed session and message persistence.
type SQLiteSessionStore struct {
	mu sync.Mutex
	d  *db.Database
}

// NewStore creates a new SQLiteSessionStore.
func NewStore(database *db.Database) *SQLiteSessionStore {
	return &SQLiteSessionStore{d: database}
}

// ─── Helpers ────────────────────────────────────────────────────────────

func marshalModel(m *config.ModelRef) string {
	if m == nil {
		return ""
	}
	data, err := json.Marshal(m)
	if err != nil {
		log.Printf("[WARN] marshal model: %v", err)
		return ""
	}
	return string(data)
}

func unmarshalModel(s string) *config.ModelRef {
	if s == "" {
		return nil
	}
	var m config.ModelRef
	if err := json.Unmarshal([]byte(s), &m); err != nil {
		return nil
	}
	return &m
}

func scanSession(s scanner) (*Session, error) {
	var id, title, agent, status, parentID, workspaceID string
	var modelStr sql.NullString
	var createdAt, updatedAt int64
	err := s.Scan(&id, &title, &agent, &modelStr, &status, &parentID, &workspaceID, &createdAt, &updatedAt)
	if err != nil {
		return nil, err
	}
	session := &Session{
		ID:          id,
		Title:       title,
		Agent:       agent,
		Model:       unmarshalModel(modelStr.String),
		Status:      status,
		ParentID:    parentID,
		WorkspaceID: workspaceID,
		CreatedAt:   createdAt,
		UpdatedAt:   updatedAt,
		Messages:    make([]Message, 0),
	}
	return session, nil
}

// ─── Schema Migration ───────────────────────────────────────────────────

// columnExists checks if a column exists in a SQLite table.
func columnExists(d *sql.DB, table, column string) (bool, error) {
	rows, err := d.Query("PRAGMA table_info("+table+")", nil...)
	if err != nil {
		return false, err
	}
	defer rows.Close()
	for rows.Next() {
		var cid int
		var name, ctype string
		var notnull int
		var dflt sql.NullString
		var pk int
		if err := rows.Scan(&cid, &name, &ctype, &notnull, &dflt, &pk); err != nil {
			continue
		}
		if name == column {
			return true, nil
		}
	}
	if err := rows.Err(); err != nil {
		return false, err
	}
	return false, nil
}

// ensureSchema adds metadata columns to the messages table if they don't exist.
func (s *SQLiteSessionStore) ensureSchema() {
	migrations := []struct {
		column string
		stmt   string
	}{
		{column: "token_usage", stmt: "ALTER TABLE messages ADD COLUMN token_usage TEXT"},
		{column: "provider_meta", stmt: "ALTER TABLE messages ADD COLUMN provider_meta TEXT"},
		{column: "latency_ms", stmt: "ALTER TABLE messages ADD COLUMN latency_ms INTEGER"},
	}
	for _, m := range migrations {
		exists, err := columnExists(s.d.DB, "messages", m.column)
		if err != nil {
			log.Printf("[DB] check column %s: %v", m.column, err)
			continue
		}
		if exists {
			continue
		}
		if _, err := s.d.DB.Exec(m.stmt); err != nil {
			log.Printf("[DB] migrate messages.%s: %v", m.column, err)
		}
	}
}

// ─── Create / Fork ──────────────────────────────────────────────────────

func (s *SQLiteSessionStore) Create(agent string, model *config.ModelRef, workspaceID string) *Session {
	now := time.Now().UnixMilli()
	id := db.NewID("ses")
	title := "New session - " + time.Now().Format(time.RFC3339)

	_, err := s.d.DB.Exec(
		`INSERT INTO sessions (id, parent_id, workspace_id, title, agent, model, status, created_at, updated_at)
		 VALUES (?, '', ?, ?, ?, ?, 'active', ?, ?)`,
		id, workspaceID, title, agent, marshalModel(model), now, now,
	)
	if err != nil {
		log.Printf("[DB] Create session: %v", err)
		return nil
	}

	return &Session{
		ID:          id,
		Title:       title,
		Agent:       agent,
		Model:       model,
		Status:      "active",
		WorkspaceID: workspaceID,
		CreatedAt:   now,
		UpdatedAt:   now,
		Messages:    make([]Message, 0),
	}
}

func (s *SQLiteSessionStore) Fork(parentID string) *Session {
	parent := s.Get(parentID)
	if parent == nil {
		return nil
	}

	now := time.Now().UnixMilli()
	id := db.NewID("ses")
	title := parent.Title + " (fork)"

	_, err := s.d.DB.Exec(
		`INSERT INTO sessions (id, parent_id, workspace_id, title, agent, model, status, created_at, updated_at)
		 VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)`,
		id, parentID, parent.WorkspaceID, title, parent.Agent, marshalModel(parent.Model), now, now,
	)
	if err != nil {
		log.Printf("[DB] Fork session: %v", err)
		return nil
	}

	// Read messages BEFORE starting the transaction, so we read from
	// the session table directly (not from a tx-pinned connection).
	// In in-memory SQLite, each connection is a separate DB instance,
	// so reading via s.d.DB while a tx is active would hit an empty DB.
	msgs := s.GetMessages(parentID)

	// Copy messages from parent inside a transaction for consistency
	tx, err := s.d.DB.Begin()
	if err != nil {
		log.Printf("[DB] Fork begin tx: %v", err)
		return nil
	}
	defer tx.Rollback() // no-op if tx.Commit() succeeds

	for _, msg := range msgs {
		msgID := db.NewID("msg")
		tcJSON, err := json.Marshal(msg.ToolCalls)
		if err != nil {
			log.Printf("[WARN] marshal tool calls: %v", err)
			return nil
		}
		_, err = tx.Exec(
			`INSERT INTO messages (id, session_id, role, content, tool_call_id, tool_calls, created_at)
			 VALUES (?, ?, ?, ?, ?, ?, ?)`,
			msgID, id, msg.Role, msg.Content, msg.ToolCallID, string(tcJSON), msg.CreatedAt,
		)
		if err != nil {
			log.Printf("[DB] Fork copy message: %v", err)
			return nil
		}
	}

	if err := tx.Commit(); err != nil {
		log.Printf("[DB] Fork commit tx: %v", err)
		return nil
	}

	return &Session{
		ID:          id,
		Title:       title,
		Agent:       parent.Agent,
		Model:       parent.Model,
		Status:      "active",
		ParentID:    parentID,
		WorkspaceID: parent.WorkspaceID,
		CreatedAt:   now,
		UpdatedAt:   now,
	}
}

// ForkAt forks a session from a specific message ID (copies messages up to that point).
// If messageID is empty, behaves like Fork (copies all messages).
func (s *SQLiteSessionStore) ForkAt(parentID string, messageID string) *Session {
	if messageID == "" {
		return s.Fork(parentID)
	}
	parent := s.Get(parentID)
	if parent == nil {
		return nil
	}

	now := time.Now().UnixMilli()
	id := db.NewID("ses")
	title := parent.Title + " (fork)"

	_, err := s.d.DB.Exec(
		`INSERT INTO sessions (id, parent_id, workspace_id, title, agent, model, status, created_at, updated_at)
		 VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)`,
		id, parentID, parent.WorkspaceID, title, parent.Agent, marshalModel(parent.Model), now, now,
	)
	if err != nil {
		log.Printf("[DB] ForkAt session: %v", err)
		return nil
	}

	// Copy messages up to and including the specified message ID
	msgs := s.GetMessages(parentID)
	tx, err := s.d.DB.Begin()
	if err != nil {
		log.Printf("[DB] ForkAt begin tx: %v", err)
		return nil
	}
	defer tx.Rollback()

	for _, msg := range msgs {
		msgID := db.NewID("msg")
		tcJSON, err := json.Marshal(msg.ToolCalls)
		if err != nil {
			log.Printf("[WARN] ForkAt marshal tool calls: %v", err)
			return nil
		}
		_, err = tx.Exec(
			`INSERT INTO messages (id, session_id, role, content, tool_call_id, tool_calls, created_at)
			 VALUES (?, ?, ?, ?, ?, ?, ?)`,
			msgID, id, msg.Role, msg.Content, msg.ToolCallID, string(tcJSON), msg.CreatedAt,
		)
		if err != nil {
			log.Printf("[DB] ForkAt copy message: %v", err)
			return nil
		}
		if msg.ID == messageID {
			break // stop at the specified message
		}
	}

	if err := tx.Commit(); err != nil {
		log.Printf("[DB] ForkAt commit tx: %v", err)
		return nil
	}

	return &Session{
		ID:          id,
		Title:       title,
		Agent:       parent.Agent,
		Model:       parent.Model,
		Status:      "active",
		ParentID:    parentID,
		WorkspaceID: parent.WorkspaceID,
		CreatedAt:   now,
		UpdatedAt:   now,
	}
}

// ─── Read ───────────────────────────────────────────────────────────────

func (s *SQLiteSessionStore) Get(id string) *Session {
	row := s.d.DB.QueryRow(
		`SELECT id, title, COALESCE(agent,''), COALESCE(model,''), status, COALESCE(parent_id,''), COALESCE(workspace_id,''), created_at, updated_at
		 FROM sessions WHERE id = ?`, id,
	)
	session, err := scanSession(row)
	if err != nil {
		return nil
	}
	return session
}

func (s *SQLiteSessionStore) ListRoots(status string) []*Session {
	query := `SELECT id, title, COALESCE(agent,''), COALESCE(model,''), status, COALESCE(parent_id,''), COALESCE(workspace_id,''), created_at, updated_at
		FROM sessions WHERE parent_id = '' OR parent_id IS NULL`
	var args []interface{}
	if status != "" {
		query += ` AND status = ?`
		args = append(args, status)
	}
	query += ` ORDER BY updated_at DESC`
	rows, err := s.d.DB.Query(query, args...)
	if err != nil {
		log.Printf("[DB] ListRoots: %v", err)
		return nil
	}
	defer rows.Close()

	var sessions []*Session
	for rows.Next() {
		s, err := scanSession(rows)
		if err != nil {
			continue
		}
		sessions = append(sessions, s)
	}
	if err := rows.Err(); err != nil {
		log.Printf("[DB] ListRoots rows: %v", err)
		return nil
	}
	return sessions
}

func (s *SQLiteSessionStore) ListRootsFiltered(workspaceID, status string) []*Session {
	query := `SELECT id, title, COALESCE(agent,''), COALESCE(model,''), status, COALESCE(parent_id,''), COALESCE(workspace_id,''), created_at, updated_at
		FROM sessions WHERE (parent_id = '' OR parent_id IS NULL) AND workspace_id = ?`
	var args []interface{} = []interface{}{workspaceID}
	if status != "" {
		query += ` AND status = ?`
		args = append(args, status)
	}
	query += ` ORDER BY updated_at DESC`
	rows, err := s.d.DB.Query(query, args...)
	if err != nil {
		log.Printf("[DB] ListRootsFiltered: %v", err)
		return nil
	}
	defer rows.Close()
	var sessions []*Session
	for rows.Next() {
		se, err := scanSession(rows)
		if err != nil {
			continue
		}
		sessions = append(sessions, se)
	}
	if err := rows.Err(); err != nil {
		log.Printf("[DB] ListRootsFiltered rows: %v", err)
		return nil
	}
	return sessions
}

// ─── Update ─────────────────────────────────────────────────────────────

func (s *SQLiteSessionStore) UpdateSession(id, title, status string) (bool, error) {
	now := time.Now().UnixMilli()
	result, err := s.d.DB.Exec(
		`UPDATE sessions SET title = COALESCE(NULLIF(?, ''), title), status = COALESCE(NULLIF(?, ''), status), updated_at = ? WHERE id = ?`,
		title, status, now, id,
	)
	if err != nil {
		return false, err
	}
	n, _ := result.RowsAffected()
	return n > 0, nil
}

// SetStatus updates only the status of a session.
func (s *SQLiteSessionStore) SetStatus(id, status string) (bool, error) {
	return s.UpdateSession(id, "", status)
}

func (s *SQLiteSessionStore) Archive(id string) bool {
	now := time.Now().UnixMilli()
	_, err := s.d.DB.Exec(`UPDATE sessions SET status = 'archived', updated_at = ? WHERE id = ?`, now, id)
	return err == nil
}

func (s *SQLiteSessionStore) Delete(id string) bool {
	_, err := s.d.DB.Exec(`DELETE FROM sessions WHERE id = ?`, id)
	return err == nil
}

// ─── Messages ───────────────────────────────────────────────────────────

func (s *SQLiteSessionStore) AddMessage(sessionID, role, content string) *Message {
	now := time.Now().UnixMilli()
	msgID := db.NewID("msg")
	_, err := s.d.DB.Exec(
		`INSERT INTO messages (id, session_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)`,
		msgID, sessionID, role, content, now,
	)
	if err != nil {
		log.Printf("[DB] AddMessage: %v", err)
		return nil
	}
	// Update session timestamp
	s.d.DB.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, now, sessionID)
	return &Message{ID: msgID, Role: role, Content: content, CreatedAt: now}
}

func (s *SQLiteSessionStore) AddMessageWithTools(sessionID, role, content string, toolCalls []ToolCallData) *Message {
	now := time.Now().UnixMilli()
	msgID := db.NewID("msg")
	tcJSON, err := json.Marshal(toolCalls)
	if err != nil {
		log.Printf("[WARN] marshal tool calls: %v", err)
		return nil
	}
	_, err = s.d.DB.Exec(
		`INSERT INTO messages (id, session_id, role, content, tool_calls, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
		msgID, sessionID, role, content, string(tcJSON), now,
	)
	if err != nil {
		log.Printf("[DB] AddMessageWithTools: %v", err)
		return nil
	}
	s.d.DB.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, now, sessionID)
	return &Message{ID: msgID, Role: role, Content: content, ToolCalls: toolCalls, CreatedAt: now}
}

func (s *SQLiteSessionStore) AddToolResultMessage(sessionID, toolCallID, toolName, result string) *Message {
	now := time.Now().UnixMilli()
	msgID := db.NewID("msg")
	content := fmt.Sprintf("[Tool %s (%s)]\n%s", toolName, toolCallID, result)
	if len(content) > 10000 {
		content = content[:10000] + "\n... truncated"
	}
	_, err := s.d.DB.Exec(
		`INSERT INTO messages (id, session_id, role, content, tool_call_id, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
		msgID, sessionID, "tool", content, toolCallID, now,
	)
	if err != nil {
		log.Printf("[DB] AddToolResultMessage: %v", err)
		return nil
	}
	s.d.DB.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, now, sessionID)
	return &Message{ID: msgID, Role: "tool", Content: content, ToolCallID: toolCallID, CreatedAt: now}
}

func (s *SQLiteSessionStore) AddMessageWithMetadata(sessionID, role, content string, reasoning string, toolCallID string, toolCalls []ToolCallData, tokenUsage *TokenUsage, providerMeta *ProviderMetadata, latencyMs int64) *Message {
	return s.addMessageWithInterrupted(sessionID, role, content, reasoning, toolCallID, toolCalls, tokenUsage, providerMeta, latencyMs, false)
}

// AddInterruptedMessage stores an assistant message marked as interrupted (partial content).
func (s *SQLiteSessionStore) AddInterruptedMessage(sessionID, content, reasoning string, providerMeta *ProviderMetadata, latencyMs int64) *Message {
	return s.addMessageWithInterrupted(sessionID, "assistant", content, reasoning, "", nil, nil, providerMeta, latencyMs, true)
}

// AddInterruptedMessageWithTools stores an interrupted assistant message that includes tool calls.
func (s *SQLiteSessionStore) AddInterruptedMessageWithTools(sessionID, content, reasoning string, toolCalls []ToolCallData, providerMeta *ProviderMetadata, latencyMs int64) *Message {
	return s.addMessageWithInterrupted(sessionID, "assistant", content, reasoning, "", toolCalls, nil, providerMeta, latencyMs, true)
}

// addMessageWithInterrupted is like AddMessageWithMetadata but also sets the interrupted flag.
func (s *SQLiteSessionStore) addMessageWithInterrupted(sessionID, role, content string, reasoning string, toolCallID string, toolCalls []ToolCallData, tokenUsage *TokenUsage, providerMeta *ProviderMetadata, latencyMs int64, interrupted bool) *Message {
	s.ensureSchema()
	now := time.Now().UnixMilli()
	msgID := db.NewID("msg")

	var tcJSON string
	if len(toolCalls) > 0 {
		b, err := json.Marshal(toolCalls)
		if err != nil {
			log.Printf("[WARN] marshal tool calls: %v", err)
			return nil
		}
		tcJSON = string(b)
	}
	var tuJSON string
	if tokenUsage != nil {
		b, err := json.Marshal(tokenUsage)
		if err != nil {
			log.Printf("[WARN] marshal token usage: %v", err)
			return nil
		}
		tuJSON = string(b)
	}
	var pmJSON string
	if providerMeta != nil {
		b, err := json.Marshal(providerMeta)
		if err != nil {
			log.Printf("[WARN] marshal provider meta: %v", err)
			return nil
		}
		pmJSON = string(b)
	}

	interruptedInt := 0
	if interrupted {
		interruptedInt = 1
	}
	_, err := s.d.DB.Exec(
		`INSERT INTO messages (id, session_id, role, content, reasoning, tool_call_id, tool_calls, token_usage, provider_meta, latency_ms, interrupted, created_at)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		msgID, sessionID, role, content, reasoning, toolCallID, tcJSON, tuJSON, pmJSON, latencyMs, interruptedInt, now,
	)
	if err != nil {
		log.Printf("[DB] AddMessageWithMetadata: %v", err)
		return nil
	}
	s.d.DB.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, now, sessionID)
	return &Message{
		ID:           msgID,
		Role:         role,
		Content:      content,
		Reasoning:    reasoning,
		ToolCallID:   toolCallID,
		ToolCalls:    toolCalls,
		Interrupted:  interrupted,
		TokenUsage:   tokenUsage,
		ProviderMeta: providerMeta,
		LatencyMs:    latencyMs,
		CreatedAt:    now,
	}
}

func (s *SQLiteSessionStore) GetMessages(sessionID string) []Message {
	s.ensureSchema()
	rows, err := s.d.DB.Query(
		`SELECT id, COALESCE(role,''), COALESCE(content,''), COALESCE(reasoning,''), COALESCE(tool_call_id,''), COALESCE(tool_calls,''), created_at,
		 COALESCE(token_usage,''), COALESCE(provider_meta,''), COALESCE(latency_ms,0), COALESCE(interrupted,0)
		 FROM messages WHERE session_id = ? ORDER BY created_at ASC`, sessionID,
	)
	if err != nil {
		return nil
	}
	defer rows.Close()

	var messages []Message
	for rows.Next() {
		var id, role, content, reasoning, tcID, tcStr string
		var createdAt, latencyMs int64
		var tuStr, pmStr string
		var interruptedInt int64
		if err := rows.Scan(&id, &role, &content, &reasoning, &tcID, &tcStr, &createdAt, &tuStr, &pmStr, &latencyMs, &interruptedInt); err != nil {
			continue
		}
		msg := Message{ID: id, Role: role, Content: content, Reasoning: reasoning, ToolCallID: tcID, CreatedAt: createdAt, LatencyMs: latencyMs, Interrupted: interruptedInt != 0}
		if tcStr != "" {
			json.Unmarshal([]byte(tcStr), &msg.ToolCalls)
		}
		if tuStr != "" {
			json.Unmarshal([]byte(tuStr), &msg.TokenUsage)
		}
		if pmStr != "" {
			json.Unmarshal([]byte(pmStr), &msg.ProviderMeta)
		}
		messages = append(messages, msg)
	}
	if err := rows.Err(); err != nil {
		log.Printf("[DB] GetMessages rows: %v", err)
		return nil
	}
	return messages
}

func (s *SQLiteSessionStore) SearchMessages(sessionID, query string) []Message {
	rows, err := s.d.DB.Query(
		`SELECT id, COALESCE(role,''), COALESCE(content,''), COALESCE(tool_call_id,''), COALESCE(tool_calls,''), created_at
		 FROM messages WHERE session_id = ? AND content LIKE '%' || ? || '%' ORDER BY created_at ASC`,
		sessionID, query,
	)
	if err != nil {
		return nil
	}
	defer rows.Close()
	var messages []Message
	for rows.Next() {
		var id, role, content, tcID, tcStr string
		var createdAt int64
		if err := rows.Scan(&id, &role, &content, &tcID, &tcStr, &createdAt); err != nil {
			continue
		}
		msg := Message{ID: id, Role: role, Content: content, ToolCallID: tcID, CreatedAt: createdAt}
		if tcStr != "" {
			json.Unmarshal([]byte(tcStr), &msg.ToolCalls)
		}
		messages = append(messages, msg)
	}
	if err := rows.Err(); err != nil {
		log.Printf("[DB] SearchMessages rows: %v", err)
		return nil
	}
	return messages
}

func (s *SQLiteSessionStore) UpdateMessage(sessionID, msgID, content string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	res, err := s.d.DB.Exec(
		`UPDATE messages SET content = ? WHERE id = ? AND session_id = ?`,
		content, msgID, sessionID,
	)
	if err != nil {
		log.Printf("[DB] UpdateMessage: %v", err)
		return false
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		log.Printf("[DB] UpdateMessage: no rows affected (msg %s not found)", msgID)
		return false
	}
	s.d.DB.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, time.Now().UnixMilli(), sessionID)
	return true
}

func (s *SQLiteSessionStore) DeleteMessage(sessionID, msgID string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	res, err := s.d.DB.Exec(
		`DELETE FROM messages WHERE id = ? AND session_id = ?`,
		msgID, sessionID,
	)
	if err != nil {
		log.Printf("[DB] DeleteMessage: %v", err)
		return false
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		log.Printf("[DB] DeleteMessage: no rows affected (msg %s not found)", msgID)
		return false
	}
	now := time.Now().UnixMilli()
	s.d.DB.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, now, sessionID)
	return true
}

// ─── Working Memory ─────────────────────────────────────────────────────

func (s *SQLiteSessionStore) GetWorkingMemory(sessionID string) map[string]string {
	rows, err := s.d.DB.Query(
		`SELECT key, value FROM working_memory WHERE session_id = ?`, sessionID,
	)
	if err != nil {
		return nil
	}
	defer rows.Close()
	mem := make(map[string]string)
	for rows.Next() {
		var key, value string
		if rows.Scan(&key, &value) == nil {
			mem[key] = value
		}
	}
	if err := rows.Err(); err != nil {
		log.Printf("[DB] GetWorkingMemory rows: %v", err)
		return nil
	}
	return mem
}

func (s *SQLiteSessionStore) SetWorkingMemory(sessionID, key, value string) {
	now := time.Now().UnixMilli()
	_, err := s.d.DB.Exec(
		`INSERT INTO working_memory (session_id, key, value, created_at, updated_at)
		 VALUES (?, ?, ?, ?, ?)
		 ON CONFLICT(session_id, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
		sessionID, key, value, now, now,
	)
	if err != nil {
		log.Printf("[DB] SetWorkingMemory: %v", err)
	}
}

// ─── Decisions ──────────────────────────────────────────────────────────

func (s *SQLiteSessionStore) RecordDecision(sessionID, workspaceID string, turn int, observation, inference, decision, alternatives, toolName, toolArgs, context, outcome, outcomeDetail string, importance float64) string {
	now := time.Now().UnixMilli()
	id := db.NewID("dec")
	_, err := s.d.DB.Exec(
		`INSERT INTO decision_journal (id, session_id, workspace_id, turn, observation, inference, decision, alternatives, tool_name, tool_args, context, outcome, outcome_detail, importance, created_at)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		id, sessionID, workspaceID, turn, observation, inference, decision, alternatives, toolName, toolArgs, context, outcome, outcomeDetail, importance, now,
	)
	if err != nil {
		log.Printf("[DB] RecordDecision: %v", err)
		return ""
	}
	return id
}

func (s *SQLiteSessionStore) UpdateDecision(id, outcome, outcomeDetail string) error {
	_, err := s.d.DB.Exec(
		`UPDATE decision_journal SET outcome = ?, outcome_detail = ? WHERE id = ?`,
		outcome, outcomeDetail, id,
	)
	return err
}

func (s *SQLiteSessionStore) QueryDecisions(query string, limit int) ([]DecisionEntry, error) {
	if limit <= 0 {
		limit = 20
	}
	rows, err := s.d.DB.Query(
		`SELECT id, COALESCE(session_id,''), COALESCE(workspace_id,''), turn, observation,
		        COALESCE(inference,''), decision, COALESCE(alternatives,''), COALESCE(outcome,''),
		        COALESCE(outcome_detail,''), COALESCE(tool_name,''), COALESCE(tool_args,''),
		        COALESCE(context,''), importance, created_at
		 FROM decision_journal
		 WHERE observation LIKE '%' || ? || '%' OR decision LIKE '%' || ? || '%'
		 ORDER BY created_at DESC LIMIT ?`, query, query, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []DecisionEntry
	for rows.Next() {
		var e DecisionEntry
		if err := rows.Scan(&e.ID, &e.SessionID, &e.WorkspaceID, &e.Turn, &e.Observation,
			&e.Inference, &e.Decision, &e.Alternatives, &e.Outcome, &e.OutcomeDetail,
			&e.ToolName, &e.ToolArgs, &e.Context, &e.Importance, &e.CreatedAt); err != nil {
			continue
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

func (s *SQLiteSessionStore) GetDecisionByID(id string) *DecisionEntry {
	row := s.d.DB.QueryRow(
		`SELECT id, COALESCE(session_id,''), COALESCE(workspace_id,''), turn, observation,
		        COALESCE(inference,''), decision, COALESCE(alternatives,''), COALESCE(outcome,''),
		        COALESCE(outcome_detail,''), COALESCE(tool_name,''), COALESCE(tool_args,''),
		        COALESCE(context,''), importance, created_at
		 FROM decision_journal WHERE id = ?`, id,
	)
	var e DecisionEntry
	err := row.Scan(&e.ID, &e.SessionID, &e.WorkspaceID, &e.Turn, &e.Observation,
		&e.Inference, &e.Decision, &e.Alternatives, &e.Outcome, &e.OutcomeDetail,
		&e.ToolName, &e.ToolArgs, &e.Context, &e.Importance, &e.CreatedAt)
	if err != nil {
		return nil
	}
	return &e
}

func (s *SQLiteSessionStore) GetRecentDecisions(limit int) ([]DecisionEntry, error) {
	if limit <= 0 {
		limit = 20
	}
	rows, err := s.d.DB.Query(
		`SELECT id, COALESCE(session_id,''), COALESCE(workspace_id,''), turn, observation,
		        COALESCE(inference,''), decision, COALESCE(alternatives,''), COALESCE(outcome,''),
		        COALESCE(outcome_detail,''), COALESCE(tool_name,''), COALESCE(tool_args,''),
		        COALESCE(context,''), importance, created_at
		 FROM decision_journal ORDER BY created_at DESC LIMIT ?`, limit,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var entries []DecisionEntry
	for rows.Next() {
		var e DecisionEntry
		if err := rows.Scan(&e.ID, &e.SessionID, &e.WorkspaceID, &e.Turn, &e.Observation,
			&e.Inference, &e.Decision, &e.Alternatives, &e.Outcome, &e.OutcomeDetail,
			&e.ToolName, &e.ToolArgs, &e.Context, &e.Importance, &e.CreatedAt); err != nil {
			continue
		}
		entries = append(entries, e)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	return entries, nil
}

// ─── Tool Call State ────────────────────────────────────────────────────

// UpdateToolCallState updates the state of a specific tool call within an assistant message.
// Returns true if the message and tool call were found and updated.
func (s *SQLiteSessionStore) UpdateToolCallState(sessionID, msgID, toolCallID string, newState ToolCallState) bool {
	s.mu.Lock()
	defer s.mu.Unlock()

	var tcStr string
	err := s.d.DB.QueryRow(
		`SELECT COALESCE(tool_calls, '') FROM messages WHERE id = ? AND session_id = ? AND role = 'assistant'`,
		msgID, sessionID,
	).Scan(&tcStr)
	if err != nil || tcStr == "" {
		return false
	}

	var toolCalls []ToolCallData
	if err := json.Unmarshal([]byte(tcStr), &toolCalls); err != nil {
		return false
	}

	found := false
	for i := range toolCalls {
		if toolCalls[i].ID == toolCallID {
			toolCalls[i].State = newState
			found = true
			break
		}
	}
	if !found {
		return false
	}

	updatedJSON, err := json.Marshal(toolCalls)
	if err != nil {
		return false
	}

	res, err := s.d.DB.Exec(
		`UPDATE messages SET tool_calls = ? WHERE id = ? AND session_id = ?`,
		string(updatedJSON), msgID, sessionID,
	)
	if err != nil {
		return false
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return false
	}

	now := time.Now().UnixMilli()
	s.d.DB.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, now, sessionID)
	return true
}

// GetPendingToolCalls returns all tool calls in pending or running state for a session.
func (s *SQLiteSessionStore) GetPendingToolCalls(sessionID string) []ToolCallData {
	rows, err := s.d.DB.Query(
		`SELECT COALESCE(tool_calls, '') FROM messages WHERE session_id = ? AND role = 'assistant' AND tool_calls IS NOT NULL AND tool_calls != ''`,
		sessionID,
	)
	if err != nil {
		return nil
	}
	defer rows.Close()

	var pending []ToolCallData
	for rows.Next() {
		var tcStr string
		if err := rows.Scan(&tcStr); err != nil {
			continue
		}
		var toolCalls []ToolCallData
		if err := json.Unmarshal([]byte(tcStr), &toolCalls); err != nil {
			continue
		}
		for _, tc := range toolCalls {
			if tc.State == ToolCallPending || tc.State == ToolCallRunning {
				pending = append(pending, tc)
			}
		}
	}
	if err := rows.Err(); err != nil {
		log.Printf("[DB] GetPendingToolCalls rows: %v", err)
		return nil
	}
	return pending
}

// AddToolResultWithState works like AddToolResultMessage but also updates the
// tool call state in the original assistant message in a single atomic operation.
func (s *SQLiteSessionStore) AddToolResultWithState(sessionID, msgID, toolCallID, toolName, result string, newState ToolCallState) *Message {
	s.mu.Lock()
	defer s.mu.Unlock()

	now := time.Now().UnixMilli()
	content := fmt.Sprintf("[Tool %s (%s)]\n%s", toolName, toolCallID, result)
	if len(content) > 10000 {
		content = content[:10000] + "\n... truncated"
	}

	// Use SQL transaction for atomicity
	tx, err := s.d.DB.Begin()
	if err != nil {
		log.Printf("[DB] AddToolResultWithState begin tx: %v", err)
		return nil
	}
	commit := false
	defer func() {
		if !commit {
			tx.Rollback()
		}
	}()

	resultMsgID := db.NewID("msg")
	_, err = tx.Exec(
		`INSERT INTO messages (id, session_id, role, content, tool_call_id, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
		resultMsgID, sessionID, "tool", content, toolCallID, now,
	)
	if err != nil {
		log.Printf("[DB] AddToolResultWithState insert: %v", err)
		return nil
	}

	// Update tool call state in the original assistant message
	var tcStr string
	err = tx.QueryRow(
		`SELECT COALESCE(tool_calls, '') FROM messages WHERE id = ? AND session_id = ? AND role = 'assistant'`,
		msgID, sessionID,
	).Scan(&tcStr)
	if err == nil && tcStr != "" {
		var toolCalls []ToolCallData
		if json.Unmarshal([]byte(tcStr), &toolCalls) == nil {
			for i := range toolCalls {
				if toolCalls[i].ID == toolCallID {
					toolCalls[i].State = newState
					break
				}
			}
			if updatedJSON, err := json.Marshal(toolCalls); err == nil {
				tx.Exec(
					`UPDATE messages SET tool_calls = ? WHERE id = ? AND session_id = ?`,
					string(updatedJSON), msgID, sessionID,
				)
			}
		}
	}

	tx.Exec(`UPDATE sessions SET updated_at = ? WHERE id = ?`, now, sessionID)

	if err := tx.Commit(); err != nil {
		log.Printf("[DB] AddToolResultWithState commit: %v", err)
		return nil
	}
	commit = true
	return &Message{ID: resultMsgID, Role: "tool", Content: content, ToolCallID: toolCallID, CreatedAt: now}
}

// InterruptSession cancels a running session via the shared RunStateManager.
func (s *SQLiteSessionStore) InterruptSession(sessionID string) error {
	return DefaultRunStateManager.CancelSession(sessionID)
}
