package session

import (
	"sync"
	"github.com/ROSALDEV-SAC/yola-core/config"
)

// ─── Types ──────────────────────────────────────────────────────────────

// ToolCallData represents a tool call within an assistant message.
type ToolCallData struct {
	ID       string           `json:"id"`
	Type     string           `json:"type"`
	Function ToolCallFuncData `json:"function"`
	State    ToolCallState    `json:"state,omitempty"`
}

// ToolCallFuncData holds the function name and arguments for a tool call.
type ToolCallFuncData struct {
	Name      string `json:"name"`
	Arguments string `json:"arguments"`
}

// Message represents a single message in a session.
type Message struct {
	ID           string             `json:"id,omitempty"`
	Role         string             `json:"role"`
	Content      string             `json:"content"`
	Reasoning    string             `json:"reasoning,omitempty"`
	ToolCallID   string             `json:"toolCallId,omitempty"`
	ToolCalls    []ToolCallData     `json:"toolCalls,omitempty"`
	Interrupted  bool               `json:"interrupted,omitempty"`
	CreatedAt    int64              `json:"createdAt"`
	TokenUsage   *TokenUsage        `json:"tokenUsage,omitempty"`
	ProviderMeta *ProviderMetadata  `json:"providerMeta,omitempty"`
	LatencyMs    int64              `json:"latencyMs,omitempty"`
}

// Session represents a conversation session.
type Session struct {
	ID          string          `json:"id"`
	Title       string          `json:"title,omitempty"`
	Agent       string          `json:"agent,omitempty"`
	Model       *config.ModelRef `json:"model,omitempty"`
	Status      string          `json:"status,omitempty"`
	ParentID    string          `json:"parentId,omitempty"`
	WorkspaceID string          `json:"workspaceId,omitempty"`
	CreatedAt   int64           `json:"createdAt"`
	UpdatedAt   int64           `json:"updatedAt"`
	Messages    []Message       `json:"-"`
	mu          sync.Mutex      `json:"-"`
}

// ─── Store Interface ───────────────────────────────────────────────────

// Store defines the interface for session persistence.
type Store interface {
	Create(agent string, model *config.ModelRef, workspaceID string) *Session
	Get(id string) *Session
	ListRoots(status string) []*Session
	ListRootsFiltered(workspaceID, status string) []*Session
	UpdateSession(id, title, status string) (bool, error)
	SetStatus(id, status string) (bool, error)
	Archive(id string) bool
	Delete(id string) bool
	AddMessage(sessionID, role, content string) *Message
	AddMessageWithTools(sessionID, role, content string, toolCalls []ToolCallData) *Message
	AddToolResultMessage(sessionID, toolCallID, toolName, result string) *Message
	AddToolResultWithState(sessionID, msgID, toolCallID, toolName, result string, newState ToolCallState) *Message
	AddMessageWithMetadata(sessionID, role, content string, reasoning string, toolCallID string, toolCalls []ToolCallData, tokenUsage *TokenUsage, providerMeta *ProviderMetadata, latencyMs int64) *Message
	AddInterruptedMessage(sessionID, content, reasoning string, providerMeta *ProviderMetadata, latencyMs int64) *Message
	AddInterruptedMessageWithTools(sessionID, content, reasoning string, toolCalls []ToolCallData, providerMeta *ProviderMetadata, latencyMs int64) *Message
	GetMessages(sessionID string) []Message
	SearchMessages(sessionID, query string) []Message
	UpdateMessage(sessionID, msgID, content string) bool
	DeleteMessage(sessionID, msgID string) bool
	Fork(parentID string) *Session
	ForkAt(parentID string, messageID string) *Session
	GetWorkingMemory(sessionID string) map[string]string
	SetWorkingMemory(sessionID, key, value string)
	RecordDecision(sessionID, workspaceID string, turn int, observation, inference, decision, alternatives, toolName, toolArgs, context, outcome, outcomeDetail string, importance float64) string
	UpdateDecision(id, outcome, outcomeDetail string) error
	QueryDecisions(query string, limit int) ([]DecisionEntry, error)
	GetDecisionByID(id string) *DecisionEntry
	GetRecentDecisions(limit int) ([]DecisionEntry, error)

	// UpdateToolCallState updates the state of a specific tool call within an assistant message.
	// Returns true if found and updated.
	UpdateToolCallState(sessionID, msgID, toolCallID string, newState ToolCallState) bool

	// GetPendingToolCalls returns all tool calls still in pending or running state for a session.
	GetPendingToolCalls(sessionID string) []ToolCallData

	// InterruptSession cancels a running session via the RunStateManager.
	InterruptSession(id string) error
}

// DecisionEntry represents a recorded decision in the decision journal.
type DecisionEntry struct {
	ID            string  `json:"id"`
	SessionID     string  `json:"sessionId"`
	WorkspaceID   string  `json:"workspaceId"`
	Turn          int     `json:"turn"`
	Observation   string  `json:"observation"`
	Inference     string  `json:"inference,omitempty"`
	Decision      string  `json:"decision"`
	Alternatives  string  `json:"alternatives,omitempty"`
	Outcome       string  `json:"outcome,omitempty"`
	OutcomeDetail string  `json:"outcomeDetail,omitempty"`
	ToolName      string  `json:"toolName,omitempty"`
	ToolArgs      string  `json:"toolArgs,omitempty"`
	Context       string  `json:"context,omitempty"`
	Importance    float64 `json:"importance"`
	CreatedAt     int64   `json:"createdAt"`
}
