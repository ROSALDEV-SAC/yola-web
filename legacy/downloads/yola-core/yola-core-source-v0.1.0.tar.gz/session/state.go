package session

import (
	"context"
	"fmt"
	"sync"
)

// ─── RunState ──────────────────────────────────────────────────────────

// RunState represents the execution state of a session.
type RunState string

const (
	RunStateIdle  RunState = "idle"
	RunStateBusy  RunState = "busy"
	RunStateRetry RunState = "retry"
	RunStateError RunState = "error"
)

// ─── RunStateManager ───────────────────────────────────────────────────

// RunStateManager provides concurrency-safe state transitions for sessions.
// It is an in-memory guard, separate from DB persistence.
type RunStateManager struct {
	mu     sync.Mutex
	states map[string]*sessionState
}

type sessionState struct {
	state         RunState
	attempt       int               // retry attempt count
	message       string            // retry error message
	cancel        context.CancelFunc // registered by agent loop
	pendingCancel bool              // interrupt requested before cancel was registered
}

// DefaultRunStateManager is the shared RunStateManager instance used across the application.
var DefaultRunStateManager = NewRunStateManager()

// NewRunStateManager creates a new RunStateManager.
func NewRunStateManager() *RunStateManager {
	return &RunStateManager{
		states: make(map[string]*sessionState),
	}
}

// TryAcquire attempts to transition a session from idle to busy.
// Returns an error if the session is already busy (or in retry/error).
func (m *RunStateManager) TryAcquire(sessionID string) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	s, exists := m.states[sessionID]
	if exists && s.state != RunStateIdle {
		return fmt.Errorf("session %s is already %s (attempt=%d, msg=%s)",
			sessionID, s.state, s.attempt, s.message)
	}

	m.states[sessionID] = &sessionState{state: RunStateBusy}
	return nil
}

// Release transitions a session from busy back to idle.
func (m *RunStateManager) Release(sessionID string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	s, exists := m.states[sessionID]
	if !exists {
		return
	}

	s.state = RunStateIdle
	s.attempt = 0
	s.message = ""
	s.cancel = nil
	s.pendingCancel = false
}

// SetRetry marks a session for retry with attempt count and error message.
func (m *RunStateManager) SetRetry(sessionID string, attempt int, errMsg string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	s, exists := m.states[sessionID]
	if !exists {
		s = &sessionState{}
		m.states[sessionID] = s
	}

	s.state = RunStateRetry
	s.attempt = attempt
	s.message = errMsg
}

// SetError marks a session as errored (non-recoverable).
func (m *RunStateManager) SetError(sessionID string, errMsg string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	s, exists := m.states[sessionID]
	if !exists {
		s = &sessionState{}
		m.states[sessionID] = s
	}

	s.state = RunStateError
	s.message = errMsg
}

// GetState returns the current state, attempt count, and message for a session.
func (m *RunStateManager) GetState(sessionID string) (RunState, int, string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	s, exists := m.states[sessionID]
	if !exists {
		return RunStateIdle, 0, ""
	}

	return s.state, s.attempt, s.message
}

// IsBusy returns true if the session is currently executing (busy state).
func (m *RunStateManager) IsBusy(sessionID string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()

	s, exists := m.states[sessionID]
	if !exists {
		return false
	}

	return s.state == RunStateBusy
}

// RegisterCancel stores a cancel function for a session.
// If a cancel was already requested (pendingCancel), calls cancel immediately.
func (m *RunStateManager) RegisterCancel(sessionID string, cancel context.CancelFunc) {
	m.mu.Lock()
	defer m.mu.Unlock()
	s, exists := m.states[sessionID]
	if exists && s.pendingCancel {
		cancel() // cancel was requested before we registered — do it now
		s.pendingCancel = false
		s.cancel = nil
		return
	}
	if exists {
		s.cancel = cancel
	}
}

// CancelSession cancels a running session by calling its cancel function.
// If the cancel function hasn't been registered yet, marks pendingCancel so
// it cancels as soon as RegisterCancel is called.
func (m *RunStateManager) CancelSession(sessionID string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	s, exists := m.states[sessionID]
	if !exists || s.state != RunStateBusy {
		return nil // not running — nothing to cancel
	}
	if s.cancel != nil {
		s.cancel()
		s.cancel = nil
		return nil
	}
	// Cancel function not yet registered (agent still starting) — mark pending
	s.pendingCancel = true
	return nil
}

// ReleaseAll releases all sessions (for graceful shutdown).
func (m *RunStateManager) ReleaseAll() {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.states = make(map[string]*sessionState)
}
